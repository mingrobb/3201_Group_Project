/* jshint esversion: 6 */



var content = new Vue
(
    {
        el: '#content',
        data:
        {
            // style controls //
            show_dashboard: true,
            x_style_area: "width: calc(100% - 400px);",

            // graphing controls //
            instance_select: "",
            algorithm_select: ["basic","advanced"],

            trial_all: 10,
            generation_all: 99,
            individual_all: 2,

            trial_n: 1,
            generation_n: 10,
            individual_n: 1,
        },
        methods:
        {
            toggleDashboard: function()
            {
                if(this.show_dashboard==true)
                {   this.x_style_area = "width: initial;";
                    this.show_dashboard = false;
                }
                else
                {   this.x_style_area = "width: calc(100% - 400px);";
                    this.show_dashboard = true;
                }
            },
            newDraw: function()
            {
                /*
                    instance_select, rial_n, generation_n, individual_n
                    根据所选的实例、测试、世代、个体
                */
                // 重绘plain map -------------------------------------------------------------------------------
                let plain_map = null;
                let instance = advanced_WesternSahara;

                if(this.instance_select == "WesternSahara")
                {
                    plain_map = plain_map_WesternSahara;
                    instance = advanced_WesternSahara;
                }
                else if(this.instance_select == "Uruguay")
                {
                    plain_map = plain_map_Uruguay;
                }
                else if(this.instance_select == "Canada")
                {
                    plain_map = plain_map_Canada;
                }

                var plain_map_plotly =
                    {
                        text: plain_map[0],
                        x: plain_map[1],
                        y: plain_map[2],
                        mode: 'markers',
                        type: 'scatter',
                    };

                Plotly.newPlot(   $(".figure.map")[0], [plain_map_plotly], {}, {responsive: true}   );

                // 重绘experiment ------------------------------------------------------------------------------

                let experiment_y_best = [];
                let experiment_y_worst = [];
                let experiment_y_avg = [];
                let experiment_x = [];

                console.log(instance);
                for(let i=0; i<instance["description"]["evolution_all"]; i++)
                {   experiment_x.push(i+1);   }

                for(let i=1; i<instance["evolutions"].length; i++)
                {
                    experiment_y_best.push(   instance["evolutions"][i][100]["best-individual-distance"]   );
                    experiment_y_worst.push(   instance["evolutions"][i][100]["worst-individual-distance"]   );
                    experiment_y_avg.push(   instance["evolutions"][i][100]["average-distance"]   );
                }

                console.log(experiment_y_best);
                console.log(experiment_y_worst);
                console.log(experiment_y_avg);
                console.log(experiment_x);

                var experiment_plotly =
                    [
                        {
                            x: experiment_x,
                            y: experiment_y_best,
                            mode: 'lines+markers',
                            fill: 'tonexty',
                            //type: 'bar',
                            name: 'best',
                        },
                        {
                            x: experiment_x,
                            y: experiment_y_worst,
                            mode: 'lines+markers',
                            fill: 'tonexty',
                            //type: 'bar',
                            name: 'worst',
                        },
                        {
                            x: experiment_x,
                            y: experiment_y_avg,
                            mode: 'lines+markers',
                            fill: 'tonexty',
                            //type: 'bar',
                            name: 'average',
                        }
                    ];


                Plotly.newPlot(   $(".figure.distance.trend")[0], experiment_plotly, {}, {responsive: true}   );

                // 重绘evolution -------------------------------------------------------------------------------

                // 重绘generation ------------------------------------------------------------------------------

                // 重绘individual ------------------------------------------------------------------------------

            },
        },
    }
);

function parseCoords(map)
{
    var plotly_coords = [ [],[],[] ];
    for(let city of map)
    {
        plotly_coords[0].push(city[0]);    //id
        plotly_coords[1].push(city[1]);    //x-axis
        plotly_coords[2].push(city[2]);    //y-axis
    }
    return plotly_coords;
}

var plain_map_WesternSahara = parseCoords(WesternSahara);
var plain_map_Uruguay = parseCoords(Uruguay);
var plain_map_Canada = parseCoords(Canada);




//
