/* jshint esversion: 6 */

var drawExperiment = function()
{
    // 只用画一次，experiment页 //
};
