let advanced_Canada = {};
