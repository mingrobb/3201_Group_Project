let advanced_WesternSahara = {
    "description": {
        "instance_name": "none",
        "algorithm": "none",
        "city_all": 29,
        "evolution_all": 10,
        "generation_all": 100,
        "generation_size": 300,
    },
    "evolutions": [
        [
            [{
                "time_cost": 0
            }], {
                "best-individual-sequence": [27, 24, 15, 12, 23, 20, 29, 26, 22, 5, 3, 14, 19, 11, 18, 28, 21, 8, 1, 10, 4, 2, 6, 7, 17, 9, 13, 25, 16],
                "best-individual-distance": 79451.85555633319,
                "worst-individual-sequence": [18, 3, 17, 15, 14, 27, 2, 9, 22, 10, 5, 23, 28, 11, 24, 4, 29, 16, 13, 26, 12, 20, 21, 8, 6, 1, 25, 7, 19],
                "worst-individual-distance": 120938.64638596744,
                "average-distance": 106806.28917392358,
                "individual-distances": []
            }, {
                "best-individual-sequence": [22, 16, 15, 20, 12, 5, 2, 4, 11, 24, 1, 6, 10, 17, 26, 18, 19, 27, 13, 8, 7, 3, 9, 21, 29, 14, 25, 23, 28],
                "best-individual-distance": 75686.88304487214,
                "worst-individual-sequence": [18, 29, 15, 4, 14, 20, 5, 25, 7, 12, 11, 26, 17, 2, 28, 24, 19, 9, 10, 23, 22, 27, 1, 16, 21, 3, 8, 6, 13],
                "worst-individual-distance": 116154.95888958128,
                "average-distance": 104176.1285710767,
                "individual-distances": []
            }, {
                "best-individual-sequence": [6, 3, 13, 19, 17, 8, 12, 14, 21, 29, 16, 7, 9, 15, 20, 24, 23, 18, 26, 25, 22, 28, 27, 11, 10, 4, 5, 2, 1],
                "best-individual-distance": 74332.64477025162,
                "worst-individual-sequence": [5, 15, 26, 17, 21, 2, 27, 20, 18, 24, 4, 16, 9, 11, 1, 13, 8, 25, 7, 23, 22, 3, 14, 28, 19, 12, 6, 10, 29],
                "worst-individual-distance": 112965.73859795475,
                "average-distance": 101964.37173498237,
                "individual-distances": []
            }, {
                "best-individual-sequence": [6, 3, 13, 19, 17, 8, 12, 14, 21, 29, 16, 7, 9, 15, 20, 24, 23, 18, 26, 25, 22, 28, 27, 11, 10, 4, 5, 2, 1],
                "best-individual-distance": 74332.64477025162,
                "worst-individual-sequence": [20, 19, 7, 24, 29, 27, 13, 28, 22, 15, 14, 3, 26, 16, 4, 9, 6, 2, 21, 8, 1, 18, 5, 17, 11, 25, 12, 10, 23],
                "worst-individual-distance": 110309.30654335636,
                "average-distance": 99659.20835971065,
                "individual-distances": []
            }, {
                "best-individual-sequence": [24, 18, 17, 20, 9, 7, 2, 1, 6, 8, 19, 22, 23, 13, 11, 10, 27, 21, 29, 14, 28, 16, 25, 26, 4, 12, 15, 5, 3],
                "best-individual-distance": 71592.80173166197,
                "worst-individual-sequence": [23, 5, 22, 29, 27, 9, 16, 3, 14, 28, 25, 20, 13, 8, 7, 12, 21, 2, 11, 15, 24, 17, 6, 1, 18, 10, 26, 19, 4],
                "worst-individual-distance": 107297.60837263413,
                "average-distance": 97578.21740021088,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 9, 3, 25, 4, 8, 28, 15, 21, 23, 27, 14, 29, 22, 18, 24, 26, 7, 17, 20, 19, 2, 16, 13, 5, 1, 6, 12, 11],
                "best-individual-distance": 69158.5809758807,
                "worst-individual-sequence": [2, 4, 10, 29, 21, 11, 15, 13, 7, 12, 26, 19, 3, 16, 8, 5, 14, 23, 17, 1, 25, 24, 6, 9, 28, 18, 20, 27, 22],
                "worst-individual-distance": 104852.21118401061,
                "average-distance": 95558.801453708,
                "individual-distances": []
            }, {
                "best-individual-sequence": [7, 23, 15, 10, 11, 26, 21, 18, 29, 24, 28, 20, 16, 27, 25, 19, 17, 13, 14, 9, 12, 8, 4, 5, 6, 22, 3, 2, 1],
                "best-individual-distance": 67105.09332124883,
                "worst-individual-sequence": [23, 11, 3, 4, 8, 18, 9, 29, 28, 6, 2, 19, 24, 20, 25, 12, 13, 15, 5, 27, 10, 16, 26, 21, 7, 1, 17, 22, 14],
                "worst-individual-distance": 102913.69543701905,
                "average-distance": 93653.6870024812,
                "individual-distances": []
            }, {
                "best-individual-sequence": [7, 23, 15, 10, 11, 26, 21, 18, 29, 24, 28, 20, 16, 27, 25, 19, 17, 13, 14, 9, 12, 8, 4, 5, 6, 22, 3, 2, 1],
                "best-individual-distance": 67105.09332124883,
                "worst-individual-sequence": [12, 4, 2, 5, 16, 15, 7, 28, 11, 19, 14, 10, 9, 13, 25, 18, 22, 6, 21, 17, 20, 24, 26, 23, 8, 3, 1, 29, 27],
                "worst-individual-distance": 100966.86252470606,
                "average-distance": 91888.33480107631,
                "individual-distances": []
            }, {
                "best-individual-sequence": [22, 21, 8, 9, 3, 4, 1, 11, 12, 28, 20, 27, 26, 16, 29, 5, 2, 6, 10, 7, 15, 19, 14, 24, 25, 17, 13, 18, 23],
                "best-individual-distance": 62354.32239388287,
                "worst-individual-sequence": [8, 3, 9, 14, 22, 13, 25, 20, 18, 28, 17, 15, 16, 2, 7, 6, 11, 23, 24, 29, 27, 10, 26, 1, 21, 12, 19, 5, 4],
                "worst-individual-distance": 98993.59289059899,
                "average-distance": 90119.49136128068,
                "individual-distances": []
            }, {
                "best-individual-sequence": [22, 21, 8, 9, 3, 4, 1, 11, 12, 28, 20, 27, 26, 16, 29, 5, 2, 6, 10, 7, 15, 19, 14, 24, 25, 17, 13, 18, 23],
                "best-individual-distance": 62354.32239388287,
                "worst-individual-sequence": [29, 3, 6, 23, 14, 16, 27, 26, 22, 20, 17, 18, 13, 12, 10, 19, 8, 4, 21, 7, 11, 25, 9, 1, 15, 5, 2, 24, 28],
                "worst-individual-distance": 96997.87463055912,
                "average-distance": 88397.58274444229,
                "individual-distances": []
            }, {
                "best-individual-sequence": [22, 21, 8, 9, 3, 4, 1, 11, 12, 28, 20, 27, 26, 16, 29, 5, 2, 6, 10, 7, 15, 19, 14, 24, 25, 17, 13, 18, 23],
                "best-individual-distance": 62354.32239388287,
                "worst-individual-sequence": [8, 6, 23, 7, 12, 9, 1, 17, 13, 10, 5, 28, 24, 16, 25, 4, 11, 29, 26, 21, 22, 2, 3, 19, 18, 15, 14, 20, 27],
                "worst-individual-distance": 95137.79095988799,
                "average-distance": 86783.128541026,
                "individual-distances": []
            }, {
                "best-individual-sequence": [22, 21, 8, 9, 3, 4, 1, 11, 12, 28, 20, 27, 26, 16, 29, 5, 2, 6, 10, 7, 15, 19, 14, 24, 25, 17, 13, 18, 23],
                "best-individual-distance": 62354.32239388287,
                "worst-individual-sequence": [2, 1, 19, 23, 16, 15, 17, 18, 25, 13, 11, 27, 21, 14, 10, 8, 7, 9, 28, 12, 4, 5, 22, 29, 20, 24, 6, 26, 3],
                "worst-individual-distance": 93433.22616738737,
                "average-distance": 85143.57592021125,
                "individual-distances": []
            }, {
                "best-individual-sequence": [22, 21, 8, 9, 3, 4, 1, 11, 12, 28, 20, 27, 26, 16, 29, 5, 2, 6, 10, 7, 15, 19, 14, 24, 25, 17, 13, 18, 23],
                "best-individual-distance": 62354.32239388287,
                "worst-individual-sequence": [8, 5, 22, 27, 15, 19, 11, 24, 16, 10, 4, 2, 6, 9, 28, 7, 3, 1, 20, 21, 13, 23, 26, 25, 12, 18, 17, 29, 14],
                "worst-individual-distance": 91774.64186220597,
                "average-distance": 83810.26796169739,
                "individual-distances": []
            }, {
                "best-individual-sequence": [22, 21, 8, 9, 3, 4, 1, 11, 12, 28, 20, 27, 26, 16, 29, 5, 2, 6, 10, 7, 15, 19, 14, 24, 25, 17, 13, 18, 23],
                "best-individual-distance": 62354.32239388287,
                "worst-individual-sequence": [28, 23, 14, 16, 25, 29, 3, 9, 7, 8, 12, 2, 19, 27, 21, 1, 6, 22, 11, 15, 18, 26, 5, 10, 17, 20, 13, 4, 24],
                "worst-individual-distance": 90115.0391131991,
                "average-distance": 82412.15678324417,
                "individual-distances": []
            }, {
                "best-individual-sequence": [18, 15, 24, 10, 16, 25, 29, 17, 6, 3, 9, 7, 8, 13, 12, 2, 5, 1, 27, 21, 19, 4, 11, 14, 20, 22, 23, 28, 26],
                "best-individual-distance": 60463.70191532077,
                "worst-individual-sequence": [6, 8, 11, 3, 15, 23, 12, 4, 21, 26, 10, 24, 16, 27, 25, 19, 17, 14, 13, 18, 9, 20, 22, 7, 1, 28, 29, 5, 2],
                "worst-individual-distance": 88697.63688183067,
                "average-distance": 81048.88091643441,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 24, 27, 16, 22, 28, 19, 21, 23, 29, 17, 3, 7, 9, 8, 5, 1, 10, 6, 2, 12, 11, 13, 4, 14, 15, 18, 20, 25],
                "best-individual-distance": 52398.46224851155,
                "worst-individual-sequence": [14, 9, 18, 3, 1, 23, 28, 24, 7, 2, 10, 8, 19, 5, 6, 22, 15, 12, 26, 21, 29, 16, 27, 25, 20, 13, 4, 11, 17],
                "worst-individual-distance": 87126.69188432881,
                "average-distance": 79622.4989583492,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 24, 27, 16, 22, 28, 19, 21, 23, 29, 17, 3, 7, 9, 8, 5, 1, 10, 6, 2, 12, 11, 13, 4, 14, 15, 18, 20, 25],
                "best-individual-distance": 52398.46224851155,
                "worst-individual-sequence": [21, 15, 25, 16, 26, 22, 23, 13, 12, 11, 5, 8, 9, 10, 3, 19, 7, 14, 24, 1, 2, 4, 29, 28, 27, 6, 17, 18, 20],
                "worst-individual-distance": 85585.29364658143,
                "average-distance": 78134.46565855829,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 24, 27, 16, 22, 28, 19, 21, 23, 29, 17, 3, 7, 9, 8, 5, 1, 10, 6, 2, 12, 11, 13, 4, 14, 15, 18, 20, 25],
                "best-individual-distance": 52398.46224851155,
                "worst-individual-sequence": [10, 9, 3, 25, 4, 8, 28, 15, 21, 23, 27, 14, 29, 22, 18, 24, 26, 7, 17, 20, 19, 2, 16, 13, 5, 1, 6, 12, 11],
                "worst-individual-distance": 84116.69217196401,
                "average-distance": 76976.86556505652,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 24, 27, 16, 22, 28, 19, 21, 23, 29, 17, 3, 7, 9, 8, 5, 1, 10, 6, 2, 12, 11, 13, 4, 14, 15, 18, 20, 25],
                "best-individual-distance": 52398.46224851155,
                "worst-individual-sequence": [4, 26, 16, 14, 28, 20, 8, 19, 22, 23, 29, 15, 10, 21, 17, 2, 9, 5, 12, 13, 7, 1, 3, 6, 11, 25, 24, 27, 18],
                "worst-individual-distance": 82827.52795240957,
                "average-distance": 75807.25857954621,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 24, 27, 16, 22, 28, 19, 21, 23, 29, 17, 3, 7, 9, 8, 5, 1, 10, 6, 2, 12, 11, 13, 4, 14, 15, 18, 20, 25],
                "best-individual-distance": 52398.46224851155,
                "worst-individual-sequence": [29, 19, 1, 7, 8, 15, 21, 12, 11, 4, 5, 6, 22, 28, 23, 25, 27, 10, 2, 13, 9, 3, 16, 14, 26, 17, 20, 18, 24],
                "worst-individual-distance": 81592.26695742556,
                "average-distance": 74838.34214249163,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 24, 27, 16, 22, 28, 19, 21, 23, 29, 17, 3, 7, 9, 8, 5, 1, 10, 6, 2, 12, 11, 13, 4, 14, 15, 18, 20, 25],
                "best-individual-distance": 52398.46224851155,
                "worst-individual-sequence": [24, 28, 15, 21, 23, 27, 14, 29, 18, 4, 22, 8, 5, 2, 13, 11, 26, 17, 20, 19, 7, 1, 6, 12, 10, 9, 3, 25, 16],
                "worst-individual-distance": 79991.88838594971,
                "average-distance": 73676.96887022082,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 24, 27, 16, 22, 28, 19, 21, 23, 29, 17, 3, 7, 9, 8, 5, 1, 10, 6, 2, 12, 11, 13, 4, 14, 15, 18, 20, 25],
                "best-individual-distance": 52398.46224851155,
                "worst-individual-sequence": [18, 19, 5, 2, 28, 16, 25, 14, 13, 7, 23, 11, 10, 27, 21, 29, 15, 22, 17, 20, 26, 24, 8, 9, 4, 1, 3, 6, 12],
                "worst-individual-distance": 78777.2988306007,
                "average-distance": 72581.50454313982,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 24, 27, 16, 22, 28, 19, 21, 23, 29, 17, 3, 7, 9, 8, 5, 1, 10, 6, 2, 12, 11, 13, 4, 14, 15, 18, 20, 25],
                "best-individual-distance": 52398.46224851155,
                "worst-individual-sequence": [7, 2, 1, 5, 29, 22, 6, 4, 26, 28, 24, 27, 12, 17, 19, 18, 21, 23, 16, 8, 20, 25, 15, 10, 14, 13, 11, 3, 9],
                "worst-individual-distance": 77581.00131982015,
                "average-distance": 71668.26172682577,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 24, 27, 16, 22, 28, 19, 21, 23, 29, 17, 3, 7, 9, 8, 5, 1, 10, 6, 2, 12, 11, 13, 4, 14, 15, 18, 20, 25],
                "best-individual-distance": 52398.46224851155,
                "worst-individual-sequence": [27, 24, 15, 12, 23, 20, 29, 26, 22, 5, 3, 14, 19, 11, 18, 28, 21, 8, 1, 10, 4, 2, 6, 7, 17, 9, 13, 25, 16],
                "worst-individual-distance": 76721.71950623656,
                "average-distance": 70747.5109884931,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 24, 27, 16, 22, 28, 19, 21, 23, 29, 17, 3, 7, 9, 8, 5, 1, 10, 6, 2, 12, 11, 13, 4, 14, 15, 18, 20, 25],
                "best-individual-distance": 52398.46224851155,
                "worst-individual-sequence": [22, 21, 29, 20, 3, 9, 18, 14, 19, 26, 16, 25, 7, 11, 6, 12, 8, 17, 23, 10, 13, 15, 28, 24, 27, 4, 2, 1, 5],
                "worst-individual-distance": 75747.33994676988,
                "average-distance": 69779.00076358084,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 24, 27, 16, 22, 28, 19, 21, 23, 29, 17, 3, 7, 9, 8, 5, 1, 10, 6, 2, 12, 11, 13, 4, 14, 15, 18, 20, 25],
                "best-individual-distance": 52398.46224851155,
                "worst-individual-sequence": [25, 14, 18, 10, 4, 11, 17, 27, 26, 24, 1, 6, 5, 8, 2, 23, 19, 15, 20, 13, 7, 3, 9, 21, 29, 12, 16, 28, 22],
                "worst-individual-distance": 74882.65490105892,
                "average-distance": 69024.44280549744,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 24, 27, 16, 22, 28, 19, 21, 23, 29, 17, 3, 7, 9, 8, 5, 1, 10, 6, 2, 12, 11, 13, 4, 14, 15, 18, 20, 25],
                "best-individual-distance": 52398.46224851155,
                "worst-individual-sequence": [10, 13, 12, 1, 4, 8, 2, 17, 23, 26, 15, 27, 16, 22, 28, 25, 20, 21, 24, 29, 3, 7, 9, 11, 6, 5, 19, 18, 14],
                "worst-individual-distance": 73829.41203681337,
                "average-distance": 68200.9145484981,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 24, 27, 16, 22, 28, 19, 21, 23, 29, 17, 3, 7, 9, 8, 5, 1, 10, 6, 2, 12, 11, 13, 4, 14, 15, 18, 20, 25],
                "best-individual-distance": 52398.46224851155,
                "worst-individual-sequence": [7, 2, 4, 14, 5, 23, 21, 18, 29, 24, 28, 20, 16, 27, 25, 19, 17, 1, 6, 10, 22, 11, 15, 26, 12, 8, 13, 9, 3],
                "worst-individual-distance": 72901.7029171963,
                "average-distance": 67452.22077118902,
                "individual-distances": []
            }, {
                "best-individual-sequence": [2, 6, 3, 10, 13, 7, 9, 20, 16, 25, 27, 14, 29, 22, 18, 23, 21, 26, 17, 24, 28, 19, 15, 12, 5, 11, 8, 4, 1],
                "best-individual-distance": 51220.9741125646,
                "worst-individual-sequence": [3, 6, 5, 25, 24, 28, 8, 19, 22, 23, 13, 11, 10, 27, 21, 29, 26, 17, 16, 14, 15, 18, 20, 4, 1, 2, 7, 12, 9],
                "worst-individual-distance": 71969.75948393394,
                "average-distance": 66757.75676101494,
                "individual-distances": []
            }, {
                "best-individual-sequence": [2, 6, 3, 10, 13, 7, 9, 20, 16, 25, 27, 14, 29, 22, 18, 23, 21, 26, 17, 24, 28, 19, 15, 12, 5, 11, 8, 4, 1],
                "best-individual-distance": 51220.9741125646,
                "worst-individual-sequence": [25, 16, 24, 28, 15, 21, 12, 14, 20, 23, 27, 29, 22, 18, 4, 8, 26, 17, 19, 2, 7, 13, 5, 1, 6, 11, 10, 9, 3],
                "worst-individual-distance": 71083.78360390093,
                "average-distance": 66082.70281625542,
                "individual-distances": []
            }, {
                "best-individual-sequence": [2, 6, 3, 10, 13, 7, 9, 20, 16, 25, 27, 14, 29, 22, 18, 23, 21, 26, 17, 24, 28, 19, 15, 12, 5, 11, 8, 4, 1],
                "best-individual-distance": 51220.9741125646,
                "worst-individual-sequence": [4, 8, 29, 16, 9, 13, 10, 15, 14, 19, 22, 28, 25, 27, 20, 23, 21, 26, 24, 11, 3, 7, 18, 6, 2, 1, 12, 17, 5],
                "worst-individual-distance": 70232.76721437683,
                "average-distance": 65470.53404172713,
                "individual-distances": []
            }, {
                "best-individual-sequence": [2, 6, 3, 10, 13, 7, 9, 20, 16, 25, 27, 14, 29, 22, 18, 23, 21, 26, 17, 24, 28, 19, 15, 12, 5, 11, 8, 4, 1],
                "best-individual-distance": 51220.9741125646,
                "worst-individual-sequence": [16, 28, 25, 17, 21, 23, 27, 29, 22, 18, 10, 12, 9, 24, 14, 8, 2, 5, 11, 6, 15, 19, 13, 7, 4, 1, 3, 20, 26],
                "worst-individual-distance": 69598.0464423338,
                "average-distance": 64938.279884377895,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 4, 2, 27, 25, 16, 24, 22, 28, 20, 23, 21, 29, 18, 19, 26, 17, 14, 13, 15, 1, 6, 8, 12, 11, 10, 9, 3, 7],
                "best-individual-distance": 46368.27541051737,
                "worst-individual-sequence": [10, 9, 3, 21, 23, 29, 22, 18, 4, 8, 20, 19, 13, 6, 7, 17, 16, 14, 15, 28, 24, 25, 27, 26, 2, 1, 5, 12, 11],
                "worst-individual-distance": 68987.47772333078,
                "average-distance": 64337.63088593715,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 4, 2, 27, 25, 16, 24, 22, 28, 20, 23, 21, 29, 18, 19, 26, 17, 14, 13, 15, 1, 6, 8, 12, 11, 10, 9, 3, 7],
                "best-individual-distance": 46368.27541051737,
                "worst-individual-sequence": [15, 24, 16, 25, 29, 17, 3, 9, 7, 8, 13, 21, 19, 14, 12, 2, 5, 1, 6, 4, 27, 10, 11, 26, 20, 22, 23, 28, 18],
                "worst-individual-distance": 68297.96901748383,
                "average-distance": 63759.54436200801,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 4, 2, 27, 25, 16, 24, 22, 28, 20, 23, 21, 29, 18, 19, 26, 17, 14, 13, 15, 1, 6, 8, 12, 11, 10, 9, 3, 7],
                "best-individual-distance": 46368.27541051737,
                "worst-individual-sequence": [25, 18, 27, 29, 17, 7, 4, 10, 2, 5, 9, 3, 6, 1, 13, 19, 24, 15, 12, 8, 11, 14, 20, 22, 23, 28, 26, 21, 16],
                "worst-individual-distance": 67602.30569725524,
                "average-distance": 63231.39163867249,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 4, 2, 27, 25, 16, 24, 22, 28, 20, 23, 21, 29, 18, 19, 26, 17, 14, 13, 15, 1, 6, 8, 12, 11, 10, 9, 3, 7],
                "best-individual-distance": 46368.27541051737,
                "worst-individual-sequence": [23, 7, 5, 2, 4, 3, 11, 1, 6, 10, 8, 13, 22, 9, 21, 29, 26, 17, 16, 14, 15, 28, 24, 25, 27, 12, 20, 19, 18],
                "worst-individual-distance": 66949.41533941614,
                "average-distance": 62765.10649248521,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 4, 2, 27, 25, 16, 24, 22, 28, 20, 23, 21, 29, 18, 19, 26, 17, 14, 13, 15, 1, 6, 8, 12, 11, 10, 9, 3, 7],
                "best-individual-distance": 46368.27541051737,
                "worst-individual-sequence": [12, 7, 24, 26, 16, 29, 22, 28, 17, 21, 19, 20, 25, 18, 15, 23, 27, 13, 4, 8, 11, 14, 10, 2, 5, 9, 3, 6, 1],
                "worst-individual-distance": 66420.97194848461,
                "average-distance": 62325.33858873141,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 4, 2, 27, 25, 16, 24, 22, 28, 20, 23, 21, 29, 18, 19, 26, 17, 14, 13, 15, 1, 6, 8, 12, 11, 10, 9, 3, 7],
                "best-individual-distance": 46368.27541051737,
                "worst-individual-sequence": [17, 21, 19, 22, 26, 18, 15, 23, 7, 24, 28, 20, 16, 27, 25, 13, 4, 8, 11, 14, 10, 2, 5, 9, 3, 6, 1, 12, 29],
                "worst-individual-distance": 65828.39165889604,
                "average-distance": 61810.0434077807,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 4, 2, 27, 25, 16, 24, 22, 28, 20, 23, 21, 29, 18, 19, 26, 17, 14, 13, 15, 1, 6, 8, 12, 11, 10, 9, 3, 7],
                "best-individual-distance": 46368.27541051737,
                "worst-individual-sequence": [22, 25, 27, 24, 16, 21, 23, 4, 7, 5, 10, 3, 26, 28, 20, 29, 18, 17, 15, 13, 9, 12, 11, 6, 14, 19, 8, 1, 2],
                "worst-individual-distance": 65295.58835346226,
                "average-distance": 61334.798325957956,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 4, 2, 27, 25, 16, 24, 22, 28, 20, 23, 21, 29, 18, 19, 26, 17, 14, 13, 15, 1, 6, 8, 12, 11, 10, 9, 3, 7],
                "best-individual-distance": 46368.27541051737,
                "worst-individual-sequence": [3, 11, 10, 8, 28, 15, 26, 16, 4, 1, 2, 6, 5, 21, 23, 29, 22, 17, 25, 27, 20, 18, 24, 9, 7, 13, 19, 14, 12],
                "worst-individual-distance": 64701.98772576959,
                "average-distance": 60858.30925778787,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 4, 2, 27, 25, 16, 24, 22, 28, 20, 23, 21, 29, 18, 19, 26, 17, 14, 13, 15, 1, 6, 8, 12, 11, 10, 9, 3, 7],
                "best-individual-distance": 46368.27541051737,
                "worst-individual-sequence": [6, 11, 20, 13, 10, 9, 7, 1, 16, 25, 27, 14, 29, 22, 18, 23, 21, 26, 17, 24, 28, 19, 15, 12, 5, 2, 4, 3, 8],
                "worst-individual-distance": 64227.94597555215,
                "average-distance": 60487.01279991099,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 4, 2, 27, 25, 16, 24, 22, 28, 20, 23, 21, 29, 18, 19, 26, 17, 14, 13, 15, 1, 6, 8, 12, 11, 10, 9, 3, 7],
                "best-individual-distance": 46368.27541051737,
                "worst-individual-sequence": [18, 15, 12, 5, 2, 4, 3, 11, 1, 6, 22, 20, 17, 14, 28, 16, 29, 23, 10, 8, 13, 9, 7, 19, 25, 24, 26, 27, 21],
                "worst-individual-distance": 63725.079961870106,
                "average-distance": 60109.87971386516,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 4, 2, 27, 25, 16, 24, 22, 28, 20, 23, 21, 29, 18, 19, 26, 17, 14, 13, 15, 1, 6, 8, 12, 11, 10, 9, 3, 7],
                "best-individual-distance": 46368.27541051737,
                "worst-individual-sequence": [3, 4, 8, 28, 29, 26, 19, 22, 23, 13, 11, 10, 17, 16, 14, 24, 25, 21, 12, 15, 27, 18, 20, 9, 7, 2, 1, 6, 5],
                "worst-individual-distance": 63461.092659045535,
                "average-distance": 59753.55814507973,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 4, 2, 27, 25, 16, 24, 22, 28, 20, 23, 21, 29, 18, 19, 26, 17, 14, 13, 15, 1, 6, 8, 12, 11, 10, 9, 3, 7],
                "best-individual-distance": 46368.27541051737,
                "worst-individual-sequence": [16, 22, 8, 4, 10, 5, 1, 2, 6, 7, 3, 28, 19, 25, 27, 20, 23, 21, 26, 13, 9, 24, 29, 17, 18, 15, 12, 11, 14],
                "worst-individual-distance": 62945.0356991246,
                "average-distance": 59373.74794811969,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 4, 2, 27, 25, 16, 24, 22, 28, 20, 23, 21, 29, 18, 19, 26, 17, 14, 13, 15, 1, 6, 8, 12, 11, 10, 9, 3, 7],
                "best-individual-distance": 46368.27541051737,
                "worst-individual-sequence": [11, 10, 4, 3, 29, 1, 2, 6, 5, 9, 13, 12, 20, 21, 26, 17, 16, 14, 28, 24, 25, 27, 8, 7, 18, 15, 19, 23, 22],
                "worst-individual-distance": 62532.972029986755,
                "average-distance": 58935.22387854087,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 4, 2, 27, 25, 16, 24, 22, 28, 20, 23, 21, 29, 18, 19, 26, 17, 14, 13, 15, 1, 6, 8, 12, 11, 10, 9, 3, 7],
                "best-individual-distance": 46368.27541051737,
                "worst-individual-sequence": [6, 5, 4, 12, 17, 19, 18, 16, 14, 15, 10, 8, 13, 22, 28, 25, 27, 20, 23, 21, 26, 24, 7, 29, 3, 9, 2, 1, 11],
                "worst-individual-distance": 62091.79823646779,
                "average-distance": 58542.73346503905,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 29, 17, 3, 9, 8, 11, 1, 2, 6, 5, 10, 7, 4, 12, 13, 14, 20, 16, 15, 19, 18, 26, 25, 24, 27, 22, 28, 21],
                "best-individual-distance": 46190.86710437129,
                "worst-individual-sequence": [5, 2, 4, 3, 8, 13, 22, 11, 1, 6, 10, 28, 25, 27, 21, 26, 24, 20, 17, 29, 14, 16, 9, 7, 15, 19, 23, 18, 12],
                "worst-individual-distance": 61727.29348177883,
                "average-distance": 58163.65358225874,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 29, 17, 3, 9, 8, 11, 1, 2, 6, 5, 10, 7, 4, 12, 13, 14, 20, 16, 15, 19, 18, 26, 25, 24, 27, 22, 28, 21],
                "best-individual-distance": 46190.86710437129,
                "worst-individual-sequence": [15, 4, 6, 5, 1, 2, 11, 10, 9, 16, 22, 28, 17, 7, 3, 13, 14, 25, 24, 21, 23, 12, 8, 29, 18, 20, 27, 26, 19],
                "worst-individual-distance": 61338.526798535684,
                "average-distance": 57803.41595218304,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 29, 17, 3, 9, 8, 11, 1, 2, 6, 5, 10, 7, 4, 12, 13, 14, 20, 16, 15, 19, 18, 26, 25, 24, 27, 22, 28, 21],
                "best-individual-distance": 46190.86710437129,
                "worst-individual-sequence": [8, 4, 3, 6, 5, 13, 12, 18, 20, 23, 22, 11, 10, 9, 21, 29, 26, 17, 16, 14, 15, 28, 24, 25, 27, 19, 2, 1, 7],
                "worst-individual-distance": 60890.68810477917,
                "average-distance": 57470.58474029514,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 29, 17, 3, 9, 8, 11, 1, 2, 6, 5, 10, 7, 4, 12, 13, 14, 20, 16, 15, 19, 18, 26, 25, 24, 27, 22, 28, 21],
                "best-individual-distance": 46190.86710437129,
                "worst-individual-sequence": [11, 10, 9, 7, 12, 26, 25, 24, 27, 5, 8, 20, 18, 28, 22, 19, 17, 21, 23, 16, 29, 14, 13, 3, 4, 15, 6, 1, 2],
                "worst-individual-distance": 60511.81878409229,
                "average-distance": 57148.51743025361,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 29, 17, 3, 9, 8, 11, 1, 2, 6, 5, 10, 7, 4, 12, 13, 14, 20, 16, 15, 19, 18, 26, 25, 24, 27, 22, 28, 21],
                "best-individual-distance": 46190.86710437129,
                "worst-individual-sequence": [9, 7, 3, 11, 14, 19, 17, 1, 6, 10, 8, 13, 22, 28, 25, 27, 20, 23, 21, 26, 24, 29, 16, 18, 15, 12, 5, 2, 4],
                "worst-individual-distance": 60143.41577903846,
                "average-distance": 56769.027801588694,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 29, 17, 3, 9, 8, 11, 1, 2, 6, 5, 10, 7, 4, 12, 13, 14, 20, 16, 15, 19, 18, 26, 25, 24, 27, 22, 28, 21],
                "best-individual-distance": 46190.86710437129,
                "worst-individual-sequence": [12, 9, 27, 25, 14, 13, 29, 26, 24, 16, 7, 20, 23, 22, 28, 21, 19, 17, 18, 3, 4, 1, 2, 6, 8, 15, 5, 11, 10],
                "worst-individual-distance": 59799.200337085495,
                "average-distance": 56439.35506227227,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 20, 4, 8, 13, 7, 9, 3, 16, 25, 27, 14, 29, 22, 18, 23, 21, 26, 17, 24, 28, 19, 15, 12, 5, 1, 2, 6, 11],
                "best-individual-distance": 45333.49766239732,
                "worst-individual-sequence": [26, 3, 14, 16, 24, 11, 8, 4, 10, 1, 2, 6, 5, 9, 13, 12, 7, 20, 23, 22, 28, 21, 19, 17, 18, 15, 25, 27, 29],
                "worst-individual-distance": 59427.88761558593,
                "average-distance": 56099.55221125538,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 20, 4, 8, 13, 7, 9, 3, 16, 25, 27, 14, 29, 22, 18, 23, 21, 26, 17, 24, 28, 19, 15, 12, 5, 1, 2, 6, 11],
                "best-individual-distance": 45333.49766239732,
                "worst-individual-sequence": [27, 12, 11, 14, 16, 24, 3, 8, 9, 4, 13, 10, 5, 1, 2, 6, 7, 20, 23, 22, 28, 21, 19, 17, 18, 15, 29, 26, 25],
                "worst-individual-distance": 59061.43297257677,
                "average-distance": 55760.866306081334,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 3, 9, 8, 11, 10, 2, 1, 6, 5, 7, 4, 12, 13, 14, 20, 16, 19, 15, 18, 26, 25, 24, 27, 22, 28, 21, 23, 29],
                "best-individual-distance": 42874.59367225057,
                "worst-individual-sequence": [11, 10, 20, 16, 14, 29, 22, 23, 21, 26, 17, 19, 15, 12, 5, 2, 4, 28, 24, 25, 27, 18, 9, 3, 1, 6, 8, 13, 7],
                "worst-individual-distance": 58698.91666350265,
                "average-distance": 55407.13673358245,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 3, 9, 8, 11, 10, 2, 1, 6, 5, 7, 4, 12, 13, 14, 20, 16, 19, 15, 18, 26, 25, 24, 27, 22, 28, 21, 23, 29],
                "best-individual-distance": 42874.59367225057,
                "worst-individual-sequence": [5, 8, 20, 19, 22, 23, 13, 11, 10, 28, 27, 15, 18, 21, 29, 26, 17, 16, 14, 24, 25, 9, 7, 3, 6, 1, 2, 4, 12],
                "worst-individual-distance": 58264.96962788948,
                "average-distance": 55110.84332623262,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 3, 9, 8, 11, 10, 2, 1, 6, 5, 7, 4, 12, 13, 14, 20, 16, 19, 15, 18, 26, 25, 24, 27, 22, 28, 21, 23, 29],
                "best-individual-distance": 42874.59367225057,
                "worst-individual-sequence": [3, 11, 8, 13, 28, 21, 23, 29, 25, 20, 26, 10, 5, 1, 2, 6, 22, 17, 27, 24, 16, 18, 14, 9, 7, 19, 15, 12, 4],
                "worst-individual-distance": 58037.560306496416,
                "average-distance": 54856.47858723567,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 3, 9, 8, 11, 10, 2, 1, 6, 5, 7, 4, 12, 13, 14, 20, 16, 19, 15, 18, 26, 25, 24, 27, 22, 28, 21, 23, 29],
                "best-individual-distance": 42874.59367225057,
                "worst-individual-sequence": [4, 11, 1, 6, 10, 8, 13, 22, 28, 27, 20, 23, 21, 29, 26, 17, 16, 14, 24, 25, 3, 15, 7, 18, 9, 19, 12, 5, 2],
                "worst-individual-distance": 57678.79882804572,
                "average-distance": 54563.144835480845,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 3, 9, 8, 11, 10, 2, 1, 6, 5, 7, 4, 12, 13, 14, 20, 16, 19, 15, 18, 26, 25, 24, 27, 22, 28, 21, 23, 29],
                "best-individual-distance": 42874.59367225057,
                "worst-individual-sequence": [5, 7, 8, 20, 19, 22, 23, 13, 11, 10, 21, 29, 26, 17, 16, 14, 15, 28, 24, 25, 27, 18, 9, 3, 6, 1, 2, 4, 12],
                "worst-individual-distance": 57400.13059383484,
                "average-distance": 54273.5435212489,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 3, 9, 8, 11, 10, 2, 1, 6, 5, 7, 4, 12, 13, 14, 20, 16, 19, 15, 18, 26, 25, 24, 27, 22, 28, 21, 23, 29],
                "best-individual-distance": 42874.59367225057,
                "worst-individual-sequence": [4, 11, 10, 20, 27, 26, 16, 29, 28, 1, 2, 6, 5, 9, 13, 12, 7, 14, 15, 19, 24, 25, 17, 18, 23, 22, 21, 8, 3],
                "worst-individual-distance": 57097.86958672175,
                "average-distance": 53930.8217015855,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 3, 9, 8, 11, 10, 2, 1, 6, 5, 7, 4, 12, 13, 14, 20, 16, 19, 15, 18, 26, 25, 24, 27, 22, 28, 21, 23, 29],
                "best-individual-distance": 42874.59367225057,
                "worst-individual-sequence": [1, 2, 6, 10, 13, 8, 4, 22, 28, 27, 20, 23, 21, 29, 26, 17, 16, 14, 24, 25, 18, 15, 7, 3, 9, 19, 12, 5, 11],
                "worst-individual-distance": 56862.6690989386,
                "average-distance": 53649.6786555177,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 3, 9, 8, 11, 10, 2, 1, 6, 5, 7, 4, 12, 13, 14, 20, 16, 19, 15, 18, 26, 25, 24, 27, 22, 28, 21, 23, 29],
                "best-individual-distance": 42874.59367225057,
                "worst-individual-sequence": [11, 6, 10, 8, 9, 7, 13, 22, 28, 25, 27, 23, 21, 29, 14, 16, 18, 26, 17, 24, 20, 19, 15, 12, 5, 2, 4, 3, 1],
                "worst-individual-distance": 56532.567775628915,
                "average-distance": 53332.70286074231,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 3, 9, 8, 11, 10, 2, 1, 6, 5, 7, 4, 12, 13, 14, 20, 16, 19, 15, 18, 26, 25, 24, 27, 22, 28, 21, 23, 29],
                "best-individual-distance": 42874.59367225057,
                "worst-individual-sequence": [5, 6, 4, 10, 8, 13, 22, 28, 27, 20, 23, 21, 29, 26, 17, 16, 14, 24, 25, 15, 18, 9, 7, 3, 19, 12, 11, 2, 1],
                "worst-individual-distance": 56213.921509737964,
                "average-distance": 53036.31948577279,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 3, 9, 8, 11, 10, 2, 1, 6, 5, 7, 4, 12, 13, 14, 20, 16, 19, 15, 18, 26, 25, 24, 27, 22, 28, 21, 23, 29],
                "best-individual-distance": 42874.59367225057,
                "worst-individual-sequence": [16, 25, 27, 29, 22, 14, 23, 21, 17, 26, 24, 28, 19, 15, 12, 4, 3, 7, 20, 11, 10, 2, 5, 1, 6, 8, 13, 9, 18],
                "worst-individual-distance": 55843.127493712986,
                "average-distance": 52747.838778845166,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 3, 9, 8, 11, 10, 2, 1, 6, 5, 7, 4, 12, 13, 14, 20, 16, 19, 15, 18, 26, 25, 24, 27, 22, 28, 21, 23, 29],
                "best-individual-distance": 42874.59367225057,
                "worst-individual-sequence": [15, 23, 27, 26, 20, 14, 28, 25, 16, 24, 18, 21, 29, 17, 22, 19, 1, 5, 8, 2, 6, 3, 13, 12, 11, 10, 9, 7, 4],
                "worst-individual-distance": 55472.0342503304,
                "average-distance": 52439.19537743673,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 3, 9, 8, 11, 10, 2, 1, 6, 5, 7, 4, 12, 13, 14, 20, 16, 19, 15, 18, 26, 25, 24, 27, 22, 28, 21, 23, 29],
                "best-individual-distance": 42874.59367225057,
                "worst-individual-sequence": [15, 12, 5, 2, 4, 3, 19, 1, 6, 10, 8, 13, 22, 28, 25, 27, 20, 21, 26, 29, 17, 24, 16, 23, 18, 14, 9, 7, 11],
                "worst-individual-distance": 55165.052656210544,
                "average-distance": 52224.29083152384,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 3, 9, 8, 11, 10, 2, 1, 6, 5, 7, 4, 12, 13, 14, 20, 16, 19, 15, 18, 26, 25, 24, 27, 22, 28, 21, 23, 29],
                "best-individual-distance": 42874.59367225057,
                "worst-individual-sequence": [4, 3, 1, 2, 6, 5, 13, 12, 20, 26, 22, 21, 19, 17, 9, 7, 11, 14, 28, 24, 25, 27, 29, 18, 15, 23, 16, 8, 10],
                "worst-individual-distance": 54804.97200751193,
                "average-distance": 51977.664068619015,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 3, 9, 8, 11, 10, 2, 1, 6, 5, 7, 4, 12, 13, 14, 20, 16, 19, 15, 18, 26, 25, 24, 27, 22, 28, 21, 23, 29],
                "best-individual-distance": 42874.59367225057,
                "worst-individual-sequence": [1, 5, 6, 4, 10, 8, 13, 22, 28, 27, 20, 23, 21, 29, 26, 17, 16, 14, 24, 25, 18, 15, 7, 3, 9, 19, 12, 11, 2],
                "worst-individual-distance": 54510.062577689765,
                "average-distance": 51690.90286102528,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 3, 9, 8, 11, 10, 2, 1, 6, 5, 7, 4, 12, 13, 14, 20, 16, 19, 15, 18, 26, 25, 24, 27, 22, 28, 21, 23, 29],
                "best-individual-distance": 42874.59367225057,
                "worst-individual-sequence": [4, 1, 2, 6, 5, 9, 11, 10, 8, 15, 22, 28, 25, 27, 13, 12, 7, 3, 23, 21, 19, 17, 18, 29, 26, 14, 16, 24, 20],
                "worst-individual-distance": 54217.36950645026,
                "average-distance": 51446.92920279194,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 8, 13, 22, 23, 21, 26, 17, 14, 29, 28, 20, 16, 27, 25, 24, 18, 19, 15, 7, 9, 3, 12, 5, 4, 1, 2, 6, 10],
                "best-individual-distance": 40860.36108774924,
                "worst-individual-sequence": [20, 16, 12, 10, 9, 11, 5, 7, 4, 13, 8, 3, 6, 1, 2, 19, 17, 14, 15, 28, 24, 25, 27, 26, 22, 23, 21, 29, 18],
                "worst-individual-distance": 53970.889134097895,
                "average-distance": 51226.410582681056,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 8, 13, 22, 23, 21, 26, 17, 14, 29, 28, 20, 16, 27, 25, 24, 18, 19, 15, 7, 9, 3, 12, 5, 4, 1, 2, 6, 10],
                "best-individual-distance": 40860.36108774924,
                "worst-individual-sequence": [7, 12, 8, 11, 15, 21, 23, 18, 29, 24, 28, 20, 16, 27, 25, 14, 26, 22, 10, 4, 5, 2, 1, 6, 13, 19, 17, 3, 9],
                "worst-individual-distance": 53720.31939124778,
                "average-distance": 51034.49090214891,
                "individual-distances": []
            }, {
                "best-individual-sequence": [14, 29, 22, 18, 28, 26, 17, 16, 24, 25, 27, 20, 23, 21, 19, 15, 13, 4, 3, 7, 9, 5, 8, 2, 1, 6, 12, 11, 10],
                "best-individual-distance": 40204.10958131544,
                "worst-individual-sequence": [10, 4, 8, 27, 1, 3, 16, 2, 6, 5, 9, 13, 12, 7, 14, 24, 25, 20, 26, 22, 28, 21, 19, 17, 18, 15, 29, 23, 11],
                "worst-individual-distance": 53496.194647584685,
                "average-distance": 50823.34089561489,
                "individual-distances": []
            }, {
                "best-individual-sequence": [18, 23, 17, 26, 19, 15, 21, 28, 20, 16, 27, 25, 24, 12, 8, 11, 10, 2, 1, 6, 5, 4, 9, 7, 3, 13, 14, 29, 22],
                "best-individual-distance": 39279.42831931225,
                "worst-individual-sequence": [8, 1, 2, 6, 4, 3, 9, 27, 21, 26, 20, 29, 17, 19, 28, 24, 25, 7, 14, 16, 15, 22, 23, 18, 13, 12, 11, 10, 5],
                "worst-individual-distance": 53281.03895281297,
                "average-distance": 50569.36998420262,
                "individual-distances": []
            }, {
                "best-individual-sequence": [18, 23, 17, 26, 19, 15, 21, 28, 20, 16, 27, 25, 24, 12, 8, 11, 10, 2, 1, 6, 5, 4, 9, 7, 3, 13, 14, 29, 22],
                "best-individual-distance": 39279.42831931225,
                "worst-individual-sequence": [26, 17, 24, 28, 20, 16, 27, 25, 14, 6, 10, 19, 13, 9, 7, 4, 2, 1, 5, 3, 12, 11, 8, 15, 29, 22, 18, 23, 21],
                "worst-individual-distance": 53029.48440045805,
                "average-distance": 50332.412610881016,
                "individual-distances": []
            }, {
                "best-individual-sequence": [18, 23, 17, 26, 19, 15, 21, 28, 20, 16, 27, 25, 24, 12, 8, 11, 10, 2, 1, 6, 5, 4, 9, 7, 3, 13, 14, 29, 22],
                "best-individual-distance": 39279.42831931225,
                "worst-individual-sequence": [24, 27, 16, 22, 28, 19, 21, 23, 29, 17, 3, 9, 8, 5, 1, 10, 11, 4, 6, 2, 12, 7, 13, 14, 15, 18, 20, 25, 26],
                "worst-individual-distance": 52669.62049893388,
                "average-distance": 50021.00858319295,
                "individual-distances": []
            }, {
                "best-individual-sequence": [18, 23, 17, 26, 19, 15, 21, 28, 20, 16, 27, 25, 24, 12, 8, 11, 10, 2, 1, 6, 5, 4, 9, 7, 3, 13, 14, 29, 22],
                "best-individual-distance": 39279.42831931225,
                "worst-individual-sequence": [16, 20, 13, 11, 10, 9, 19, 24, 28, 25, 27, 14, 29, 22, 18, 23, 21, 26, 17, 15, 12, 2, 6, 1, 5, 4, 8, 3, 7],
                "worst-individual-distance": 52358.80754250034,
                "average-distance": 49789.09102232189,
                "individual-distances": []
            }, {
                "best-individual-sequence": [18, 23, 17, 26, 19, 15, 21, 28, 20, 16, 27, 25, 24, 12, 8, 11, 10, 2, 1, 6, 5, 4, 9, 7, 3, 13, 14, 29, 22],
                "best-individual-distance": 39279.42831931225,
                "worst-individual-sequence": [1, 6, 10, 8, 13, 7, 9, 20, 16, 25, 27, 14, 29, 22, 18, 23, 21, 26, 17, 24, 28, 19, 15, 12, 5, 2, 4, 3, 11],
                "worst-individual-distance": 52191.39557208008,
                "average-distance": 49550.607585442725,
                "individual-distances": []
            }, {
                "best-individual-sequence": [18, 23, 17, 26, 19, 15, 21, 28, 20, 16, 27, 25, 24, 12, 8, 11, 10, 2, 1, 6, 5, 4, 9, 7, 3, 13, 14, 29, 22],
                "best-individual-distance": 39279.42831931225,
                "worst-individual-sequence": [12, 11, 10, 8, 7, 13, 22, 28, 25, 27, 20, 23, 26, 24, 9, 29, 14, 16, 18, 19, 15, 21, 17, 3, 4, 2, 1, 5, 6],
                "worst-individual-distance": 51863.44512163193,
                "average-distance": 49297.870951320416,
                "individual-distances": []
            }, {
                "best-individual-sequence": [18, 23, 17, 26, 19, 15, 21, 28, 20, 16, 27, 25, 24, 12, 8, 11, 10, 2, 1, 6, 5, 4, 9, 7, 3, 13, 14, 29, 22],
                "best-individual-distance": 39279.42831931225,
                "worst-individual-sequence": [9, 10, 8, 13, 22, 25, 27, 20, 21, 24, 26, 28, 23, 29, 18, 19, 12, 5, 4, 3, 7, 1, 2, 6, 11, 15, 17, 14, 16],
                "worst-individual-distance": 51668.25980080477,
                "average-distance": 49068.85531034597,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 13, 22, 28, 29, 26, 17, 16, 24, 25, 27, 20, 23, 21, 14, 18, 19, 15, 9, 7, 3, 8, 11, 10, 2, 1, 6, 5, 4],
                "best-individual-distance": 38730.87815907459,
                "worst-individual-sequence": [21, 26, 17, 19, 15, 12, 7, 3, 14, 24, 28, 20, 16, 27, 25, 22, 13, 8, 11, 10, 2, 1, 5, 4, 6, 29, 9, 18, 23],
                "worst-individual-distance": 51427.98576818305,
                "average-distance": 48842.37090159397,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 13, 22, 28, 29, 26, 17, 16, 24, 25, 27, 20, 23, 21, 14, 18, 19, 15, 9, 7, 3, 8, 11, 10, 2, 1, 6, 5, 4],
                "best-individual-distance": 38730.87815907459,
                "worst-individual-sequence": [28, 19, 21, 23, 29, 17, 14, 13, 7, 4, 3, 8, 5, 1, 10, 6, 2, 12, 9, 11, 15, 18, 26, 22, 25, 27, 16, 24, 20],
                "worst-individual-distance": 51233.20092505135,
                "average-distance": 48649.301171298415,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 13, 22, 28, 29, 26, 17, 16, 24, 25, 27, 20, 23, 21, 14, 18, 19, 15, 9, 7, 3, 8, 11, 10, 2, 1, 6, 5, 4],
                "best-individual-distance": 38730.87815907459,
                "worst-individual-sequence": [2, 1, 20, 26, 29, 23, 21, 17, 16, 24, 25, 27, 22, 18, 19, 14, 13, 28, 6, 4, 3, 7, 9, 8, 10, 5, 12, 15, 11],
                "worst-individual-distance": 51014.661308616756,
                "average-distance": 48412.26339808797,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 13, 22, 28, 29, 26, 17, 16, 24, 25, 27, 20, 23, 21, 14, 18, 19, 15, 9, 7, 3, 8, 11, 10, 2, 1, 6, 5, 4],
                "best-individual-distance": 38730.87815907459,
                "worst-individual-sequence": [16, 14, 22, 28, 25, 27, 20, 29, 26, 17, 19, 18, 21, 13, 9, 7, 3, 4, 5, 11, 10, 15, 23, 8, 1, 6, 2, 12, 24],
                "worst-individual-distance": 50817.68082286979,
                "average-distance": 48240.57974298788,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 13, 22, 28, 29, 26, 17, 16, 24, 25, 27, 20, 23, 21, 14, 18, 19, 15, 9, 7, 3, 8, 11, 10, 2, 1, 6, 5, 4],
                "best-individual-distance": 38730.87815907459,
                "worst-individual-sequence": [27, 24, 16, 20, 14, 10, 6, 1, 2, 5, 12, 29, 22, 18, 23, 26, 21, 15, 17, 28, 19, 11, 13, 4, 3, 7, 9, 8, 25],
                "worst-individual-distance": 50639.139005719175,
                "average-distance": 48032.87067320171,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 13, 22, 28, 29, 26, 17, 16, 24, 25, 27, 20, 23, 21, 14, 18, 19, 15, 9, 7, 3, 8, 11, 10, 2, 1, 6, 5, 4],
                "best-individual-distance": 38730.87815907459,
                "worst-individual-sequence": [8, 12, 2, 1, 6, 19, 22, 28, 27, 20, 23, 21, 29, 13, 9, 7, 3, 4, 5, 11, 10, 14, 18, 15, 26, 25, 16, 24, 17],
                "worst-individual-distance": 50405.3143848398,
                "average-distance": 47812.345513974244,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 13, 22, 28, 29, 26, 17, 16, 24, 25, 27, 20, 23, 21, 14, 18, 19, 15, 9, 7, 3, 8, 11, 10, 2, 1, 6, 5, 4],
                "best-individual-distance": 38730.87815907459,
                "worst-individual-sequence": [10, 19, 14, 28, 27, 20, 23, 26, 25, 16, 24, 18, 21, 29, 17, 22, 15, 8, 3, 4, 13, 12, 5, 9, 7, 6, 1, 2, 11],
                "worst-individual-distance": 50129.51597459873,
                "average-distance": 47576.54142686392,
                "individual-distances": []
            }, {
                "best-individual-sequence": [29, 28, 26, 14, 17, 16, 24, 25, 27, 20, 23, 18, 19, 15, 13, 22, 21, 7, 9, 8, 11, 10, 6, 1, 2, 5, 12, 4, 3],
                "best-individual-distance": 37058.89840980804,
                "worst-individual-sequence": [18, 23, 21, 26, 24, 28, 19, 15, 29, 17, 12, 9, 8, 5, 1, 10, 11, 4, 6, 2, 3, 7, 13, 20, 16, 25, 27, 14, 22],
                "worst-individual-distance": 49974.43484998484,
                "average-distance": 47337.68020740366,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 14, 28, 26, 16, 24, 25, 27, 20, 21, 19, 15, 29, 22, 18, 23, 17, 13, 5, 8, 12, 11, 10, 1, 2, 6, 4, 3, 7],
                "best-individual-distance": 36842.75134151996,
                "worst-individual-sequence": [10, 22, 26, 25, 24, 27, 28, 17, 20, 19, 16, 23, 15, 21, 29, 14, 18, 9, 7, 2, 1, 6, 5, 3, 4, 8, 12, 13, 11],
                "worst-individual-distance": 49796.8336161605,
                "average-distance": 47143.15629603597,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 14, 28, 26, 16, 24, 25, 27, 20, 21, 19, 15, 29, 22, 18, 23, 17, 13, 5, 8, 12, 11, 10, 1, 2, 6, 4, 3, 7],
                "best-individual-distance": 36842.75134151996,
                "worst-individual-sequence": [14, 29, 22, 18, 23, 17, 26, 19, 15, 21, 28, 20, 16, 27, 25, 13, 12, 8, 11, 10, 2, 1, 5, 4, 6, 9, 7, 3, 24],
                "worst-individual-distance": 49513.52935110706,
                "average-distance": 46915.39274191995,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 14, 28, 26, 16, 24, 25, 27, 20, 21, 19, 15, 29, 22, 18, 23, 17, 13, 5, 8, 12, 11, 10, 1, 2, 6, 4, 3, 7],
                "best-individual-distance": 36842.75134151996,
                "worst-individual-sequence": [27, 24, 16, 20, 19, 22, 23, 28, 17, 21, 10, 5, 3, 9, 4, 2, 1, 6, 8, 11, 12, 7, 13, 14, 15, 18, 29, 26, 25],
                "worst-individual-distance": 49290.79309522313,
                "average-distance": 46692.70759791094,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 14, 28, 26, 16, 24, 25, 27, 20, 21, 19, 15, 29, 22, 18, 23, 17, 13, 5, 8, 12, 11, 10, 1, 2, 6, 4, 3, 7],
                "best-individual-distance": 36842.75134151996,
                "worst-individual-sequence": [5, 4, 11, 12, 8, 13, 28, 19, 26, 16, 27, 20, 29, 22, 18, 23, 17, 21, 24, 25, 14, 9, 7, 3, 15, 10, 2, 1, 6],
                "worst-individual-distance": 49053.24171325888,
                "average-distance": 46457.59605141019,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 14, 28, 26, 16, 24, 25, 27, 20, 21, 19, 15, 29, 22, 18, 23, 17, 13, 5, 8, 12, 11, 10, 1, 2, 6, 4, 3, 7],
                "best-individual-distance": 36842.75134151996,
                "worst-individual-sequence": [10, 8, 9, 3, 12, 11, 13, 20, 16, 25, 27, 14, 29, 22, 18, 23, 21, 26, 17, 24, 28, 19, 15, 7, 4, 1, 2, 6, 5],
                "worst-individual-distance": 48811.89012367327,
                "average-distance": 46284.4485110346,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 14, 28, 26, 16, 24, 25, 27, 20, 21, 19, 15, 29, 22, 18, 23, 17, 13, 5, 8, 12, 11, 10, 1, 2, 6, 4, 3, 7],
                "best-individual-distance": 36842.75134151996,
                "worst-individual-sequence": [16, 28, 19, 21, 23, 29, 17, 12, 9, 8, 5, 1, 10, 7, 3, 4, 6, 2, 11, 13, 14, 15, 22, 26, 20, 18, 24, 25, 27],
                "worst-individual-distance": 48582.36282331765,
                "average-distance": 46095.9715660347,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 14, 28, 26, 16, 24, 25, 27, 20, 21, 19, 15, 29, 22, 18, 23, 17, 13, 5, 8, 12, 11, 10, 1, 2, 6, 4, 3, 7],
                "best-individual-distance": 36842.75134151996,
                "worst-individual-sequence": [14, 29, 22, 18, 23, 17, 26, 19, 15, 21, 28, 20, 16, 27, 25, 13, 12, 8, 11, 10, 2, 1, 5, 4, 6, 9, 7, 3, 24],
                "worst-individual-distance": 48356.18254789704,
                "average-distance": 45924.36823044072,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 14, 28, 26, 16, 24, 25, 27, 20, 21, 19, 15, 29, 22, 18, 23, 17, 13, 5, 8, 12, 11, 10, 1, 2, 6, 4, 3, 7],
                "best-individual-distance": 36842.75134151996,
                "worst-individual-sequence": [14, 28, 1, 4, 2, 6, 10, 11, 8, 5, 9, 3, 7, 13, 12, 15, 18, 26, 25, 27, 16, 24, 20, 19, 21, 23, 29, 22, 17],
                "worst-individual-distance": 48178.610296030245,
                "average-distance": 45741.44954723936,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 14, 28, 26, 16, 24, 25, 27, 20, 21, 19, 15, 29, 22, 18, 23, 17, 13, 5, 8, 12, 11, 10, 1, 2, 6, 4, 3, 7],
                "best-individual-distance": 36842.75134151996,
                "worst-individual-sequence": [29, 26, 17, 16, 24, 25, 27, 20, 23, 21, 15, 19, 18, 11, 12, 1, 2, 6, 5, 9, 10, 8, 14, 4, 3, 7, 13, 22, 28],
                "worst-individual-distance": 47946.42824801103,
                "average-distance": 45528.7190593186,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 14, 28, 26, 16, 24, 25, 27, 20, 21, 19, 15, 29, 22, 18, 23, 17, 13, 5, 8, 12, 11, 10, 1, 2, 6, 4, 3, 7],
                "best-individual-distance": 36842.75134151996,
                "worst-individual-sequence": [28, 29, 22, 18, 23, 17, 26, 19, 25, 27, 24, 20, 16, 9, 15, 7, 3, 12, 5, 4, 1, 2, 6, 10, 11, 8, 13, 14, 21],
                "worst-individual-distance": 47755.84690921864,
                "average-distance": 45334.09385490527,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 14, 28, 26, 16, 24, 25, 27, 20, 21, 19, 15, 29, 22, 18, 23, 17, 13, 5, 8, 12, 11, 10, 1, 2, 6, 4, 3, 7],
                "best-individual-distance": 36842.75134151996,
                "worst-individual-sequence": [10, 6, 1, 2, 4, 5, 9, 24, 16, 25, 27, 14, 29, 22, 18, 23, 21, 26, 17, 20, 28, 19, 15, 12, 11, 13, 3, 7, 8],
                "worst-individual-distance": 47596.20828619824,
                "average-distance": 45139.060001962505,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 14, 28, 26, 16, 24, 25, 27, 20, 21, 19, 15, 29, 22, 18, 23, 17, 13, 5, 8, 12, 11, 10, 1, 2, 6, 4, 3, 7],
                "best-individual-distance": 36842.75134151996,
                "worst-individual-sequence": [28, 25, 27, 24, 20, 21, 29, 26, 17, 16, 14, 18, 23, 19, 15, 13, 3, 7, 9, 8, 11, 10, 6, 12, 5, 4, 1, 2, 22],
                "worst-individual-distance": 47381.06121010655,
                "average-distance": 44938.11356053309,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 14, 28, 26, 16, 24, 25, 27, 20, 21, 19, 15, 29, 22, 18, 23, 17, 13, 5, 8, 12, 11, 10, 1, 2, 6, 4, 3, 7],
                "best-individual-distance": 36842.75134151996,
                "worst-individual-sequence": [9, 10, 2, 6, 1, 5, 4, 3, 8, 13, 22, 28, 12, 7, 14, 15, 18, 26, 25, 27, 16, 24, 20, 19, 21, 23, 29, 17, 11],
                "worst-individual-distance": 47199.20482909782,
                "average-distance": 44752.40573851149,
                "individual-distances": []
            }
        ],
        [
            [{
                "time_cost": 0
            }], {
                "best-individual-sequence": [17, 10, 11, 5, 4, 2, 6, 1, 3, 29, 13, 27, 26, 18, 21, 8, 23, 24, 16, 20, 19, 7, 25, 22, 28, 15, 12, 9, 14],
                "best-individual-distance": 74391.64459175084,
                "worst-individual-sequence": [22, 20, 28, 4, 6, 27, 8, 3, 18, 9, 14, 11, 15, 23, 12, 26, 10, 16, 17, 25, 5, 7, 21, 1, 29, 24, 13, 2, 19],
                "worst-individual-distance": 120314.34790903461,
                "average-distance": 106257.65853280658,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 18, 21, 13, 10, 8, 12, 4, 7, 24, 14, 9, 29, 3, 16, 27, 25, 22, 23, 28, 26, 2, 1, 17, 6, 5, 15, 11, 19],
                "best-individual-distance": 72513.45363377327,
                "worst-individual-sequence": [13, 16, 11, 24, 8, 28, 20, 7, 5, 10, 9, 12, 14, 26, 21, 22, 1, 18, 25, 23, 2, 4, 17, 3, 29, 19, 15, 6, 27],
                "worst-individual-distance": 115320.38359445166,
                "average-distance": 103617.84105863787,
                "individual-distances": []
            }, {
                "best-individual-sequence": [14, 17, 13, 6, 2, 3, 7, 8, 9, 29, 5, 16, 27, 26, 4, 1, 25, 22, 23, 28, 20, 18, 21, 10, 11, 15, 12, 24, 19],
                "best-individual-distance": 71161.83069778232,
                "worst-individual-sequence": [15, 5, 13, 11, 25, 21, 24, 19, 3, 17, 10, 22, 20, 18, 6, 12, 26, 16, 1, 14, 8, 4, 9, 28, 29, 2, 7, 27, 23],
                "worst-individual-distance": 112010.8640966869,
                "average-distance": 101246.41826227902,
                "individual-distances": []
            }, {
                "best-individual-sequence": [13, 6, 2, 3, 7, 8, 9, 5, 4, 1, 11, 20, 16, 21, 27, 14, 12, 10, 17, 15, 28, 22, 25, 24, 29, 23, 26, 18, 19],
                "best-individual-distance": 68892.11915269395,
                "worst-individual-sequence": [20, 19, 25, 18, 2, 22, 11, 1, 7, 21, 23, 12, 4, 5, 16, 8, 24, 6, 17, 26, 14, 3, 10, 28, 27, 29, 15, 13, 9],
                "worst-individual-distance": 109349.39595553096,
                "average-distance": 98824.0167866848,
                "individual-distances": []
            }, {
                "best-individual-sequence": [13, 6, 2, 3, 7, 8, 9, 5, 4, 1, 11, 20, 16, 21, 27, 14, 12, 10, 17, 15, 28, 22, 25, 24, 29, 23, 26, 18, 19],
                "best-individual-distance": 68892.11915269395,
                "worst-individual-sequence": [24, 4, 16, 7, 27, 21, 28, 25, 14, 12, 26, 29, 17, 11, 9, 15, 2, 19, 5, 1, 13, 3, 23, 20, 22, 8, 10, 6, 18],
                "worst-individual-distance": 107048.93101185103,
                "average-distance": 96961.44665385329,
                "individual-distances": []
            }, {
                "best-individual-sequence": [13, 6, 2, 3, 7, 8, 9, 5, 4, 1, 11, 20, 16, 21, 27, 14, 12, 10, 17, 15, 28, 22, 25, 24, 29, 23, 26, 18, 19],
                "best-individual-distance": 68892.11915269395,
                "worst-individual-sequence": [18, 28, 22, 1, 16, 10, 21, 4, 3, 13, 7, 29, 14, 8, 15, 23, 11, 2, 12, 25, 20, 24, 17, 19, 6, 5, 27, 26, 9],
                "worst-individual-distance": 104516.72666383136,
                "average-distance": 94946.19915025386,
                "individual-distances": []
            }, {
                "best-individual-sequence": [28, 15, 22, 16, 1, 7, 9, 6, 2, 12, 10, 8, 4, 3, 5, 11, 26, 13, 19, 14, 24, 17, 18, 21, 20, 25, 27, 23, 29],
                "best-individual-distance": 64079.33153472495,
                "worst-individual-sequence": [14, 18, 22, 25, 11, 10, 5, 4, 23, 6, 29, 13, 12, 8, 1, 7, 16, 2, 19, 28, 9, 24, 21, 17, 27, 3, 15, 20, 26],
                "worst-individual-distance": 102433.22899981205,
                "average-distance": 93010.92493564304,
                "individual-distances": []
            }, {
                "best-individual-sequence": [28, 15, 22, 16, 1, 7, 9, 6, 2, 12, 10, 8, 4, 3, 5, 11, 26, 13, 19, 14, 24, 17, 18, 21, 20, 25, 27, 23, 29],
                "best-individual-distance": 64079.33153472495,
                "worst-individual-sequence": [24, 7, 2, 4, 12, 10, 1, 11, 22, 17, 9, 18, 6, 16, 28, 27, 5, 25, 8, 13, 19, 23, 26, 20, 29, 14, 21, 15, 3],
                "worst-individual-distance": 100148.4906887465,
                "average-distance": 91180.45413826012,
                "individual-distances": []
            }, {
                "best-individual-sequence": [28, 15, 22, 16, 1, 7, 9, 6, 2, 12, 10, 8, 4, 3, 5, 11, 26, 13, 19, 14, 24, 17, 18, 21, 20, 25, 27, 23, 29],
                "best-individual-distance": 64079.33153472495,
                "worst-individual-sequence": [5, 13, 17, 7, 15, 25, 26, 14, 3, 24, 16, 12, 2, 11, 1, 6, 4, 21, 28, 10, 19, 9, 29, 27, 23, 18, 20, 8, 22],
                "worst-individual-distance": 98030.08592586177,
                "average-distance": 89522.30761916497,
                "individual-distances": []
            }, {
                "best-individual-sequence": [28, 15, 22, 16, 1, 7, 9, 6, 2, 12, 10, 8, 4, 3, 5, 11, 26, 13, 19, 14, 24, 17, 18, 21, 20, 25, 27, 23, 29],
                "best-individual-distance": 64079.33153472495,
                "worst-individual-sequence": [19, 26, 29, 21, 8, 25, 27, 2, 10, 18, 28, 7, 6, 4, 9, 20, 12, 16, 22, 23, 14, 24, 15, 1, 11, 3, 13, 5, 17],
                "worst-individual-distance": 96049.75341459754,
                "average-distance": 87815.94110702188,
                "individual-distances": []
            }, {
                "best-individual-sequence": [28, 15, 22, 16, 1, 7, 9, 6, 2, 12, 10, 8, 4, 3, 5, 11, 26, 13, 19, 14, 24, 17, 18, 21, 20, 25, 27, 23, 29],
                "best-individual-distance": 64079.33153472495,
                "worst-individual-sequence": [8, 20, 4, 9, 21, 24, 16, 22, 2, 3, 13, 23, 6, 1, 12, 10, 5, 15, 7, 11, 26, 29, 28, 14, 25, 18, 17, 27, 19],
                "worst-individual-distance": 94541.23084755067,
                "average-distance": 86232.73042461739,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 4, 27, 20, 17, 14, 16, 18, 7, 9, 6, 2, 1, 13, 5, 12, 8, 22, 21, 19, 15, 23, 29, 26, 24, 28, 25, 11, 10],
                "best-individual-distance": 60174.674670361375,
                "worst-individual-sequence": [20, 15, 23, 27, 10, 3, 11, 18, 13, 14, 1, 5, 8, 7, 12, 25, 22, 28, 17, 26, 29, 4, 2, 21, 19, 24, 16, 9, 6],
                "worst-individual-distance": 92710.82821863411,
                "average-distance": 84679.56229844484,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 4, 27, 20, 17, 14, 16, 18, 7, 9, 6, 2, 1, 13, 5, 12, 8, 22, 21, 19, 15, 23, 29, 26, 24, 28, 25, 11, 10],
                "best-individual-distance": 60174.674670361375,
                "worst-individual-sequence": [28, 20, 6, 12, 14, 16, 21, 19, 8, 15, 23, 22, 29, 18, 10, 3, 7, 4, 1, 17, 26, 5, 24, 27, 25, 2, 13, 11, 9],
                "worst-individual-distance": 90869.02574023497,
                "average-distance": 83248.7681748194,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 4, 27, 20, 17, 14, 16, 18, 7, 9, 6, 2, 1, 13, 5, 12, 8, 22, 21, 19, 15, 23, 29, 26, 24, 28, 25, 11, 10],
                "best-individual-distance": 60174.674670361375,
                "worst-individual-sequence": [20, 25, 27, 18, 22, 23, 29, 7, 24, 12, 15, 8, 5, 11, 16, 26, 10, 2, 13, 3, 19, 14, 4, 6, 1, 28, 17, 9, 21],
                "worst-individual-distance": 89319.71325273455,
                "average-distance": 82013.42535980184,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 3, 13, 14, 18, 21, 6, 7, 4, 12, 10, 15, 26, 20, 25, 27, 24, 22, 23, 29, 28, 16, 9, 8, 5, 19, 17, 11, 2],
                "best-individual-distance": 59652.94801495782,
                "worst-individual-sequence": [27, 7, 5, 9, 8, 21, 15, 24, 6, 2, 19, 22, 20, 28, 25, 29, 17, 14, 13, 1, 23, 18, 4, 10, 12, 3, 11, 26, 16],
                "worst-individual-distance": 87839.20491687565,
                "average-distance": 80692.0614837315,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 3, 13, 14, 18, 21, 6, 7, 4, 12, 10, 15, 26, 20, 25, 27, 24, 22, 23, 29, 28, 16, 9, 8, 5, 19, 17, 11, 2],
                "best-individual-distance": 59652.94801495782,
                "worst-individual-sequence": [29, 19, 14, 5, 18, 13, 2, 1, 6, 25, 11, 12, 7, 4, 8, 20, 22, 21, 23, 15, 17, 16, 10, 3, 27, 28, 24, 9, 26],
                "worst-individual-distance": 86429.57022794621,
                "average-distance": 79576.95063848767,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 3, 13, 14, 18, 21, 6, 7, 4, 12, 10, 15, 26, 20, 25, 27, 24, 22, 23, 29, 28, 16, 9, 8, 5, 19, 17, 11, 2],
                "best-individual-distance": 59652.94801495782,
                "worst-individual-sequence": [13, 9, 1, 5, 6, 7, 12, 10, 15, 26, 20, 23, 27, 3, 24, 25, 17, 29, 16, 4, 28, 18, 11, 14, 19, 22, 21, 8, 2],
                "worst-individual-distance": 84981.92335115893,
                "average-distance": 78497.93728462457,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 7, 8, 9, 5, 4, 12, 10, 13, 15, 26, 20, 23, 27, 24, 25, 17, 22, 29, 28, 16, 18, 11, 14, 19, 21, 3, 6, 2],
                "best-individual-distance": 58436.4147968989,
                "worst-individual-sequence": [26, 8, 28, 24, 15, 14, 17, 6, 18, 2, 3, 10, 11, 1, 5, 4, 12, 21, 20, 22, 13, 16, 7, 9, 19, 23, 29, 25, 27],
                "worst-individual-distance": 83714.0207901176,
                "average-distance": 77322.8851399653,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 7, 8, 9, 5, 4, 12, 10, 13, 15, 26, 20, 23, 27, 24, 25, 17, 22, 29, 28, 16, 18, 11, 14, 19, 21, 3, 6, 2],
                "best-individual-distance": 58436.4147968989,
                "worst-individual-sequence": [24, 26, 27, 16, 7, 8, 5, 15, 6, 2, 23, 22, 20, 28, 25, 29, 17, 14, 13, 1, 19, 18, 4, 10, 12, 3, 11, 21, 9],
                "worst-individual-distance": 82484.17166068674,
                "average-distance": 76413.56696813047,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 7, 8, 9, 5, 4, 12, 10, 13, 15, 26, 20, 23, 27, 24, 25, 17, 22, 29, 28, 16, 18, 11, 14, 19, 21, 3, 6, 2],
                "best-individual-distance": 58436.4147968989,
                "worst-individual-sequence": [1, 12, 23, 25, 20, 16, 28, 27, 26, 3, 7, 9, 6, 2, 24, 17, 13, 5, 15, 22, 29, 14, 21, 19, 4, 18, 10, 8, 11],
                "worst-individual-distance": 81292.3400273407,
                "average-distance": 75447.824069169,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 2, 6, 9, 7, 10, 8, 11, 1, 12, 15, 26, 20, 25, 23, 22, 27, 24, 29, 28, 16, 17, 14, 19, 18, 21, 13, 3, 5],
                "best-individual-distance": 57253.34051795002,
                "worst-individual-sequence": [14, 10, 15, 20, 25, 23, 28, 27, 26, 3, 7, 9, 6, 2, 24, 29, 16, 17, 19, 12, 5, 11, 22, 18, 13, 4, 8, 1, 21],
                "worst-individual-distance": 80181.77521187726,
                "average-distance": 74531.14018537322,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 2, 6, 9, 7, 10, 8, 11, 1, 12, 15, 26, 20, 25, 23, 22, 27, 24, 29, 28, 16, 17, 14, 19, 18, 21, 13, 3, 5],
                "best-individual-distance": 57253.34051795002,
                "worst-individual-sequence": [24, 20, 22, 9, 29, 27, 21, 23, 18, 1, 11, 10, 6, 5, 8, 3, 7, 26, 16, 17, 25, 28, 2, 4, 19, 12, 15, 14, 13],
                "worst-individual-distance": 79347.83223503086,
                "average-distance": 73765.45318631946,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 8, 3, 4, 7, 2, 1, 6, 10, 9, 26, 29, 12, 15, 19, 25, 27, 24, 14, 16, 28, 13, 17, 20, 22, 21, 23, 18, 11],
                "best-individual-distance": 56221.068688451574,
                "worst-individual-sequence": [1, 7, 4, 12, 10, 15, 2, 6, 5, 26, 20, 23, 27, 3, 24, 25, 17, 29, 28, 16, 18, 11, 14, 19, 22, 21, 8, 13, 9],
                "worst-individual-distance": 78319.16018981827,
                "average-distance": 72950.88885630779,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 8, 3, 4, 7, 2, 1, 6, 10, 9, 26, 29, 12, 15, 19, 25, 27, 24, 14, 16, 28, 13, 17, 20, 22, 21, 23, 18, 11],
                "best-individual-distance": 56221.068688451574,
                "worst-individual-sequence": [10, 19, 18, 3, 2, 13, 12, 15, 26, 20, 25, 23, 27, 24, 21, 5, 7, 29, 16, 17, 28, 22, 14, 9, 1, 11, 6, 8, 4],
                "worst-individual-distance": 77432.86472959253,
                "average-distance": 72277.9337700515,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 8, 3, 4, 7, 2, 1, 6, 10, 9, 26, 29, 12, 15, 19, 25, 27, 24, 14, 16, 28, 13, 17, 20, 22, 21, 23, 18, 11],
                "best-individual-distance": 56221.068688451574,
                "worst-individual-sequence": [8, 2, 1, 6, 21, 29, 27, 24, 7, 4, 12, 10, 15, 26, 5, 14, 13, 3, 11, 9, 18, 28, 17, 25, 19, 16, 20, 23, 22],
                "worst-individual-distance": 76598.63245683219,
                "average-distance": 71473.40482685737,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 8, 3, 4, 7, 2, 1, 6, 10, 9, 26, 29, 12, 15, 19, 25, 27, 24, 14, 16, 28, 13, 17, 20, 22, 21, 23, 18, 11],
                "best-individual-distance": 56221.068688451574,
                "worst-individual-sequence": [13, 9, 1, 5, 6, 7, 4, 12, 10, 15, 26, 20, 23, 27, 24, 3, 25, 17, 29, 28, 16, 18, 11, 14, 19, 22, 21, 8, 2],
                "worst-individual-distance": 75906.11466547409,
                "average-distance": 70766.28213210776,
                "individual-distances": []
            }, {
                "best-individual-sequence": [14, 1, 6, 10, 9, 7, 12, 15, 19, 16, 26, 20, 23, 27, 24, 25, 17, 22, 29, 28, 13, 21, 18, 11, 5, 8, 3, 4, 2],
                "best-individual-distance": 55520.92257073538,
                "worst-individual-sequence": [18, 23, 26, 3, 7, 9, 6, 2, 1, 5, 20, 21, 13, 14, 12, 11, 8, 22, 15, 17, 29, 10, 19, 24, 4, 28, 25, 27, 16],
                "worst-individual-distance": 75148.66358719328,
                "average-distance": 70068.3827091711,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 5, 6, 2, 1, 4, 12, 10, 15, 26, 20, 23, 27, 24, 25, 17, 29, 21, 22, 28, 16, 18, 11, 14, 19, 3, 7, 8, 13],
                "best-individual-distance": 54858.36198884559,
                "worst-individual-sequence": [7, 10, 25, 26, 22, 5, 6, 4, 8, 2, 1, 9, 15, 20, 17, 24, 21, 29, 14, 23, 27, 16, 18, 28, 19, 12, 13, 3, 11],
                "worst-individual-distance": 74350.93123662633,
                "average-distance": 69296.96388468449,
                "individual-distances": []
            }, {
                "best-individual-sequence": [8, 9, 5, 4, 1, 11, 12, 10, 15, 26, 25, 27, 19, 23, 21, 17, 24, 22, 29, 28, 20, 16, 14, 18, 13, 6, 2, 3, 7],
                "best-individual-distance": 53765.24706314552,
                "worst-individual-sequence": [6, 3, 9, 5, 7, 4, 12, 10, 15, 26, 20, 23, 27, 24, 25, 17, 28, 14, 22, 21, 13, 16, 29, 8, 19, 1, 11, 18, 2],
                "worst-individual-distance": 73568.96713489578,
                "average-distance": 68525.39527469705,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 8, 9, 7, 3, 6, 11, 12, 10, 15, 22, 26, 20, 25, 23, 27, 24, 29, 16, 17, 28, 21, 14, 18, 19, 13, 1, 2, 5],
                "best-individual-distance": 52800.71291563547,
                "worst-individual-sequence": [18, 3, 13, 8, 26, 20, 12, 9, 5, 10, 15, 23, 27, 25, 24, 29, 28, 16, 11, 21, 17, 22, 4, 7, 2, 1, 6, 14, 19],
                "worst-individual-distance": 72660.66418067172,
                "average-distance": 67799.2764216051,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 5, 6, 2, 1, 4, 12, 10, 15, 26, 20, 27, 24, 25, 17, 22, 29, 28, 21, 23, 16, 18, 11, 3, 14, 19, 7, 8, 13],
                "best-individual-distance": 52527.38350271461,
                "worst-individual-sequence": [4, 3, 18, 9, 13, 15, 23, 28, 20, 21, 7, 8, 11, 12, 6, 2, 17, 27, 24, 26, 19, 29, 25, 16, 14, 10, 22, 1, 5],
                "worst-individual-distance": 71878.80042968507,
                "average-distance": 67168.15785785193,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 5, 6, 2, 1, 4, 12, 10, 15, 26, 20, 27, 24, 25, 17, 22, 29, 28, 21, 23, 16, 18, 11, 3, 14, 19, 7, 8, 13],
                "best-individual-distance": 52527.38350271461,
                "worst-individual-sequence": [15, 17, 23, 6, 1, 2, 4, 3, 9, 18, 16, 25, 26, 20, 28, 8, 19, 14, 10, 5, 7, 22, 11, 12, 24, 27, 21, 29, 13],
                "worst-individual-distance": 71259.72043653652,
                "average-distance": 66466.44883249876,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 5, 6, 2, 1, 4, 12, 10, 15, 26, 20, 27, 24, 25, 17, 22, 29, 28, 21, 23, 16, 18, 11, 3, 14, 19, 7, 8, 13],
                "best-individual-distance": 52527.38350271461,
                "worst-individual-sequence": [21, 22, 3, 6, 7, 12, 15, 26, 20, 25, 23, 10, 11, 1, 5, 4, 27, 2, 24, 29, 28, 16, 17, 14, 19, 8, 13, 18, 9],
                "worst-individual-distance": 70645.7386012881,
                "average-distance": 65850.64184349499,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 5, 6, 2, 1, 4, 12, 10, 15, 26, 20, 27, 24, 25, 17, 22, 29, 28, 21, 23, 16, 18, 11, 3, 14, 19, 7, 8, 13],
                "best-individual-distance": 52527.38350271461,
                "worst-individual-sequence": [6, 7, 4, 12, 9, 5, 10, 15, 26, 20, 25, 27, 23, 24, 29, 16, 17, 21, 13, 8, 3, 1, 18, 28, 11, 14, 22, 19, 2],
                "worst-individual-distance": 69862.51811673291,
                "average-distance": 65172.55727275808,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 10, 15, 22, 26, 20, 16, 24, 25, 27, 28, 23, 29, 18, 4, 5, 1, 6, 8, 3, 2, 13, 7, 9, 14, 19, 21, 17, 11],
                "best-individual-distance": 52057.21041898055,
                "worst-individual-sequence": [4, 8, 21, 27, 26, 15, 14, 12, 23, 28, 24, 29, 17, 25, 20, 19, 18, 10, 13, 22, 16, 9, 3, 1, 5, 2, 6, 11, 7],
                "worst-individual-distance": 69131.35018540655,
                "average-distance": 64625.44965948779,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 5, 4, 2, 1, 6, 10, 11, 21, 25, 18, 23, 28, 29, 22, 16, 27, 24, 26, 20, 15, 12, 19, 14, 17, 13, 3, 7, 8],
                "best-individual-distance": 51426.29265367041,
                "worst-individual-sequence": [13, 7, 8, 21, 26, 17, 16, 27, 29, 4, 9, 15, 20, 25, 24, 22, 23, 10, 5, 3, 12, 28, 19, 18, 14, 11, 6, 1, 2],
                "worst-individual-distance": 68388.08805720264,
                "average-distance": 63946.22913434244,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 5, 4, 1, 11, 12, 10, 15, 26, 20, 23, 27, 24, 16, 25, 17, 29, 21, 22, 28, 14, 18, 19, 13, 3, 7, 6, 2, 8],
                "best-individual-distance": 51163.446091981816,
                "worst-individual-sequence": [13, 9, 15, 26, 28, 16, 29, 22, 14, 7, 8, 11, 12, 2, 24, 25, 17, 19, 18, 21, 20, 27, 23, 6, 10, 1, 5, 4, 3],
                "worst-individual-distance": 67759.9375548949,
                "average-distance": 63324.760439552105,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 11, 18, 19, 15, 26, 23, 28, 24, 25, 20, 16, 27, 14, 29, 22, 21, 17, 12, 10, 5, 8, 3, 4, 7, 13, 1, 6, 2],
                "best-individual-distance": 50243.918529068775,
                "worst-individual-sequence": [3, 7, 2, 1, 6, 10, 21, 8, 26, 9, 29, 24, 25, 27, 28, 22, 17, 14, 23, 18, 13, 19, 20, 16, 15, 11, 5, 12, 4],
                "worst-individual-distance": 67156.89733181369,
                "average-distance": 62702.890851937496,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 6, 2, 1, 12, 10, 15, 26, 20, 23, 27, 24, 25, 22, 29, 28, 16, 17, 14, 19, 18, 21, 13, 3, 5, 4, 9, 7, 8],
                "best-individual-distance": 47546.51890667916,
                "worst-individual-sequence": [7, 5, 1, 6, 10, 8, 15, 26, 24, 14, 29, 28, 16, 27, 25, 23, 13, 3, 11, 18, 21, 17, 19, 20, 22, 9, 2, 12, 4],
                "worst-individual-distance": 66505.58131685235,
                "average-distance": 62051.85539564049,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 6, 2, 1, 12, 10, 15, 26, 20, 23, 27, 24, 25, 22, 29, 28, 16, 17, 14, 19, 18, 21, 13, 3, 5, 4, 9, 7, 8],
                "best-individual-distance": 47546.51890667916,
                "worst-individual-sequence": [25, 12, 4, 3, 7, 2, 1, 6, 10, 21, 27, 28, 23, 24, 17, 13, 8, 11, 14, 18, 22, 19, 9, 5, 15, 20, 29, 26, 16],
                "worst-individual-distance": 65720.5564687835,
                "average-distance": 61456.6755858128,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 6, 2, 1, 12, 10, 15, 26, 20, 23, 27, 24, 25, 22, 29, 28, 16, 17, 14, 19, 18, 21, 13, 3, 5, 4, 9, 7, 8],
                "best-individual-distance": 47546.51890667916,
                "worst-individual-sequence": [3, 4, 27, 20, 17, 14, 16, 18, 7, 9, 6, 2, 1, 13, 5, 12, 8, 22, 21, 19, 15, 23, 29, 26, 24, 28, 25, 11, 10],
                "worst-individual-distance": 65095.12448803342,
                "average-distance": 60887.82469135847,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 6, 2, 1, 12, 10, 15, 26, 20, 23, 27, 24, 25, 22, 29, 28, 16, 17, 14, 19, 18, 21, 13, 3, 5, 4, 9, 7, 8],
                "best-individual-distance": 47546.51890667916,
                "worst-individual-sequence": [9, 12, 19, 15, 29, 17, 20, 27, 14, 22, 25, 23, 18, 28, 5, 8, 7, 11, 26, 16, 24, 21, 13, 3, 4, 2, 1, 6, 10],
                "worst-individual-distance": 64419.01772811651,
                "average-distance": 60360.70566602728,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 6, 2, 1, 12, 10, 15, 26, 20, 23, 27, 24, 25, 22, 29, 28, 16, 17, 14, 19, 18, 21, 13, 3, 5, 4, 9, 7, 8],
                "best-individual-distance": 47546.51890667916,
                "worst-individual-sequence": [6, 9, 7, 10, 1, 4, 26, 20, 23, 27, 24, 25, 17, 12, 8, 3, 15, 22, 29, 28, 16, 14, 19, 13, 18, 21, 11, 5, 2],
                "worst-individual-distance": 63871.221087025435,
                "average-distance": 59795.3217472342,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 6, 2, 1, 12, 10, 15, 26, 20, 23, 27, 24, 25, 22, 29, 28, 16, 17, 14, 19, 18, 21, 13, 3, 5, 4, 9, 7, 8],
                "best-individual-distance": 47546.51890667916,
                "worst-individual-sequence": [7, 8, 9, 5, 4, 12, 10, 13, 15, 26, 20, 17, 22, 25, 23, 27, 24, 29, 28, 16, 18, 11, 14, 19, 21, 1, 6, 2, 3],
                "worst-individual-distance": 63244.44031878543,
                "average-distance": 59316.36124790579,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 6, 2, 1, 12, 10, 15, 26, 20, 23, 27, 24, 25, 22, 29, 28, 16, 17, 14, 19, 18, 21, 13, 3, 5, 4, 9, 7, 8],
                "best-individual-distance": 47546.51890667916,
                "worst-individual-sequence": [13, 18, 9, 19, 15, 26, 23, 24, 20, 27, 29, 22, 21, 14, 25, 17, 28, 16, 7, 8, 11, 12, 2, 6, 10, 1, 5, 4, 3],
                "worst-individual-distance": 62722.66986150327,
                "average-distance": 58831.89224966657,
                "individual-distances": []
            }, {
                "best-individual-sequence": [6, 4, 9, 12, 15, 20, 17, 14, 26, 25, 24, 16, 27, 28, 23, 29, 19, 22, 21, 18, 11, 5, 7, 13, 3, 8, 10, 2, 1],
                "best-individual-distance": 47106.78216621387,
                "worst-individual-sequence": [11, 12, 4, 3, 7, 5, 1, 6, 10, 8, 15, 26, 20, 25, 23, 22, 27, 24, 29, 28, 16, 17, 14, 19, 13, 18, 21, 2, 9],
                "worst-individual-distance": 62161.2821349143,
                "average-distance": 58401.42626265625,
                "individual-distances": []
            }, {
                "best-individual-sequence": [6, 4, 9, 12, 15, 20, 17, 14, 26, 25, 24, 16, 27, 28, 23, 29, 19, 22, 21, 18, 11, 5, 7, 13, 3, 8, 10, 2, 1],
                "best-individual-distance": 47106.78216621387,
                "worst-individual-sequence": [11, 5, 8, 3, 4, 7, 2, 1, 6, 10, 29, 26, 27, 9, 12, 15, 19, 25, 14, 16, 28, 13, 17, 24, 20, 22, 21, 23, 18],
                "worst-individual-distance": 61757.21897453006,
                "average-distance": 57989.26613819583,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 5, 4, 3, 9, 7, 8, 12, 23, 21, 29, 28, 16, 27, 24, 25, 17, 14, 13, 22, 18, 19, 10, 1, 2, 6, 11, 15, 26],
                "best-individual-distance": 47102.223079659765,
                "worst-individual-sequence": [8, 11, 18, 14, 12, 3, 1, 2, 10, 28, 16, 20, 23, 27, 24, 25, 17, 21, 26, 15, 29, 22, 19, 13, 6, 7, 4, 5, 9],
                "worst-individual-distance": 61145.50318986682,
                "average-distance": 57601.80160385036,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 1, 11, 12, 10, 15, 22, 20, 26, 25, 24, 16, 27, 28, 23, 29, 18, 17, 14, 13, 19, 21, 8, 3, 7, 9, 6, 2, 5],
                "best-individual-distance": 46635.70930660476,
                "worst-individual-sequence": [4, 1, 2, 10, 11, 19, 26, 20, 23, 29, 16, 27, 24, 25, 17, 22, 13, 18, 12, 6, 28, 21, 14, 3, 7, 8, 9, 15, 5],
                "worst-individual-distance": 60760.42777528388,
                "average-distance": 57200.79643045246,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 1, 11, 12, 10, 15, 22, 20, 26, 25, 24, 16, 27, 28, 23, 29, 18, 17, 14, 13, 19, 21, 8, 3, 7, 9, 6, 2, 5],
                "best-individual-distance": 46635.70930660476,
                "worst-individual-sequence": [5, 8, 3, 4, 7, 2, 1, 6, 10, 21, 29, 26, 27, 9, 12, 15, 19, 25, 14, 16, 28, 13, 17, 24, 20, 22, 23, 18, 11],
                "worst-individual-distance": 60378.070108467844,
                "average-distance": 56748.96358956451,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 7, 3, 6, 11, 12, 10, 15, 22, 26, 20, 23, 29, 27, 24, 25, 17, 14, 16, 28, 21, 18, 19, 13, 1, 2, 5, 4, 8],
                "best-individual-distance": 45367.64390110454,
                "worst-individual-sequence": [2, 1, 6, 10, 8, 9, 15, 19, 23, 21, 14, 13, 3, 11, 5, 18, 22, 17, 7, 26, 28, 24, 27, 25, 16, 20, 29, 12, 4],
                "worst-individual-distance": 59963.27009725772,
                "average-distance": 56332.20914059553,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 16, 15, 7, 26, 20, 25, 27, 24, 10, 23, 29, 28, 17, 14, 19, 18, 21, 13, 12, 5, 4, 2, 1, 6, 3, 22, 8, 9],
                "best-individual-distance": 43344.60878151136,
                "worst-individual-sequence": [16, 17, 22, 11, 1, 7, 9, 6, 2, 12, 10, 8, 4, 3, 5, 15, 26, 13, 19, 14, 24, 25, 28, 29, 18, 21, 23, 20, 27],
                "worst-individual-distance": 59481.75148786605,
                "average-distance": 55841.94476021805,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 16, 15, 7, 26, 20, 25, 27, 24, 10, 23, 29, 28, 17, 14, 19, 18, 21, 13, 12, 5, 4, 2, 1, 6, 3, 22, 8, 9],
                "best-individual-distance": 43344.60878151136,
                "worst-individual-sequence": [1, 6, 9, 11, 21, 18, 19, 12, 10, 15, 22, 26, 20, 25, 23, 27, 24, 29, 16, 17, 28, 13, 14, 8, 5, 3, 4, 7, 2],
                "worst-individual-distance": 58862.447660983205,
                "average-distance": 55393.46496387448,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 21, 22, 19, 12, 10, 15, 26, 20, 25, 24, 16, 27, 28, 23, 29, 18, 17, 14, 13, 7, 3, 9, 8, 5, 6, 2, 1, 4],
                "best-individual-distance": 43165.37206247262,
                "worst-individual-sequence": [26, 20, 21, 7, 4, 2, 1, 6, 10, 12, 19, 23, 27, 16, 24, 25, 17, 22, 29, 28, 18, 14, 9, 11, 5, 3, 8, 13, 15],
                "worst-individual-distance": 58421.25284147148,
                "average-distance": 55028.73987486004,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 21, 22, 19, 12, 10, 15, 26, 20, 25, 24, 16, 27, 28, 23, 29, 18, 17, 14, 13, 7, 3, 9, 8, 5, 6, 2, 1, 4],
                "best-individual-distance": 43165.37206247262,
                "worst-individual-sequence": [8, 4, 7, 2, 1, 6, 10, 11, 5, 9, 3, 25, 22, 21, 24, 20, 27, 29, 28, 16, 17, 26, 23, 13, 12, 18, 19, 14, 15],
                "worst-individual-distance": 58057.3978389438,
                "average-distance": 54628.51422780117,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 8, 12, 10, 15, 2, 20, 23, 28, 16, 27, 24, 25, 29, 21, 22, 19, 18, 14, 17, 13, 3, 7, 9, 5, 4, 26, 1, 6],
                "best-individual-distance": 41443.69397752658,
                "worst-individual-sequence": [9, 3, 8, 4, 12, 10, 13, 26, 16, 15, 21, 20, 23, 27, 24, 25, 17, 22, 29, 28, 18, 11, 14, 19, 2, 7, 1, 6, 5],
                "worst-individual-distance": 57616.077080753,
                "average-distance": 54200.29759710876,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 16, 15, 7, 26, 20, 25, 27, 24, 10, 23, 29, 28, 17, 14, 19, 18, 21, 13, 12, 5, 4, 2, 1, 6, 3, 22, 8, 9],
                "best-individual-distance": 41118.55446807337,
                "worst-individual-sequence": [23, 29, 3, 7, 8, 9, 5, 13, 26, 20, 27, 24, 25, 15, 16, 17, 28, 21, 14, 18, 19, 4, 2, 1, 6, 11, 12, 10, 22],
                "worst-individual-distance": 57199.96556743672,
                "average-distance": 53817.80695982609,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 16, 15, 7, 26, 20, 25, 27, 24, 10, 23, 29, 28, 17, 14, 19, 18, 21, 13, 12, 5, 4, 2, 1, 6, 3, 22, 8, 9],
                "best-individual-distance": 41118.55446807337,
                "worst-individual-sequence": [11, 4, 7, 21, 18, 14, 12, 3, 1, 2, 10, 15, 26, 20, 25, 27, 24, 28, 16, 17, 23, 29, 19, 22, 8, 13, 9, 5, 6],
                "worst-individual-distance": 56705.446129918695,
                "average-distance": 53333.04093088404,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 16, 15, 7, 26, 20, 25, 27, 24, 10, 23, 29, 28, 17, 14, 19, 18, 21, 13, 12, 5, 4, 2, 1, 6, 3, 22, 8, 9],
                "best-individual-distance": 41118.55446807337,
                "worst-individual-sequence": [17, 7, 6, 2, 12, 8, 16, 14, 13, 9, 3, 10, 11, 1, 5, 4, 18, 21, 22, 19, 15, 23, 29, 26, 24, 28, 25, 27, 20],
                "worst-individual-distance": 56248.56954840259,
                "average-distance": 52866.30918105663,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 16, 15, 7, 26, 20, 25, 27, 24, 10, 23, 29, 28, 17, 14, 19, 18, 21, 13, 12, 5, 4, 2, 1, 6, 3, 22, 8, 9],
                "best-individual-distance": 41118.55446807337,
                "worst-individual-sequence": [2, 6, 1, 11, 9, 7, 8, 12, 10, 15, 22, 26, 20, 25, 23, 27, 24, 29, 28, 16, 17, 14, 19, 18, 21, 13, 3, 5, 4],
                "worst-individual-distance": 55840.93608389382,
                "average-distance": 52462.735115612435,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 16, 15, 7, 26, 20, 25, 27, 24, 10, 23, 29, 28, 17, 14, 19, 18, 21, 13, 12, 5, 4, 2, 1, 6, 3, 22, 8, 9],
                "best-individual-distance": 41118.55446807337,
                "worst-individual-sequence": [9, 8, 11, 21, 7, 14, 12, 3, 1, 2, 10, 15, 26, 20, 25, 27, 24, 28, 16, 17, 23, 29, 22, 19, 13, 6, 18, 4, 5],
                "worst-individual-distance": 55429.61885253334,
                "average-distance": 52037.735603801,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 16, 15, 7, 26, 20, 25, 27, 24, 10, 23, 29, 28, 17, 14, 19, 18, 21, 13, 12, 5, 4, 2, 1, 6, 3, 22, 8, 9],
                "best-individual-distance": 41118.55446807337,
                "worst-individual-sequence": [17, 7, 6, 2, 12, 8, 16, 14, 13, 9, 3, 10, 11, 1, 5, 4, 18, 21, 22, 19, 15, 23, 29, 26, 24, 28, 25, 27, 20],
                "worst-individual-distance": 55019.180965608524,
                "average-distance": 51629.62968872861,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 16, 15, 7, 26, 20, 25, 27, 24, 10, 23, 29, 28, 17, 14, 19, 18, 21, 13, 12, 5, 4, 2, 1, 6, 3, 22, 8, 9],
                "best-individual-distance": 41118.55446807337,
                "worst-individual-sequence": [4, 1, 12, 10, 15, 22, 26, 20, 25, 23, 27, 24, 16, 28, 21, 29, 18, 17, 14, 13, 19, 11, 3, 7, 6, 2, 8, 9, 5],
                "worst-individual-distance": 54467.26390679465,
                "average-distance": 51209.6963898684,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 10, 15, 21, 26, 20, 25, 27, 24, 28, 16, 17, 23, 29, 22, 19, 18, 14, 13, 2, 7, 9, 5, 4, 3, 1, 6, 11, 8],
                "best-individual-distance": 40020.95909596056,
                "worst-individual-sequence": [10, 9, 12, 15, 19, 26, 4, 23, 21, 29, 28, 20, 16, 27, 24, 25, 17, 14, 13, 22, 18, 11, 5, 8, 3, 7, 2, 1, 6],
                "worst-individual-distance": 54056.59655565236,
                "average-distance": 50815.81361164909,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 10, 15, 21, 26, 20, 25, 27, 24, 28, 16, 17, 23, 29, 22, 19, 18, 14, 13, 2, 7, 9, 5, 4, 3, 1, 6, 11, 8],
                "best-individual-distance": 40020.95909596056,
                "worst-individual-sequence": [18, 22, 21, 14, 12, 5, 8, 3, 1, 2, 10, 15, 26, 20, 25, 27, 24, 28, 16, 17, 23, 29, 19, 13, 7, 11, 6, 4, 9],
                "worst-individual-distance": 53713.805923601234,
                "average-distance": 50445.48279583705,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 10, 15, 21, 26, 20, 25, 27, 24, 28, 16, 17, 23, 29, 22, 19, 18, 14, 13, 2, 7, 9, 5, 4, 3, 1, 6, 11, 8],
                "best-individual-distance": 40020.95909596056,
                "worst-individual-sequence": [9, 3, 5, 8, 4, 7, 11, 12, 10, 15, 22, 26, 20, 25, 23, 27, 24, 29, 28, 16, 17, 14, 19, 18, 21, 2, 1, 6, 13],
                "worst-individual-distance": 53337.16651367664,
                "average-distance": 50084.81065606658,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 15, 19, 21, 23, 26, 27, 24, 25, 10, 29, 28, 20, 16, 18, 17, 14, 13, 7, 3, 9, 8, 5, 4, 11, 6, 2, 1, 22],
                "best-individual-distance": 38848.98340632172,
                "worst-individual-sequence": [4, 1, 2, 10, 11, 5, 19, 26, 20, 23, 29, 28, 16, 27, 24, 25, 17, 22, 14, 13, 18, 12, 6, 3, 7, 8, 9, 15, 21],
                "worst-individual-distance": 52926.91916320707,
                "average-distance": 49738.91583834358,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 15, 19, 21, 23, 26, 27, 24, 25, 10, 29, 28, 20, 16, 18, 17, 14, 13, 7, 3, 9, 8, 5, 4, 11, 6, 2, 1, 22],
                "best-individual-distance": 38848.98340632172,
                "worst-individual-sequence": [5, 4, 1, 11, 12, 10, 15, 26, 20, 25, 27, 24, 16, 28, 23, 29, 17, 22, 14, 21, 18, 19, 13, 6, 7, 3, 2, 8, 9],
                "worst-individual-distance": 52608.062061585566,
                "average-distance": 49346.66431147902,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 15, 19, 21, 23, 26, 27, 24, 25, 10, 29, 28, 20, 16, 18, 17, 14, 13, 7, 3, 9, 8, 5, 4, 11, 6, 2, 1, 22],
                "best-individual-distance": 38848.98340632172,
                "worst-individual-sequence": [5, 4, 7, 8, 12, 10, 15, 22, 26, 20, 19, 23, 21, 17, 25, 27, 24, 29, 28, 16, 14, 18, 13, 2, 6, 1, 9, 11, 3],
                "worst-individual-distance": 52368.441116597874,
                "average-distance": 48994.93327315646,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 29, 19, 18, 26, 23, 28, 20, 16, 27, 24, 25, 15, 22, 21, 17, 14, 13, 7, 12, 4, 3, 8, 9, 5, 2, 1, 6, 11],
                "best-individual-distance": 38682.257478303974,
                "worst-individual-sequence": [7, 8, 2, 12, 15, 22, 26, 20, 25, 23, 29, 27, 24, 16, 17, 28, 21, 14, 18, 19, 13, 6, 10, 11, 1, 5, 9, 4, 3],
                "worst-individual-distance": 51948.68552164263,
                "average-distance": 48627.358542184345,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 20, 25, 27, 24, 16, 13, 29, 28, 17, 14, 19, 18, 21, 23, 11, 10, 6, 1, 2, 5, 8, 3, 4, 7, 9, 12, 15, 22],
                "best-individual-distance": 38651.23988867779,
                "worst-individual-sequence": [6, 11, 2, 12, 10, 15, 22, 26, 20, 27, 24, 25, 23, 29, 14, 28, 16, 17, 21, 18, 19, 13, 3, 9, 5, 8, 4, 7, 1],
                "worst-individual-distance": 51495.88608308722,
                "average-distance": 48211.496664796796,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 20, 25, 27, 24, 16, 13, 29, 28, 17, 14, 19, 18, 21, 23, 11, 10, 6, 1, 2, 5, 8, 3, 4, 7, 9, 12, 15, 22],
                "best-individual-distance": 38651.23988867779,
                "worst-individual-sequence": [7, 3, 6, 8, 9, 5, 15, 26, 20, 23, 29, 28, 16, 27, 24, 25, 17, 14, 13, 22, 21, 18, 19, 12, 2, 1, 4, 11, 10],
                "worst-individual-distance": 51190.90021306941,
                "average-distance": 47908.946567644394,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 20, 25, 27, 24, 16, 13, 29, 28, 17, 14, 19, 18, 21, 23, 11, 10, 6, 1, 2, 5, 8, 3, 4, 7, 9, 12, 15, 22],
                "best-individual-distance": 38651.23988867779,
                "worst-individual-sequence": [9, 5, 6, 2, 1, 4, 12, 10, 15, 26, 20, 27, 24, 25, 17, 22, 29, 28, 21, 23, 16, 18, 11, 3, 14, 19, 7, 8, 13],
                "worst-individual-distance": 50795.12249683388,
                "average-distance": 47598.64488597214,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 20, 25, 27, 24, 16, 13, 29, 28, 17, 14, 19, 18, 21, 23, 11, 10, 6, 1, 2, 5, 8, 3, 4, 7, 9, 12, 15, 22],
                "best-individual-distance": 38651.23988867779,
                "worst-individual-sequence": [7, 15, 19, 22, 14, 26, 23, 28, 20, 27, 24, 16, 25, 17, 29, 18, 13, 3, 8, 5, 6, 2, 21, 9, 4, 1, 11, 12, 10],
                "worst-individual-distance": 50449.66135455443,
                "average-distance": 47271.49393695139,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 15, 19, 18, 26, 23, 28, 20, 16, 27, 24, 25, 29, 22, 21, 17, 14, 13, 12, 4, 5, 3, 7, 8, 9, 2, 1, 6, 11],
                "best-individual-distance": 37724.6785289732,
                "worst-individual-sequence": [11, 12, 10, 15, 26, 20, 23, 29, 28, 16, 27, 24, 25, 17, 22, 14, 21, 18, 19, 13, 3, 7, 8, 2, 6, 9, 5, 4, 1],
                "worst-individual-distance": 50061.95710181184,
                "average-distance": 46894.27312999906,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 20, 25, 27, 24, 16, 17, 14, 19, 18, 23, 29, 28, 21, 11, 12, 10, 6, 1, 2, 5, 8, 3, 4, 7, 9, 15, 13, 22],
                "best-individual-distance": 37647.989933388504,
                "worst-individual-sequence": [9, 12, 10, 15, 26, 20, 16, 14, 18, 11, 19, 27, 24, 25, 17, 22, 29, 28, 21, 23, 13, 4, 7, 8, 5, 6, 2, 1, 3],
                "worst-individual-distance": 49811.5242644212,
                "average-distance": 46642.83074109924,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 20, 25, 27, 24, 16, 17, 14, 19, 18, 23, 29, 28, 21, 11, 12, 10, 6, 1, 2, 5, 8, 3, 4, 7, 9, 15, 13, 22],
                "best-individual-distance": 37647.989933388504,
                "worst-individual-sequence": [10, 12, 15, 26, 20, 23, 27, 25, 14, 13, 2, 16, 29, 21, 22, 28, 19, 17, 18, 11, 5, 8, 3, 4, 7, 9, 24, 1, 6],
                "worst-individual-distance": 49496.329480578075,
                "average-distance": 46346.14828532809,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 20, 25, 27, 24, 16, 17, 14, 19, 18, 23, 29, 28, 21, 11, 12, 10, 6, 1, 2, 5, 8, 3, 4, 7, 9, 15, 13, 22],
                "best-individual-distance": 37647.989933388504,
                "worst-individual-sequence": [11, 5, 8, 15, 26, 20, 16, 24, 27, 28, 23, 13, 25, 29, 21, 22, 19, 18, 14, 17, 3, 4, 7, 9, 2, 1, 6, 12, 10],
                "worst-individual-distance": 49169.06214904883,
                "average-distance": 46048.71522834533,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 20, 25, 27, 24, 16, 17, 14, 19, 18, 23, 29, 28, 21, 11, 12, 10, 6, 1, 2, 5, 8, 3, 4, 7, 9, 15, 13, 22],
                "best-individual-distance": 37647.989933388504,
                "worst-individual-sequence": [20, 5, 4, 3, 9, 7, 8, 12, 23, 21, 29, 28, 16, 27, 24, 25, 17, 14, 13, 22, 18, 19, 10, 1, 2, 6, 11, 15, 26],
                "worst-individual-distance": 48794.33659860896,
                "average-distance": 45732.559937967584,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 20, 25, 27, 24, 16, 17, 14, 19, 18, 23, 29, 28, 21, 11, 12, 10, 6, 1, 2, 5, 8, 3, 4, 7, 9, 15, 13, 22],
                "best-individual-distance": 37647.989933388504,
                "worst-individual-sequence": [12, 10, 15, 26, 23, 21, 22, 29, 28, 20, 27, 24, 16, 25, 17, 14, 18, 13, 11, 19, 7, 8, 5, 6, 2, 1, 3, 9, 4],
                "worst-individual-distance": 48492.9480191652,
                "average-distance": 45449.15960155137,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 20, 25, 27, 24, 16, 17, 14, 19, 18, 23, 29, 28, 21, 11, 12, 10, 6, 1, 2, 5, 8, 3, 4, 7, 9, 15, 13, 22],
                "best-individual-distance": 37647.989933388504,
                "worst-individual-sequence": [11, 12, 10, 15, 23, 18, 22, 21, 29, 26, 27, 25, 17, 24, 14, 13, 19, 28, 16, 20, 7, 3, 9, 8, 5, 6, 2, 1, 4],
                "worst-individual-distance": 48197.6512953284,
                "average-distance": 45204.40746104583,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 20, 25, 27, 24, 16, 17, 14, 19, 18, 23, 29, 28, 21, 2, 12, 8, 3, 7, 9, 5, 4, 13, 1, 6, 10, 11, 15, 22],
                "best-individual-distance": 36459.48811433246,
                "worst-individual-sequence": [15, 22, 26, 21, 14, 18, 20, 19, 23, 17, 25, 27, 24, 16, 29, 28, 13, 11, 5, 4, 2, 1, 6, 10, 12, 8, 9, 7, 3],
                "worst-individual-distance": 47850.56660795499,
                "average-distance": 44895.88565303732,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 22, 28, 26, 20, 25, 27, 24, 16, 23, 29, 18, 17, 14, 13, 4, 3, 7, 8, 9, 5, 2, 1, 6, 11, 12, 10, 15, 19],
                "best-individual-distance": 36219.960620957,
                "worst-individual-sequence": [9, 7, 12, 10, 11, 15, 19, 18, 20, 25, 28, 16, 17, 22, 29, 27, 24, 21, 23, 14, 26, 13, 3, 5, 4, 2, 1, 6, 8],
                "worst-individual-distance": 47527.72230913131,
                "average-distance": 44642.59087455694,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 22, 28, 26, 20, 25, 27, 24, 16, 23, 29, 18, 17, 14, 13, 4, 3, 7, 8, 9, 5, 2, 1, 6, 11, 12, 10, 15, 19],
                "best-individual-distance": 36219.960620957,
                "worst-individual-sequence": [1, 11, 12, 10, 15, 26, 20, 23, 28, 16, 27, 24, 25, 29, 21, 22, 19, 18, 14, 17, 13, 3, 7, 8, 9, 6, 2, 5, 4],
                "worst-individual-distance": 47236.264426228954,
                "average-distance": 44352.399579376615,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 22, 28, 26, 20, 25, 27, 24, 16, 23, 29, 18, 17, 14, 13, 4, 3, 7, 8, 9, 5, 2, 1, 6, 11, 12, 10, 15, 19],
                "best-individual-distance": 36219.960620957,
                "worst-individual-sequence": [12, 6, 10, 15, 26, 20, 25, 27, 24, 28, 16, 17, 23, 29, 22, 21, 14, 18, 19, 13, 8, 3, 7, 9, 1, 2, 4, 5, 11],
                "worst-individual-distance": 46915.02338533852,
                "average-distance": 44103.6448963208,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 22, 28, 26, 20, 25, 27, 24, 16, 23, 29, 18, 17, 14, 13, 4, 3, 7, 8, 9, 5, 2, 1, 6, 11, 12, 10, 15, 19],
                "best-individual-distance": 36219.960620957,
                "worst-individual-sequence": [22, 26, 20, 25, 24, 16, 27, 28, 23, 29, 17, 14, 19, 18, 13, 6, 11, 10, 8, 12, 4, 9, 3, 2, 1, 5, 7, 15, 21],
                "worst-individual-distance": 46606.17390978788,
                "average-distance": 43863.40452425728,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 22, 28, 26, 20, 25, 27, 24, 16, 23, 29, 18, 17, 14, 13, 4, 3, 7, 8, 9, 5, 2, 1, 6, 11, 12, 10, 15, 19],
                "best-individual-distance": 36219.960620957,
                "worst-individual-sequence": [6, 2, 1, 22, 10, 15, 26, 20, 23, 27, 24, 25, 12, 29, 28, 16, 14, 19, 18, 21, 17, 13, 3, 5, 4, 9, 7, 8, 11],
                "worst-individual-distance": 46296.84645819791,
                "average-distance": 43596.18042504349,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 22, 28, 26, 20, 25, 27, 24, 16, 23, 29, 18, 17, 14, 13, 4, 3, 7, 8, 9, 5, 2, 1, 6, 11, 12, 10, 15, 19],
                "best-individual-distance": 36219.960620957,
                "worst-individual-sequence": [5, 12, 15, 20, 24, 16, 28, 18, 22, 21, 29, 26, 27, 25, 23, 17, 14, 19, 13, 3, 7, 8, 9, 11, 2, 1, 6, 10, 4],
                "worst-individual-distance": 46060.92377825472,
                "average-distance": 43369.32366940601,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 22, 28, 26, 20, 25, 27, 24, 16, 23, 29, 18, 17, 14, 13, 4, 3, 7, 8, 9, 5, 2, 1, 6, 11, 12, 10, 15, 19],
                "best-individual-distance": 36219.960620957,
                "worst-individual-sequence": [10, 15, 22, 26, 20, 25, 27, 24, 16, 23, 29, 28, 17, 14, 19, 18, 21, 12, 5, 13, 3, 4, 2, 1, 6, 7, 8, 9, 11],
                "worst-individual-distance": 45761.71568025656,
                "average-distance": 43155.66093949465,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 21, 22, 29, 28, 20, 16, 27, 24, 25, 26, 17, 14, 19, 18, 13, 8, 4, 3, 7, 9, 5, 2, 1, 6, 11, 12, 10, 15],
                "best-individual-distance": 35785.634999050875,
                "worst-individual-sequence": [19, 21, 22, 29, 26, 28, 16, 20, 25, 24, 27, 15, 18, 17, 14, 13, 4, 3, 8, 9, 5, 7, 2, 1, 6, 11, 12, 10, 23],
                "worst-individual-distance": 45520.023794893496,
                "average-distance": 42887.22999632784,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 21, 22, 29, 28, 20, 16, 27, 24, 25, 26, 17, 14, 19, 18, 13, 8, 4, 3, 7, 9, 5, 2, 1, 6, 11, 12, 10, 15],
                "best-individual-distance": 35785.634999050875,
                "worst-individual-sequence": [22, 23, 29, 28, 20, 16, 27, 24, 25, 26, 17, 14, 19, 18, 21, 13, 8, 4, 12, 11, 5, 9, 2, 1, 6, 7, 3, 10, 15],
                "worst-individual-distance": 45194.87066128176,
                "average-distance": 42658.66814567076,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 28, 26, 20, 25, 27, 24, 16, 29, 22, 21, 17, 14, 13, 12, 4, 5, 3, 7, 8, 9, 2, 1, 6, 11, 10, 15, 19, 18],
                "best-individual-distance": 35226.55669764358,
                "worst-individual-sequence": [1, 12, 11, 10, 15, 23, 22, 26, 20, 25, 24, 27, 29, 28, 16, 17, 14, 19, 18, 21, 13, 3, 4, 7, 8, 5, 9, 6, 2],
                "worst-individual-distance": 44875.85158613725,
                "average-distance": 42444.8277354874,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 28, 26, 20, 25, 27, 24, 16, 29, 22, 21, 17, 14, 13, 12, 4, 5, 3, 7, 8, 9, 2, 1, 6, 11, 10, 15, 19, 18],
                "best-individual-distance": 35226.55669764358,
                "worst-individual-sequence": [8, 2, 6, 15, 22, 26, 20, 23, 29, 27, 24, 16, 25, 17, 28, 21, 14, 18, 19, 13, 12, 10, 11, 1, 5, 4, 3, 9, 7],
                "worst-individual-distance": 44620.01759667352,
                "average-distance": 42242.671999322854,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 28, 26, 20, 25, 27, 24, 16, 29, 22, 21, 17, 14, 13, 12, 4, 5, 3, 7, 8, 9, 2, 1, 6, 11, 10, 15, 19, 18],
                "best-individual-distance": 35226.55669764358,
                "worst-individual-sequence": [1, 6, 10, 15, 19, 21, 20, 27, 24, 2, 22, 26, 16, 25, 23, 29, 28, 17, 14, 13, 11, 12, 3, 7, 8, 9, 5, 4, 18],
                "worst-individual-distance": 44404.16411041313,
                "average-distance": 42029.782572525124,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 28, 26, 20, 25, 27, 24, 16, 29, 22, 21, 17, 14, 13, 12, 4, 5, 3, 7, 8, 9, 2, 1, 6, 11, 10, 15, 19, 18],
                "best-individual-distance": 35226.55669764358,
                "worst-individual-sequence": [10, 15, 23, 22, 25, 27, 24, 16, 29, 28, 26, 20, 17, 21, 19, 18, 14, 13, 3, 7, 8, 9, 1, 2, 5, 4, 11, 6, 12],
                "worst-individual-distance": 44179.3786549159,
                "average-distance": 41843.745954052894,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 28, 26, 20, 25, 27, 24, 16, 29, 22, 21, 17, 14, 13, 12, 4, 5, 3, 7, 8, 9, 2, 1, 6, 11, 10, 15, 19, 18],
                "best-individual-distance": 35226.55669764358,
                "worst-individual-sequence": [2, 10, 15, 26, 20, 23, 21, 19, 18, 17, 29, 28, 16, 27, 24, 25, 22, 14, 13, 12, 3, 7, 11, 1, 6, 4, 8, 5, 9],
                "worst-individual-distance": 43877.57485703494,
                "average-distance": 41642.15648988126,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 28, 26, 20, 25, 27, 24, 16, 29, 22, 21, 17, 14, 13, 12, 4, 5, 3, 7, 8, 9, 2, 1, 6, 11, 10, 15, 19, 18],
                "best-individual-distance": 35226.55669764358,
                "worst-individual-sequence": [12, 10, 15, 26, 23, 21, 22, 29, 28, 20, 16, 27, 24, 25, 17, 18, 19, 14, 7, 8, 13, 9, 5, 6, 2, 1, 3, 11, 4],
                "worst-individual-distance": 43682.25000213239,
                "average-distance": 41468.48825599866,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 22, 29, 28, 23, 21, 15, 19, 18, 26, 20, 16, 27, 24, 25, 17, 14, 13, 12, 8, 4, 3, 7, 9, 5, 2, 1, 6, 10],
                "best-individual-distance": 34613.43250776065,
                "worst-individual-sequence": [11, 15, 26, 20, 28, 27, 25, 21, 22, 2, 16, 17, 23, 29, 19, 18, 14, 13, 3, 5, 4, 24, 1, 6, 8, 9, 7, 12, 10],
                "worst-individual-distance": 43447.01521683887,
                "average-distance": 41305.44791121329,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 22, 29, 28, 23, 21, 15, 19, 18, 26, 20, 16, 27, 24, 25, 17, 14, 13, 12, 8, 4, 3, 7, 9, 5, 2, 1, 6, 10],
                "best-individual-distance": 34613.43250776065,
                "worst-individual-sequence": [12, 10, 15, 23, 26, 22, 29, 20, 16, 27, 24, 25, 21, 19, 28, 18, 14, 17, 13, 4, 3, 7, 8, 9, 5, 2, 1, 6, 11],
                "worst-individual-distance": 43243.647448498166,
                "average-distance": 41147.80122257925,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 22, 29, 28, 23, 21, 15, 19, 18, 26, 20, 16, 27, 24, 25, 17, 14, 13, 12, 8, 4, 3, 7, 9, 5, 2, 1, 6, 10],
                "best-individual-distance": 34613.43250776065,
                "worst-individual-sequence": [11, 10, 15, 26, 25, 27, 24, 16, 23, 22, 29, 28, 20, 17, 14, 19, 18, 21, 13, 12, 5, 4, 3, 2, 6, 1, 8, 9, 7],
                "worst-individual-distance": 43039.503769150026,
                "average-distance": 40994.41419637701,
                "individual-distances": []
            }
        ],
        [
            [{
                "time_cost": 0
            }], {
                "best-individual-sequence": [24, 16, 7, 9, 27, 29, 28, 14, 17, 4, 3, 11, 19, 23, 12, 8, 2, 1, 15, 6, 10, 13, 5, 18, 22, 26, 25, 21, 20],
                "best-individual-distance": 76001.87783971152,
                "worst-individual-sequence": [23, 11, 16, 6, 26, 2, 27, 9, 12, 15, 17, 4, 10, 13, 24, 22, 1, 25, 28, 20, 14, 18, 19, 3, 8, 29, 21, 5, 7],
                "worst-individual-distance": 120834.8462900896,
                "average-distance": 106602.45880517231,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 3, 5, 27, 1, 23, 9, 14, 21, 16, 20, 15, 28, 11, 10, 13, 7, 6, 2, 8, 12, 19, 29, 4, 22, 18, 24, 25, 26],
                "best-individual-distance": 70470.18632469258,
                "worst-individual-sequence": [22, 3, 16, 28, 15, 21, 6, 26, 7, 12, 5, 11, 24, 9, 8, 13, 14, 23, 10, 18, 19, 4, 29, 20, 27, 25, 2, 17, 1],
                "worst-individual-distance": 115615.6108193318,
                "average-distance": 103867.62419033963,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 8, 6, 11, 5, 10, 4, 1, 2, 3, 7, 27, 15, 13, 12, 18, 21, 19, 9, 16, 28, 14, 24, 26, 20, 29, 23, 22, 25],
                "best-individual-distance": 67662.30590291473,
                "worst-individual-sequence": [12, 21, 20, 26, 11, 16, 15, 2, 24, 9, 4, 28, 27, 18, 29, 25, 8, 3, 14, 19, 23, 7, 17, 5, 13, 1, 22, 6, 10],
                "worst-individual-distance": 112337.93228125252,
                "average-distance": 101134.40547547815,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 8, 6, 11, 5, 10, 4, 1, 2, 3, 7, 27, 15, 13, 12, 18, 21, 19, 9, 16, 28, 14, 24, 26, 20, 29, 23, 22, 25],
                "best-individual-distance": 67662.30590291473,
                "worst-individual-sequence": [2, 13, 16, 25, 29, 4, 7, 17, 19, 9, 12, 22, 1, 24, 27, 18, 26, 14, 15, 23, 10, 3, 21, 11, 28, 8, 6, 5, 20],
                "worst-individual-distance": 109177.14465291944,
                "average-distance": 98903.69195528698,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 8, 6, 11, 5, 10, 4, 1, 2, 3, 7, 27, 15, 13, 12, 18, 21, 19, 9, 16, 28, 14, 24, 26, 20, 29, 23, 22, 25],
                "best-individual-distance": 67662.30590291473,
                "worst-individual-sequence": [18, 26, 6, 21, 23, 19, 20, 22, 2, 17, 9, 5, 28, 15, 25, 4, 11, 27, 13, 14, 3, 7, 8, 10, 1, 24, 16, 12, 29],
                "worst-individual-distance": 106923.7709115978,
                "average-distance": 96750.59002926956,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 8, 6, 11, 5, 10, 4, 1, 2, 3, 7, 27, 15, 13, 12, 18, 21, 19, 9, 16, 28, 14, 24, 26, 20, 29, 23, 22, 25],
                "best-individual-distance": 67662.30590291473,
                "worst-individual-sequence": [26, 13, 6, 11, 15, 27, 16, 21, 14, 10, 12, 22, 1, 4, 7, 17, 2, 24, 29, 19, 23, 8, 28, 9, 18, 20, 5, 3, 25],
                "worst-individual-distance": 104670.75231689641,
                "average-distance": 94829.25118530392,
                "individual-distances": []
            }, {
                "best-individual-sequence": [15, 21, 17, 25, 19, 13, 6, 11, 5, 10, 4, 1, 2, 9, 7, 12, 16, 27, 28, 3, 8, 14, 24, 26, 20, 29, 18, 23, 22],
                "best-individual-distance": 65842.01684821634,
                "worst-individual-sequence": [27, 26, 20, 11, 15, 17, 7, 16, 19, 28, 4, 3, 24, 8, 2, 5, 13, 18, 23, 14, 25, 9, 21, 1, 12, 22, 29, 10, 6],
                "worst-individual-distance": 102516.97116388184,
                "average-distance": 92780.55976026118,
                "individual-distances": []
            }, {
                "best-individual-sequence": [15, 21, 17, 25, 19, 13, 6, 11, 5, 10, 4, 1, 2, 9, 7, 12, 16, 27, 28, 3, 8, 14, 24, 26, 20, 29, 18, 23, 22],
                "best-individual-distance": 65842.01684821634,
                "worst-individual-sequence": [18, 19, 20, 27, 17, 1, 5, 23, 26, 3, 11, 4, 10, 15, 9, 29, 12, 21, 16, 14, 25, 22, 24, 8, 6, 13, 2, 7, 28],
                "worst-individual-distance": 100174.21345814051,
                "average-distance": 91206.17896444438,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 21, 22, 18, 5, 6, 2, 4, 1, 13, 8, 20, 25, 14, 9, 17, 28, 24, 16, 27, 26, 29, 15, 19, 12, 10, 11, 3, 7],
                "best-individual-distance": 62366.39488858418,
                "worst-individual-sequence": [1, 24, 14, 28, 13, 17, 3, 15, 23, 11, 2, 5, 9, 20, 21, 27, 7, 6, 8, 12, 19, 29, 4, 25, 22, 26, 16, 18, 10],
                "worst-individual-distance": 98356.24340880444,
                "average-distance": 89503.54871172844,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 21, 22, 18, 5, 6, 2, 4, 1, 13, 8, 20, 25, 14, 9, 17, 28, 24, 16, 27, 26, 29, 15, 19, 12, 10, 11, 3, 7],
                "best-individual-distance": 62366.39488858418,
                "worst-individual-sequence": [2, 3, 8, 26, 20, 21, 12, 23, 15, 27, 29, 4, 17, 7, 24, 14, 28, 19, 16, 25, 9, 1, 5, 11, 13, 6, 10, 18, 22],
                "worst-individual-distance": 96437.98645000946,
                "average-distance": 88002.67534712043,
                "individual-distances": []
            }, {
                "best-individual-sequence": [22, 15, 18, 26, 20, 24, 27, 16, 14, 28, 25, 9, 17, 11, 10, 13, 7, 6, 2, 8, 12, 19, 29, 4, 3, 5, 23, 1, 21],
                "best-individual-distance": 60463.0379656017,
                "worst-individual-sequence": [19, 29, 28, 22, 9, 1, 11, 17, 25, 23, 18, 12, 2, 13, 27, 15, 7, 10, 16, 20, 26, 4, 8, 24, 3, 5, 6, 21, 14],
                "worst-individual-distance": 94638.31461635335,
                "average-distance": 86507.07602322235,
                "individual-distances": []
            }, {
                "best-individual-sequence": [22, 15, 18, 26, 20, 24, 27, 16, 14, 28, 25, 9, 17, 11, 10, 13, 7, 6, 2, 8, 12, 19, 29, 4, 3, 5, 23, 1, 21],
                "best-individual-distance": 60463.0379656017,
                "worst-individual-sequence": [15, 20, 7, 24, 28, 1, 4, 8, 11, 17, 25, 23, 18, 12, 2, 13, 6, 3, 5, 10, 21, 9, 19, 22, 14, 26, 16, 29, 27],
                "worst-individual-distance": 93025.16999909602,
                "average-distance": 84891.07654079302,
                "individual-distances": []
            }, {
                "best-individual-sequence": [22, 15, 18, 26, 20, 24, 27, 16, 14, 28, 25, 9, 17, 11, 10, 13, 7, 6, 2, 8, 12, 19, 29, 4, 3, 5, 23, 1, 21],
                "best-individual-distance": 60463.0379656017,
                "worst-individual-sequence": [28, 17, 29, 19, 11, 3, 15, 9, 5, 25, 26, 14, 21, 10, 13, 7, 6, 2, 12, 20, 27, 24, 22, 8, 16, 23, 18, 4, 1],
                "worst-individual-distance": 91414.67175269852,
                "average-distance": 83406.30551907438,
                "individual-distances": []
            }, {
                "best-individual-sequence": [22, 15, 18, 26, 20, 24, 27, 16, 14, 28, 25, 9, 17, 11, 10, 13, 7, 6, 2, 8, 12, 19, 29, 4, 3, 5, 23, 1, 21],
                "best-individual-distance": 60463.0379656017,
                "worst-individual-sequence": [11, 4, 1, 29, 26, 16, 2, 6, 5, 9, 17, 14, 23, 27, 20, 25, 7, 18, 13, 10, 15, 3, 8, 22, 28, 24, 19, 12, 21],
                "worst-individual-distance": 89909.78309179957,
                "average-distance": 82119.10423364514,
                "individual-distances": []
            }, {
                "best-individual-sequence": [22, 15, 18, 26, 20, 24, 27, 16, 14, 28, 25, 9, 17, 11, 10, 13, 7, 6, 2, 8, 12, 19, 29, 4, 3, 5, 23, 1, 21],
                "best-individual-distance": 60463.0379656017,
                "worst-individual-sequence": [17, 1, 5, 6, 2, 9, 22, 4, 24, 14, 15, 26, 27, 29, 19, 28, 23, 25, 16, 20, 3, 10, 18, 11, 21, 13, 7, 12, 8],
                "worst-individual-distance": 88351.12636655697,
                "average-distance": 80813.2552915176,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 1, 2, 3, 7, 12, 5, 4, 9, 14, 20, 23, 18, 28, 22, 17, 16, 19, 13, 24, 25, 27, 26, 21, 29, 15, 8, 6, 11],
                "best-individual-distance": 59651.698098314984,
                "worst-individual-sequence": [11, 5, 10, 4, 1, 20, 28, 16, 27, 12, 15, 22, 23, 25, 24, 2, 7, 17, 9, 3, 19, 14, 26, 29, 18, 21, 8, 13, 6],
                "worst-individual-distance": 86841.72073397764,
                "average-distance": 79509.25998852032,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 12, 10, 19, 20, 28, 22, 29, 26, 13, 24, 25, 27, 16, 21, 18, 23, 17, 14, 8, 2, 1, 3, 5, 4, 6, 11, 7, 15],
                "best-individual-distance": 58390.83794925173,
                "worst-individual-sequence": [13, 25, 17, 20, 26, 18, 15, 8, 12, 2, 11, 10, 14, 3, 7, 16, 19, 9, 27, 28, 24, 29, 21, 1, 4, 5, 22, 23, 6],
                "worst-individual-distance": 85306.72274505199,
                "average-distance": 78162.37407614019,
                "individual-distances": []
            }, {
                "best-individual-sequence": [2, 22, 18, 6, 21, 1, 13, 8, 20, 25, 14, 9, 17, 28, 24, 16, 27, 26, 29, 15, 19, 12, 10, 11, 5, 4, 7, 3, 23],
                "best-individual-distance": 56922.76652198446,
                "worst-individual-sequence": [4, 23, 14, 11, 10, 29, 26, 24, 7, 8, 28, 22, 13, 15, 12, 18, 21, 17, 25, 2, 1, 9, 16, 20, 27, 19, 6, 3, 5],
                "worst-individual-distance": 83731.92195210898,
                "average-distance": 76752.21363834933,
                "individual-distances": []
            }, {
                "best-individual-sequence": [2, 22, 18, 6, 21, 1, 13, 8, 20, 25, 14, 9, 17, 28, 24, 16, 27, 26, 29, 15, 19, 12, 10, 11, 5, 4, 7, 3, 23],
                "best-individual-distance": 56922.76652198446,
                "worst-individual-sequence": [3, 21, 10, 8, 20, 25, 14, 24, 9, 5, 12, 6, 13, 16, 17, 28, 27, 26, 15, 19, 23, 22, 18, 1, 2, 4, 7, 11, 29],
                "worst-individual-distance": 82371.36698276062,
                "average-distance": 75592.20124247528,
                "individual-distances": []
            }, {
                "best-individual-sequence": [2, 22, 18, 6, 21, 1, 13, 8, 20, 25, 14, 9, 17, 28, 24, 16, 27, 26, 29, 15, 19, 12, 10, 11, 5, 4, 7, 3, 23],
                "best-individual-distance": 56922.76652198446,
                "worst-individual-sequence": [3, 5, 14, 21, 10, 7, 8, 12, 23, 1, 2, 6, 11, 29, 28, 13, 27, 25, 17, 20, 26, 19, 4, 22, 18, 24, 16, 9, 15],
                "worst-individual-distance": 81055.49145492648,
                "average-distance": 74494.59229541074,
                "individual-distances": []
            }, {
                "best-individual-sequence": [2, 22, 18, 6, 21, 1, 13, 8, 20, 25, 14, 9, 17, 28, 24, 16, 27, 26, 29, 15, 19, 12, 10, 11, 5, 4, 7, 3, 23],
                "best-individual-distance": 56922.76652198446,
                "worst-individual-sequence": [7, 6, 2, 12, 4, 24, 27, 17, 20, 29, 28, 26, 14, 21, 10, 13, 23, 19, 9, 25, 18, 15, 16, 22, 3, 8, 5, 1, 11],
                "worst-individual-distance": 79855.87253779938,
                "average-distance": 73449.15751025527,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 4, 8, 6, 11, 10, 1, 2, 5, 3, 13, 14, 22, 19, 23, 27, 25, 16, 24, 29, 7, 26, 18, 20, 15, 28, 9, 21, 17],
                "best-individual-distance": 53693.831847467955,
                "worst-individual-sequence": [7, 16, 26, 23, 21, 22, 20, 14, 9, 17, 18, 24, 11, 29, 28, 13, 27, 25, 2, 4, 5, 6, 19, 15, 12, 10, 8, 3, 1],
                "worst-individual-distance": 78863.54356841755,
                "average-distance": 72515.72902629223,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 6, 11, 1, 2, 9, 8, 14, 22, 19, 23, 16, 20, 26, 25, 28, 17, 27, 24, 29, 21, 18, 15, 13, 3, 5, 7, 4, 12],
                "best-individual-distance": 53117.90270716741,
                "worst-individual-sequence": [17, 19, 25, 24, 20, 16, 27, 28, 4, 14, 2, 21, 29, 26, 13, 11, 1, 6, 15, 22, 18, 10, 8, 5, 3, 7, 12, 23, 9],
                "worst-individual-distance": 77665.69392241052,
                "average-distance": 71460.41092202812,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 6, 11, 1, 2, 9, 8, 14, 22, 19, 23, 16, 20, 26, 25, 28, 17, 27, 24, 29, 21, 18, 15, 13, 3, 5, 7, 4, 12],
                "best-individual-distance": 53117.90270716741,
                "worst-individual-sequence": [11, 5, 10, 4, 1, 2, 7, 28, 14, 26, 27, 13, 15, 12, 18, 21, 19, 9, 16, 24, 20, 29, 22, 17, 3, 25, 23, 8, 6],
                "worst-individual-distance": 76646.02691152628,
                "average-distance": 70523.56855684856,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 1, 2, 6, 10, 11, 7, 14, 27, 24, 25, 20, 16, 21, 18, 29, 26, 15, 23, 28, 17, 22, 19, 8, 12, 13, 4, 9, 3],
                "best-individual-distance": 50424.681302816054,
                "worst-individual-sequence": [11, 8, 3, 14, 28, 25, 16, 17, 5, 4, 13, 24, 27, 21, 18, 23, 6, 2, 1, 29, 26, 15, 9, 12, 10, 19, 20, 22, 7],
                "worst-individual-distance": 75631.28558598654,
                "average-distance": 69576.80820267394,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 1, 2, 6, 10, 11, 7, 14, 27, 24, 25, 20, 16, 21, 18, 29, 26, 15, 23, 28, 17, 22, 19, 8, 12, 13, 4, 9, 3],
                "best-individual-distance": 50424.681302816054,
                "worst-individual-sequence": [17, 25, 5, 10, 4, 1, 2, 12, 16, 28, 26, 29, 20, 24, 7, 9, 3, 6, 14, 27, 19, 18, 13, 23, 22, 21, 8, 11, 15],
                "worst-individual-distance": 74599.9814671175,
                "average-distance": 68687.22046771488,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 1, 2, 6, 10, 11, 7, 14, 27, 24, 25, 20, 16, 21, 18, 29, 26, 15, 23, 28, 17, 22, 19, 8, 12, 13, 4, 9, 3],
                "best-individual-distance": 50424.681302816054,
                "worst-individual-sequence": [29, 25, 3, 4, 5, 16, 14, 17, 26, 1, 11, 10, 13, 7, 6, 2, 8, 12, 19, 20, 22, 24, 27, 15, 18, 9, 21, 28, 23],
                "worst-individual-distance": 73434.662749002,
                "average-distance": 67862.80422679923,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 1, 2, 6, 10, 11, 7, 14, 27, 24, 25, 20, 16, 21, 18, 29, 26, 15, 23, 28, 17, 22, 19, 8, 12, 13, 4, 9, 3],
                "best-individual-distance": 50424.681302816054,
                "worst-individual-sequence": [14, 27, 29, 28, 23, 16, 20, 22, 25, 21, 19, 13, 1, 11, 10, 7, 6, 2, 8, 12, 15, 26, 24, 17, 9, 4, 5, 18, 3],
                "worst-individual-distance": 72599.69351335055,
                "average-distance": 67123.12881956245,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 1, 2, 6, 10, 11, 7, 14, 27, 24, 25, 20, 16, 21, 18, 29, 26, 15, 23, 28, 17, 22, 19, 8, 12, 13, 4, 9, 3],
                "best-individual-distance": 50424.681302816054,
                "worst-individual-sequence": [5, 10, 4, 7, 12, 28, 20, 9, 11, 1, 3, 13, 8, 14, 22, 19, 23, 27, 25, 16, 24, 29, 21, 26, 18, 2, 6, 17, 15],
                "worst-individual-distance": 71683.77182704755,
                "average-distance": 66452.09499524334,
                "individual-distances": []
            }, {
                "best-individual-sequence": [14, 4, 7, 3, 9, 13, 20, 22, 18, 21, 29, 26, 15, 28, 17, 19, 23, 27, 25, 16, 24, 11, 12, 10, 8, 6, 5, 1, 2],
                "best-individual-distance": 47752.13698363456,
                "worst-individual-sequence": [17, 20, 15, 22, 27, 16, 14, 28, 5, 9, 1, 11, 10, 7, 6, 2, 8, 12, 13, 24, 25, 19, 29, 23, 3, 4, 21, 18, 26],
                "worst-individual-distance": 70866.55308808196,
                "average-distance": 65748.45445221248,
                "individual-distances": []
            }, {
                "best-individual-sequence": [14, 4, 7, 3, 9, 13, 20, 22, 18, 21, 29, 26, 15, 28, 17, 19, 23, 27, 25, 16, 24, 11, 12, 10, 8, 6, 5, 1, 2],
                "best-individual-distance": 47752.13698363456,
                "worst-individual-sequence": [25, 17, 20, 15, 22, 24, 27, 16, 14, 23, 12, 4, 28, 29, 21, 18, 8, 3, 9, 26, 13, 5, 1, 11, 10, 6, 2, 7, 19],
                "worst-individual-distance": 70020.03481959784,
                "average-distance": 65023.166343925084,
                "individual-distances": []
            }, {
                "best-individual-sequence": [14, 4, 7, 3, 9, 13, 20, 22, 18, 21, 29, 26, 15, 28, 17, 19, 23, 27, 25, 16, 24, 11, 12, 10, 8, 6, 5, 1, 2],
                "best-individual-distance": 47752.13698363456,
                "worst-individual-sequence": [16, 14, 25, 1, 2, 6, 11, 29, 28, 3, 5, 9, 12, 8, 4, 13, 19, 18, 23, 21, 10, 7, 26, 17, 20, 15, 22, 24, 27],
                "worst-individual-distance": 69220.29718085608,
                "average-distance": 64285.27876558732,
                "individual-distances": []
            }, {
                "best-individual-sequence": [14, 4, 7, 3, 9, 13, 20, 22, 18, 21, 29, 26, 15, 28, 17, 19, 23, 27, 25, 16, 24, 11, 12, 10, 8, 6, 5, 1, 2],
                "best-individual-distance": 47752.13698363456,
                "worst-individual-sequence": [11, 10, 15, 14, 9, 5, 12, 3, 26, 20, 29, 4, 2, 1, 7, 19, 28, 6, 13, 24, 25, 27, 16, 23, 21, 18, 22, 17, 8],
                "worst-individual-distance": 68423.89619216244,
                "average-distance": 63596.640047206754,
                "individual-distances": []
            }, {
                "best-individual-sequence": [14, 4, 7, 3, 9, 13, 20, 22, 18, 21, 29, 26, 15, 28, 17, 19, 23, 27, 25, 16, 24, 11, 12, 10, 8, 6, 5, 1, 2],
                "best-individual-distance": 47752.13698363456,
                "worst-individual-sequence": [5, 1, 2, 11, 4, 7, 3, 9, 13, 23, 20, 29, 19, 25, 27, 16, 21, 22, 18, 28, 26, 24, 14, 10, 8, 6, 12, 15, 17],
                "worst-individual-distance": 67629.85577190551,
                "average-distance": 62915.3259969164,
                "individual-distances": []
            }, {
                "best-individual-sequence": [14, 4, 7, 3, 9, 13, 20, 22, 18, 21, 29, 26, 15, 28, 17, 19, 23, 27, 25, 16, 24, 11, 12, 10, 8, 6, 5, 1, 2],
                "best-individual-distance": 47752.13698363456,
                "worst-individual-sequence": [10, 17, 28, 20, 9, 11, 1, 3, 13, 14, 25, 16, 24, 29, 21, 27, 26, 15, 19, 22, 23, 12, 8, 18, 5, 6, 2, 7, 4],
                "worst-individual-distance": 66990.66686519748,
                "average-distance": 62347.03226420742,
                "individual-distances": []
            }, {
                "best-individual-sequence": [14, 4, 7, 3, 9, 13, 20, 22, 18, 21, 29, 26, 15, 28, 17, 19, 23, 27, 25, 16, 24, 11, 12, 10, 8, 6, 5, 1, 2],
                "best-individual-distance": 47752.13698363456,
                "worst-individual-sequence": [17, 8, 6, 11, 5, 10, 4, 1, 2, 7, 15, 13, 12, 18, 19, 28, 27, 16, 14, 24, 26, 21, 9, 3, 20, 29, 23, 22, 25],
                "worst-individual-distance": 66382.08126805602,
                "average-distance": 61823.33240715093,
                "individual-distances": []
            }, {
                "best-individual-sequence": [2, 11, 4, 7, 3, 9, 13, 20, 29, 22, 18, 21, 28, 26, 17, 19, 23, 27, 25, 16, 24, 8, 10, 14, 6, 15, 12, 5, 1],
                "best-individual-distance": 46969.526374602385,
                "worst-individual-sequence": [4, 17, 8, 6, 11, 10, 1, 2, 5, 7, 12, 16, 3, 28, 27, 9, 14, 26, 29, 21, 13, 15, 24, 25, 20, 22, 18, 23, 19],
                "worst-individual-distance": 65639.99302524602,
                "average-distance": 61266.976923264905,
                "individual-distances": []
            }, {
                "best-individual-sequence": [2, 11, 4, 7, 3, 9, 13, 20, 29, 22, 18, 21, 28, 26, 17, 19, 23, 27, 25, 16, 24, 8, 10, 14, 6, 15, 12, 5, 1],
                "best-individual-distance": 46969.526374602385,
                "worst-individual-sequence": [22, 19, 28, 15, 9, 16, 18, 21, 26, 24, 29, 20, 27, 25, 23, 13, 7, 6, 17, 14, 8, 2, 1, 10, 11, 5, 3, 4, 12],
                "worst-individual-distance": 65015.27496680304,
                "average-distance": 60707.31495097714,
                "individual-distances": []
            }, {
                "best-individual-sequence": [2, 11, 4, 7, 3, 9, 13, 20, 29, 22, 18, 21, 28, 26, 17, 19, 23, 27, 25, 16, 24, 8, 10, 14, 6, 15, 12, 5, 1],
                "best-individual-distance": 46969.526374602385,
                "worst-individual-sequence": [22, 3, 19, 9, 5, 4, 13, 21, 18, 28, 17, 23, 25, 24, 14, 16, 27, 26, 29, 15, 12, 8, 1, 6, 2, 11, 10, 7, 20],
                "worst-individual-distance": 64340.73939765256,
                "average-distance": 60116.20814662044,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 5, 4, 7, 9, 19, 22, 29, 20, 26, 28, 24, 25, 27, 16, 21, 18, 23, 17, 14, 8, 6, 2, 1, 3, 11, 10, 13, 15],
                "best-individual-distance": 45446.366650680546,
                "worst-individual-sequence": [6, 11, 5, 10, 1, 2, 3, 7, 16, 14, 15, 20, 23, 9, 29, 21, 28, 24, 25, 26, 22, 19, 17, 18, 27, 13, 4, 12, 8],
                "worst-individual-distance": 63700.771939272214,
                "average-distance": 59514.067582950935,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 5, 4, 7, 9, 19, 22, 29, 20, 26, 28, 24, 25, 27, 16, 21, 18, 23, 17, 14, 8, 6, 2, 1, 3, 11, 10, 13, 15],
                "best-individual-distance": 45446.366650680546,
                "worst-individual-sequence": [14, 12, 4, 9, 3, 2, 6, 11, 29, 1, 13, 24, 25, 27, 16, 21, 17, 20, 26, 18, 22, 8, 28, 10, 7, 5, 15, 23, 19],
                "worst-individual-distance": 63011.64663275134,
                "average-distance": 59002.12790871513,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 5, 4, 7, 9, 19, 22, 29, 20, 26, 28, 24, 25, 27, 16, 21, 18, 23, 17, 14, 8, 6, 2, 1, 3, 11, 10, 13, 15],
                "best-individual-distance": 45446.366650680546,
                "worst-individual-sequence": [22, 15, 18, 26, 20, 24, 27, 16, 14, 28, 25, 9, 17, 11, 10, 13, 7, 6, 2, 8, 12, 19, 29, 4, 3, 5, 23, 1, 21],
                "worst-individual-distance": 62480.89480980186,
                "average-distance": 58449.676016163314,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 5, 4, 7, 9, 19, 22, 29, 20, 26, 28, 24, 25, 27, 16, 21, 18, 23, 17, 14, 8, 6, 2, 1, 3, 11, 10, 13, 15],
                "best-individual-distance": 45446.366650680546,
                "worst-individual-sequence": [16, 21, 18, 23, 12, 3, 9, 5, 4, 28, 22, 17, 20, 14, 15, 26, 29, 11, 8, 6, 2, 1, 10, 19, 13, 7, 24, 25, 27],
                "worst-individual-distance": 61965.873485328775,
                "average-distance": 57956.7951290898,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 5, 4, 7, 9, 19, 22, 29, 20, 26, 28, 24, 25, 27, 16, 21, 18, 23, 17, 14, 8, 6, 2, 1, 3, 11, 10, 13, 15],
                "best-individual-distance": 45446.366650680546,
                "worst-individual-sequence": [2, 3, 7, 24, 21, 12, 5, 4, 9, 14, 20, 23, 18, 28, 22, 17, 16, 19, 13, 26, 25, 27, 29, 15, 8, 6, 11, 10, 1],
                "worst-individual-distance": 61470.493683703586,
                "average-distance": 57494.335348834305,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 3, 8, 12, 9, 13, 7, 25, 27, 16, 21, 18, 23, 17, 14, 15, 19, 22, 29, 20, 26, 28, 24, 4, 6, 11, 10, 1, 2],
                "best-individual-distance": 44995.15478161516,
                "worst-individual-sequence": [28, 22, 24, 25, 17, 20, 26, 27, 16, 21, 15, 4, 1, 11, 10, 13, 7, 6, 2, 8, 12, 19, 29, 23, 3, 5, 9, 14, 18],
                "worst-individual-distance": 60980.67794567148,
                "average-distance": 57023.061590536505,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 3, 8, 12, 9, 13, 7, 25, 27, 16, 21, 18, 23, 17, 14, 15, 19, 22, 29, 20, 26, 28, 24, 4, 6, 11, 10, 1, 2],
                "best-individual-distance": 44995.15478161516,
                "worst-individual-sequence": [11, 7, 18, 21, 29, 3, 10, 13, 20, 25, 14, 9, 17, 28, 24, 16, 27, 26, 15, 19, 22, 23, 12, 8, 6, 1, 4, 5, 2],
                "worst-individual-distance": 60532.63915183585,
                "average-distance": 56540.03264014951,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 24, 25, 27, 16, 21, 18, 23, 14, 19, 22, 29, 26, 20, 17, 15, 12, 6, 2, 1, 28, 8, 11, 5, 4, 7, 3, 9, 13],
                "best-individual-distance": 43337.82359513649,
                "worst-individual-sequence": [4, 12, 10, 3, 7, 24, 25, 29, 13, 22, 28, 27, 26, 21, 15, 19, 18, 23, 17, 14, 8, 6, 2, 1, 5, 11, 20, 16, 9],
                "worst-individual-distance": 60077.68896450226,
                "average-distance": 56069.801559518346,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 24, 25, 27, 16, 21, 18, 23, 14, 19, 22, 29, 26, 20, 17, 15, 12, 6, 2, 1, 28, 8, 11, 5, 4, 7, 3, 9, 13],
                "best-individual-distance": 43337.82359513649,
                "worst-individual-sequence": [6, 2, 3, 1, 5, 8, 14, 22, 19, 23, 28, 24, 16, 27, 26, 25, 29, 21, 18, 15, 17, 20, 13, 7, 12, 11, 10, 9, 4],
                "worst-individual-distance": 59549.67937272652,
                "average-distance": 55618.42243912812,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 24, 25, 27, 16, 21, 18, 23, 14, 19, 22, 29, 26, 20, 17, 15, 12, 6, 2, 1, 28, 8, 11, 5, 4, 7, 3, 9, 13],
                "best-individual-distance": 43337.82359513649,
                "worst-individual-sequence": [16, 14, 12, 5, 3, 9, 4, 13, 24, 25, 28, 1, 11, 10, 7, 6, 2, 8, 19, 29, 23, 17, 21, 22, 15, 18, 26, 20, 27],
                "worst-individual-distance": 59080.67548297884,
                "average-distance": 55180.767806634016,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 24, 25, 27, 16, 21, 18, 23, 14, 19, 22, 29, 26, 20, 17, 15, 12, 6, 2, 1, 28, 8, 11, 5, 4, 7, 3, 9, 13],
                "best-individual-distance": 43337.82359513649,
                "worst-individual-sequence": [28, 12, 9, 19, 20, 22, 13, 15, 27, 25, 16, 24, 29, 26, 21, 18, 23, 17, 14, 8, 6, 2, 1, 10, 11, 7, 4, 5, 3],
                "worst-individual-distance": 58618.99469372269,
                "average-distance": 54776.17662282668,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 24, 25, 27, 16, 21, 18, 23, 14, 19, 22, 29, 26, 20, 17, 15, 12, 6, 2, 1, 28, 8, 11, 5, 4, 7, 3, 9, 13],
                "best-individual-distance": 43337.82359513649,
                "worst-individual-sequence": [14, 23, 12, 3, 4, 22, 13, 15, 19, 27, 25, 16, 24, 29, 26, 17, 18, 21, 20, 28, 8, 6, 11, 10, 1, 2, 5, 7, 9],
                "worst-individual-distance": 58253.43983206283,
                "average-distance": 54366.12121605857,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 24, 25, 27, 16, 21, 18, 23, 14, 19, 22, 29, 26, 20, 17, 15, 12, 6, 2, 1, 28, 8, 11, 5, 4, 7, 3, 9, 13],
                "best-individual-distance": 43337.82359513649,
                "worst-individual-sequence": [14, 16, 27, 26, 15, 19, 22, 23, 12, 28, 25, 9, 1, 11, 10, 13, 8, 6, 2, 5, 4, 3, 7, 20, 24, 29, 21, 18, 17],
                "worst-individual-distance": 57756.2275404299,
                "average-distance": 53933.95640763286,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 24, 25, 27, 16, 21, 18, 23, 14, 19, 22, 29, 26, 20, 17, 15, 12, 6, 2, 1, 28, 8, 11, 5, 4, 7, 3, 9, 13],
                "best-individual-distance": 43337.82359513649,
                "worst-individual-sequence": [28, 25, 27, 16, 18, 23, 24, 11, 10, 15, 13, 4, 3, 5, 9, 20, 17, 14, 8, 6, 2, 1, 7, 12, 19, 22, 21, 26, 29],
                "worst-individual-distance": 57342.678400788434,
                "average-distance": 53534.17394057666,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 24, 25, 27, 16, 21, 18, 23, 14, 19, 22, 29, 26, 20, 17, 15, 12, 6, 2, 1, 28, 8, 11, 5, 4, 7, 3, 9, 13],
                "best-individual-distance": 43337.82359513649,
                "worst-individual-sequence": [9, 7, 3, 22, 20, 5, 4, 13, 21, 18, 29, 26, 15, 28, 17, 19, 23, 27, 25, 16, 24, 14, 12, 8, 1, 6, 2, 11, 10],
                "worst-individual-distance": 56931.197092030445,
                "average-distance": 53145.651751845595,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 3, 5, 8, 7, 1, 23, 29, 20, 26, 28, 24, 25, 27, 16, 21, 17, 22, 18, 15, 14, 13, 12, 11, 10, 19, 6, 2, 4],
                "best-individual-distance": 41031.76104470814,
                "worst-individual-sequence": [24, 29, 22, 28, 20, 14, 3, 7, 9, 18, 21, 19, 16, 8, 13, 15, 12, 6, 2, 1, 4, 5, 10, 11, 17, 27, 25, 23, 26],
                "worst-individual-distance": 56443.19427919381,
                "average-distance": 52734.836443540364,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 3, 5, 8, 7, 1, 23, 29, 20, 26, 28, 24, 25, 27, 16, 21, 17, 22, 18, 15, 14, 13, 12, 11, 10, 19, 6, 2, 4],
                "best-individual-distance": 41031.76104470814,
                "worst-individual-sequence": [24, 9, 12, 19, 26, 20, 22, 29, 28, 15, 13, 3, 25, 27, 16, 21, 18, 23, 17, 14, 8, 6, 7, 11, 5, 10, 4, 1, 2],
                "worst-individual-distance": 55999.431075737724,
                "average-distance": 52302.58354812691,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 3, 5, 8, 7, 1, 23, 29, 20, 26, 28, 24, 25, 27, 16, 21, 17, 22, 18, 15, 14, 13, 12, 11, 10, 19, 6, 2, 4],
                "best-individual-distance": 41031.76104470814,
                "worst-individual-sequence": [12, 5, 3, 9, 14, 20, 23, 18, 28, 22, 17, 8, 13, 24, 25, 16, 27, 26, 15, 19, 21, 29, 4, 6, 11, 10, 1, 2, 7],
                "worst-individual-distance": 55638.08790451468,
                "average-distance": 51981.18571799973,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 3, 5, 8, 7, 1, 23, 29, 20, 26, 28, 24, 25, 27, 16, 21, 17, 22, 18, 15, 14, 13, 12, 11, 10, 19, 6, 2, 4],
                "best-individual-distance": 41031.76104470814,
                "worst-individual-sequence": [13, 19, 27, 24, 15, 25, 16, 29, 21, 26, 23, 28, 18, 20, 17, 14, 8, 6, 2, 1, 4, 7, 5, 22, 12, 10, 11, 9, 3],
                "worst-individual-distance": 55238.89394819642,
                "average-distance": 51551.775862683244,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 3, 5, 8, 7, 1, 23, 29, 20, 26, 28, 24, 25, 27, 16, 21, 17, 22, 18, 15, 14, 13, 12, 11, 10, 19, 6, 2, 4],
                "best-individual-distance": 41031.76104470814,
                "worst-individual-sequence": [11, 2, 1, 5, 3, 9, 13, 20, 29, 22, 18, 21, 28, 26, 17, 19, 23, 27, 25, 16, 24, 8, 15, 14, 6, 10, 12, 4, 7],
                "worst-individual-distance": 54672.86760474425,
                "average-distance": 51142.08195495345,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 3, 5, 8, 7, 1, 23, 29, 20, 26, 28, 24, 25, 27, 16, 21, 17, 22, 18, 15, 14, 13, 12, 11, 10, 19, 6, 2, 4],
                "best-individual-distance": 41031.76104470814,
                "worst-individual-sequence": [3, 9, 13, 20, 29, 22, 18, 21, 15, 19, 28, 26, 17, 23, 27, 25, 16, 24, 8, 12, 2, 1, 5, 10, 14, 6, 11, 4, 7],
                "worst-individual-distance": 54261.84033773272,
                "average-distance": 50783.929582394216,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 3, 5, 8, 7, 1, 23, 29, 20, 26, 28, 24, 25, 27, 16, 21, 17, 22, 18, 15, 14, 13, 12, 11, 10, 19, 6, 2, 4],
                "best-individual-distance": 41031.76104470814,
                "worst-individual-sequence": [20, 13, 16, 27, 26, 15, 24, 25, 21, 29, 28, 23, 17, 14, 12, 8, 1, 6, 2, 4, 11, 10, 9, 7, 3, 5, 19, 22, 18],
                "worst-individual-distance": 53767.21953854007,
                "average-distance": 50454.621286303336,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 3, 5, 8, 7, 1, 23, 29, 20, 26, 28, 24, 25, 27, 16, 21, 17, 22, 18, 15, 14, 13, 12, 11, 10, 19, 6, 2, 4],
                "best-individual-distance": 41031.76104470814,
                "worst-individual-sequence": [22, 19, 7, 9, 26, 20, 25, 24, 15, 29, 28, 21, 18, 27, 16, 23, 17, 14, 12, 8, 1, 6, 2, 11, 10, 3, 5, 4, 13],
                "worst-individual-distance": 53291.18049685163,
                "average-distance": 50087.45643304237,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 3, 5, 8, 7, 1, 23, 29, 20, 26, 28, 24, 25, 27, 16, 21, 17, 22, 18, 15, 14, 13, 12, 11, 10, 19, 6, 2, 4],
                "best-individual-distance": 41031.76104470814,
                "worst-individual-sequence": [9, 13, 22, 15, 28, 17, 19, 23, 27, 25, 16, 24, 26, 29, 21, 18, 14, 20, 3, 6, 2, 5, 12, 1, 8, 10, 11, 4, 7],
                "worst-individual-distance": 52966.60268941794,
                "average-distance": 49836.280263485736,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 3, 5, 8, 7, 1, 23, 29, 20, 26, 28, 24, 25, 27, 16, 21, 17, 22, 18, 15, 14, 13, 12, 11, 10, 19, 6, 2, 4],
                "best-individual-distance": 41031.76104470814,
                "worst-individual-sequence": [9, 3, 13, 19, 15, 25, 16, 24, 29, 21, 26, 23, 22, 28, 18, 20, 17, 14, 8, 6, 2, 1, 4, 7, 5, 27, 12, 10, 11],
                "worst-individual-distance": 52615.768206984474,
                "average-distance": 49545.04916254433,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 3, 5, 8, 7, 1, 23, 29, 20, 26, 28, 24, 25, 27, 16, 21, 17, 22, 18, 15, 14, 13, 12, 11, 10, 19, 6, 2, 4],
                "best-individual-distance": 41031.76104470814,
                "worst-individual-sequence": [26, 20, 25, 24, 15, 29, 28, 27, 16, 18, 21, 19, 17, 14, 8, 6, 2, 1, 4, 7, 5, 12, 11, 9, 3, 10, 13, 23, 22],
                "worst-individual-distance": 52305.675687008814,
                "average-distance": 49260.495245544174,
                "individual-distances": []
            }, {
                "best-individual-sequence": [13, 15, 19, 22, 29, 20, 26, 28, 24, 25, 27, 16, 21, 18, 23, 17, 14, 2, 3, 1, 6, 4, 7, 5, 10, 11, 12, 8, 9],
                "best-individual-distance": 40722.13814766267,
                "worst-individual-sequence": [10, 1, 2, 3, 7, 12, 5, 4, 9, 14, 20, 23, 18, 28, 22, 17, 16, 19, 13, 24, 25, 27, 26, 21, 29, 15, 8, 6, 11],
                "worst-individual-distance": 51944.20094354274,
                "average-distance": 48967.968743470774,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 13, 29, 22, 28, 17, 19, 23, 24, 27, 25, 20, 16, 14, 26, 21, 18, 15, 12, 11, 10, 4, 6, 2, 1, 5, 8, 7, 3],
                "best-individual-distance": 40401.96098550358,
                "worst-individual-sequence": [13, 19, 27, 25, 16, 24, 29, 21, 26, 23, 22, 28, 18, 20, 17, 14, 8, 4, 7, 6, 9, 15, 2, 1, 5, 3, 12, 11, 10],
                "worst-individual-distance": 51591.75596395374,
                "average-distance": 48675.00895668421,
                "individual-distances": []
            }, {
                "best-individual-sequence": [13, 20, 26, 25, 24, 27, 16, 18, 17, 14, 21, 29, 28, 23, 22, 15, 19, 4, 3, 6, 1, 2, 5, 8, 11, 10, 12, 7, 9],
                "best-individual-distance": 40218.487777750226,
                "worst-individual-sequence": [5, 4, 19, 22, 29, 20, 26, 28, 24, 25, 27, 16, 21, 18, 23, 17, 14, 8, 6, 2, 1, 3, 11, 10, 7, 15, 9, 13, 12],
                "worst-individual-distance": 51339.03092008313,
                "average-distance": 48347.30926980681,
                "individual-distances": []
            }, {
                "best-individual-sequence": [13, 20, 26, 25, 24, 27, 16, 18, 17, 14, 21, 29, 28, 23, 22, 15, 19, 4, 3, 6, 1, 2, 5, 8, 11, 10, 12, 7, 9],
                "best-individual-distance": 40218.487777750226,
                "worst-individual-sequence": [20, 13, 19, 26, 27, 25, 16, 24, 29, 15, 28, 21, 18, 23, 17, 14, 8, 6, 2, 1, 10, 12, 11, 9, 7, 3, 5, 4, 22],
                "worst-individual-distance": 50941.06279317361,
                "average-distance": 48084.39964800134,
                "individual-distances": []
            }, {
                "best-individual-sequence": [13, 20, 26, 25, 24, 27, 16, 18, 17, 14, 21, 29, 28, 23, 22, 15, 19, 4, 3, 6, 1, 2, 5, 8, 11, 10, 12, 7, 9],
                "best-individual-distance": 40218.487777750226,
                "worst-individual-sequence": [6, 2, 3, 1, 5, 8, 14, 22, 19, 23, 28, 24, 16, 27, 26, 25, 29, 21, 18, 15, 17, 20, 13, 7, 12, 11, 10, 9, 4],
                "worst-individual-distance": 50599.54544310579,
                "average-distance": 47839.85124810084,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 23, 7, 3, 9, 13, 20, 29, 22, 21, 28, 26, 17, 18, 19, 24, 4, 27, 25, 16, 14, 15, 12, 8, 5, 10, 11, 6, 2],
                "best-individual-distance": 38063.210123410645,
                "worst-individual-sequence": [3, 13, 14, 19, 21, 22, 18, 20, 25, 24, 7, 29, 28, 27, 16, 23, 26, 17, 15, 9, 12, 4, 8, 6, 11, 10, 1, 2, 5],
                "worst-individual-distance": 50341.20423049098,
                "average-distance": 47572.9308219712,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 23, 7, 3, 9, 13, 20, 29, 22, 21, 28, 26, 17, 18, 19, 24, 4, 27, 25, 16, 14, 15, 12, 8, 5, 10, 11, 6, 2],
                "best-individual-distance": 38063.210123410645,
                "worst-individual-sequence": [29, 18, 26, 21, 15, 19, 20, 28, 23, 25, 16, 24, 27, 14, 17, 22, 12, 13, 8, 6, 2, 11, 10, 1, 5, 4, 7, 9, 3],
                "worst-individual-distance": 50110.470150446454,
                "average-distance": 47331.275458706245,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 23, 7, 3, 9, 13, 20, 29, 22, 21, 28, 26, 17, 18, 19, 24, 4, 27, 25, 16, 14, 15, 12, 8, 5, 10, 11, 6, 2],
                "best-individual-distance": 38063.210123410645,
                "worst-individual-sequence": [8, 29, 21, 23, 17, 22, 20, 26, 28, 24, 25, 27, 16, 18, 14, 19, 2, 1, 4, 5, 6, 9, 3, 7, 13, 15, 12, 11, 10],
                "worst-individual-distance": 49822.87437319918,
                "average-distance": 47120.48324428726,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 23, 7, 3, 9, 13, 20, 29, 22, 21, 28, 26, 17, 18, 19, 24, 4, 27, 25, 16, 14, 15, 12, 8, 5, 10, 11, 6, 2],
                "best-individual-distance": 38063.210123410645,
                "worst-individual-sequence": [19, 27, 25, 16, 24, 15, 13, 20, 29, 22, 18, 23, 28, 17, 14, 8, 6, 2, 1, 5, 4, 12, 10, 11, 7, 3, 9, 21, 26],
                "worst-individual-distance": 49573.543775002094,
                "average-distance": 46869.102578443235,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 23, 7, 3, 9, 13, 20, 29, 22, 21, 28, 26, 17, 18, 19, 24, 4, 27, 25, 16, 14, 15, 12, 8, 5, 10, 11, 6, 2],
                "best-individual-distance": 38063.210123410645,
                "worst-individual-sequence": [3, 9, 13, 20, 18, 26, 25, 24, 27, 16, 21, 29, 28, 23, 17, 14, 12, 8, 1, 6, 2, 11, 10, 5, 22, 15, 19, 4, 7],
                "worst-individual-distance": 49258.86523467195,
                "average-distance": 46651.92245034128,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 23, 7, 3, 9, 13, 20, 29, 22, 21, 28, 26, 17, 18, 19, 24, 4, 27, 25, 16, 14, 15, 12, 8, 5, 10, 11, 6, 2],
                "best-individual-distance": 38063.210123410645,
                "worst-individual-sequence": [29, 28, 13, 8, 25, 27, 16, 21, 18, 23, 17, 19, 22, 24, 11, 10, 5, 6, 2, 1, 4, 3, 7, 15, 12, 9, 14, 26, 20],
                "worst-individual-distance": 49020.14608780133,
                "average-distance": 46405.58679760667,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 23, 7, 3, 9, 13, 20, 29, 22, 21, 28, 26, 17, 18, 19, 24, 4, 27, 25, 16, 14, 15, 12, 8, 5, 10, 11, 6, 2],
                "best-individual-distance": 38063.210123410645,
                "worst-individual-sequence": [5, 9, 13, 20, 21, 17, 19, 23, 27, 25, 16, 24, 28, 22, 18, 29, 26, 14, 8, 6, 2, 1, 4, 7, 3, 15, 12, 10, 11],
                "worst-individual-distance": 48720.39461793318,
                "average-distance": 46159.50649546329,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 23, 7, 3, 9, 13, 20, 29, 22, 21, 28, 26, 17, 18, 19, 24, 4, 27, 25, 16, 14, 15, 12, 8, 5, 10, 11, 6, 2],
                "best-individual-distance": 38063.210123410645,
                "worst-individual-sequence": [15, 12, 19, 29, 20, 26, 28, 24, 25, 27, 16, 21, 18, 23, 17, 14, 8, 11, 10, 6, 2, 1, 4, 7, 9, 5, 3, 22, 13],
                "worst-individual-distance": 48407.52721984622,
                "average-distance": 45900.37699911333,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 23, 7, 3, 9, 13, 20, 29, 22, 21, 28, 26, 17, 18, 19, 24, 4, 27, 25, 16, 14, 15, 12, 8, 5, 10, 11, 6, 2],
                "best-individual-distance": 38063.210123410645,
                "worst-individual-sequence": [11, 15, 19, 29, 20, 26, 28, 24, 25, 22, 18, 21, 27, 16, 23, 17, 14, 8, 6, 1, 2, 5, 10, 3, 7, 9, 13, 12, 4],
                "worst-individual-distance": 48133.04241169041,
                "average-distance": 45661.17381458924,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 23, 7, 3, 9, 13, 20, 29, 22, 21, 28, 26, 17, 18, 19, 24, 4, 27, 25, 16, 14, 15, 12, 8, 5, 10, 11, 6, 2],
                "best-individual-distance": 38063.210123410645,
                "worst-individual-sequence": [13, 7, 9, 14, 20, 26, 29, 19, 25, 27, 16, 21, 18, 23, 15, 11, 12, 4, 3, 5, 1, 2, 6, 10, 8, 24, 17, 28, 22],
                "worst-individual-distance": 47896.91256364165,
                "average-distance": 45463.79973713645,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 23, 7, 3, 9, 13, 20, 29, 22, 21, 28, 26, 17, 18, 19, 24, 4, 27, 25, 16, 14, 15, 12, 8, 5, 10, 11, 6, 2],
                "best-individual-distance": 38063.210123410645,
                "worst-individual-sequence": [9, 14, 22, 19, 23, 28, 24, 16, 27, 26, 25, 29, 21, 18, 15, 17, 20, 13, 12, 4, 6, 1, 2, 5, 8, 11, 10, 3, 7],
                "worst-individual-distance": 47643.43674943426,
                "average-distance": 45181.21994793931,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 23, 7, 3, 9, 13, 20, 29, 22, 21, 28, 26, 17, 18, 19, 24, 4, 27, 25, 16, 14, 15, 12, 8, 5, 10, 11, 6, 2],
                "best-individual-distance": 38063.210123410645,
                "worst-individual-sequence": [9, 13, 21, 19, 23, 27, 25, 16, 24, 28, 22, 18, 29, 20, 26, 17, 14, 8, 6, 2, 1, 4, 7, 5, 15, 12, 10, 11, 3],
                "worst-individual-distance": 47381.949746758066,
                "average-distance": 44937.073799658276,
                "individual-distances": []
            }, {
                "best-individual-sequence": [24, 27, 16, 18, 21, 29, 28, 23, 22, 19, 17, 14, 13, 15, 12, 11, 10, 4, 8, 6, 2, 1, 5, 3, 7, 9, 20, 26, 25],
                "best-individual-distance": 37284.500924268104,
                "worst-individual-sequence": [21, 28, 26, 25, 24, 14, 18, 17, 19, 22, 23, 27, 16, 8, 11, 10, 5, 6, 2, 1, 4, 3, 7, 15, 12, 9, 13, 20, 29],
                "worst-individual-distance": 47164.565465532534,
                "average-distance": 44733.98634133525,
                "individual-distances": []
            }, {
                "best-individual-sequence": [24, 27, 16, 18, 21, 29, 28, 23, 22, 19, 17, 14, 13, 15, 12, 11, 10, 4, 8, 6, 2, 1, 5, 3, 7, 9, 20, 26, 25],
                "best-individual-distance": 37284.500924268104,
                "worst-individual-sequence": [29, 23, 24, 25, 16, 14, 13, 20, 27, 22, 18, 21, 28, 26, 17, 8, 3, 12, 11, 10, 6, 2, 1, 5, 4, 7, 9, 15, 19],
                "worst-individual-distance": 46874.38745400919,
                "average-distance": 44472.866270236285,
                "individual-distances": []
            }, {
                "best-individual-sequence": [15, 19, 22, 29, 20, 26, 28, 24, 25, 27, 16, 21, 18, 23, 17, 14, 12, 8, 10, 6, 2, 1, 5, 4, 3, 7, 9, 13, 11],
                "best-individual-distance": 37097.44143525554,
                "worst-individual-sequence": [22, 19, 21, 26, 27, 28, 17, 23, 15, 11, 10, 5, 6, 2, 1, 4, 3, 7, 8, 12, 9, 14, 29, 13, 25, 16, 24, 20, 18],
                "worst-individual-distance": 46673.632024022445,
                "average-distance": 44274.83381522097,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 26, 28, 24, 25, 27, 16, 29, 21, 18, 15, 23, 22, 19, 14, 12, 8, 10, 11, 6, 2, 1, 5, 4, 7, 9, 3, 13, 17],
                "best-individual-distance": 36704.05083368526,
                "worst-individual-sequence": [9, 14, 19, 29, 23, 12, 25, 17, 20, 26, 27, 16, 21, 15, 18, 22, 28, 24, 13, 4, 6, 1, 2, 5, 8, 11, 10, 3, 7],
                "worst-individual-distance": 46333.52110869766,
                "average-distance": 43998.08625772838,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 26, 28, 24, 25, 27, 16, 29, 21, 18, 15, 23, 22, 19, 14, 12, 8, 10, 11, 6, 2, 1, 5, 4, 7, 9, 3, 13, 17],
                "best-individual-distance": 36704.05083368526,
                "worst-individual-sequence": [22, 18, 21, 28, 26, 17, 19, 23, 27, 25, 16, 24, 14, 15, 12, 8, 6, 2, 1, 20, 9, 5, 4, 3, 13, 10, 11, 7, 29],
                "worst-individual-distance": 46188.72634929648,
                "average-distance": 43793.690827039565,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 26, 28, 24, 25, 27, 16, 29, 21, 18, 15, 23, 22, 19, 14, 12, 8, 10, 11, 6, 2, 1, 5, 4, 7, 9, 3, 13, 17],
                "best-individual-distance": 36704.05083368526,
                "worst-individual-sequence": [22, 18, 21, 20, 28, 23, 16, 19, 17, 25, 24, 27, 26, 15, 12, 8, 11, 10, 5, 6, 2, 1, 7, 4, 3, 9, 14, 13, 29],
                "worst-individual-distance": 45912.66447738199,
                "average-distance": 43606.76706825858,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 26, 28, 24, 25, 27, 16, 29, 21, 18, 15, 23, 22, 19, 14, 12, 8, 10, 11, 6, 2, 1, 5, 4, 7, 9, 3, 13, 17],
                "best-individual-distance": 36704.05083368526,
                "worst-individual-sequence": [15, 19, 22, 29, 20, 26, 28, 24, 25, 27, 16, 21, 18, 23, 17, 14, 12, 1, 6, 10, 11, 4, 7, 5, 3, 2, 8, 9, 13],
                "worst-individual-distance": 45694.790385946406,
                "average-distance": 43383.03860680538,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 26, 28, 24, 25, 27, 16, 29, 21, 18, 15, 23, 22, 19, 14, 12, 8, 10, 11, 6, 2, 1, 5, 4, 7, 9, 3, 13, 17],
                "best-individual-distance": 36704.05083368526,
                "worst-individual-sequence": [13, 12, 19, 15, 3, 25, 16, 24, 29, 26, 23, 22, 28, 20, 21, 18, 17, 14, 8, 6, 2, 1, 4, 7, 5, 10, 11, 27, 9],
                "worst-individual-distance": 45449.83381340168,
                "average-distance": 43156.127950503156,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 26, 28, 24, 25, 27, 16, 29, 21, 18, 15, 23, 22, 19, 14, 12, 8, 10, 11, 6, 2, 1, 5, 4, 7, 9, 3, 13, 17],
                "best-individual-distance": 36704.05083368526,
                "worst-individual-sequence": [23, 27, 25, 16, 24, 21, 26, 20, 29, 22, 19, 18, 28, 14, 17, 8, 7, 2, 1, 6, 9, 5, 4, 3, 13, 12, 10, 11, 15],
                "worst-individual-distance": 45207.803369706846,
                "average-distance": 42898.80933528915,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 26, 28, 24, 25, 27, 16, 29, 21, 18, 15, 23, 22, 19, 14, 12, 8, 10, 11, 6, 2, 1, 5, 4, 7, 9, 3, 13, 17],
                "best-individual-distance": 36704.05083368526,
                "worst-individual-sequence": [13, 21, 23, 27, 25, 16, 24, 28, 18, 15, 19, 22, 29, 20, 26, 17, 14, 9, 6, 2, 1, 4, 7, 5, 3, 12, 10, 11, 8],
                "worst-individual-distance": 45008.58536329925,
                "average-distance": 42699.84742116938,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 26, 28, 24, 25, 27, 16, 29, 21, 18, 15, 23, 22, 19, 14, 12, 8, 10, 11, 6, 2, 1, 5, 4, 7, 9, 3, 13, 17],
                "best-individual-distance": 36704.05083368526,
                "worst-individual-sequence": [13, 19, 15, 22, 28, 20, 21, 18, 17, 23, 27, 25, 16, 24, 26, 29, 14, 8, 6, 2, 1, 4, 7, 5, 10, 11, 12, 3, 9],
                "worst-individual-distance": 44791.303946422966,
                "average-distance": 42485.51889731051,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 20, 26, 28, 24, 25, 27, 16, 29, 21, 18, 14, 15, 12, 11, 10, 8, 5, 6, 2, 1, 4, 7, 3, 9, 13, 19, 22, 23],
                "best-individual-distance": 36467.846452785605,
                "worst-individual-sequence": [19, 15, 11, 5, 3, 9, 13, 20, 29, 22, 18, 21, 28, 26, 17, 7, 6, 2, 1, 10, 4, 8, 12, 14, 16, 25, 24, 27, 23],
                "worst-individual-distance": 44600.07391742836,
                "average-distance": 42285.02595115427,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 20, 26, 28, 24, 25, 27, 16, 29, 21, 18, 14, 15, 12, 11, 10, 8, 5, 6, 2, 1, 4, 7, 3, 9, 13, 19, 22, 23],
                "best-individual-distance": 36467.846452785605,
                "worst-individual-sequence": [14, 22, 28, 19, 27, 25, 16, 24, 29, 26, 23, 21, 18, 15, 17, 20, 13, 3, 4, 6, 1, 2, 5, 8, 11, 10, 12, 7, 9],
                "worst-individual-distance": 44319.71990051142,
                "average-distance": 42078.89151388643,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 20, 26, 28, 24, 25, 27, 16, 29, 21, 18, 14, 15, 12, 11, 10, 8, 5, 6, 2, 1, 4, 7, 3, 9, 13, 19, 22, 23],
                "best-individual-distance": 36467.846452785605,
                "worst-individual-sequence": [22, 29, 24, 25, 27, 16, 20, 26, 28, 21, 18, 23, 17, 14, 8, 4, 5, 6, 2, 1, 3, 12, 11, 10, 13, 15, 7, 9, 19],
                "worst-individual-distance": 44042.25046225365,
                "average-distance": 41866.45765769127,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 26, 28, 24, 25, 27, 16, 21, 18, 23, 17, 14, 12, 11, 10, 4, 8, 6, 2, 1, 5, 3, 7, 9, 13, 15, 19, 22, 29],
                "best-individual-distance": 36124.1365813261,
                "worst-individual-sequence": [16, 24, 14, 20, 22, 21, 28, 26, 17, 19, 18, 12, 6, 1, 2, 5, 8, 11, 10, 4, 7, 9, 3, 29, 13, 15, 23, 27, 25],
                "worst-individual-distance": 43791.15027741835,
                "average-distance": 41658.10830608234,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 26, 28, 24, 25, 27, 16, 29, 21, 18, 14, 15, 12, 11, 10, 8, 5, 6, 2, 1, 4, 3, 7, 9, 13, 19, 22, 23, 17],
                "best-individual-distance": 35703.44779212588,
                "worst-individual-sequence": [13, 28, 24, 25, 27, 16, 21, 18, 23, 15, 19, 22, 29, 20, 26, 17, 14, 8, 6, 2, 1, 7, 4, 11, 10, 12, 5, 3, 9],
                "worst-individual-distance": 43620.43582914694,
                "average-distance": 41485.39301988769,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 26, 28, 24, 25, 27, 16, 29, 21, 18, 14, 15, 12, 11, 10, 8, 5, 6, 2, 1, 4, 3, 7, 9, 13, 19, 22, 23, 17],
                "best-individual-distance": 35703.44779212588,
                "worst-individual-sequence": [3, 5, 8, 7, 13, 19, 23, 17, 20, 26, 28, 24, 25, 27, 16, 21, 18, 14, 15, 29, 22, 1, 11, 10, 12, 6, 2, 4, 9],
                "worst-individual-distance": 43428.96918874637,
                "average-distance": 41306.09240131562,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 26, 28, 24, 25, 27, 16, 29, 21, 18, 14, 15, 12, 11, 10, 8, 5, 6, 2, 1, 4, 3, 7, 9, 13, 19, 22, 23, 17],
                "best-individual-distance": 35703.44779212588,
                "worst-individual-sequence": [13, 12, 22, 26, 21, 15, 19, 20, 28, 23, 25, 16, 24, 27, 14, 18, 17, 29, 11, 10, 4, 6, 2, 1, 5, 8, 7, 3, 9],
                "worst-individual-distance": 43232.40347037933,
                "average-distance": 41100.83339637693,
                "individual-distances": []
            }
        ],
        [
            [{
                "time_cost": 0
            }], {
                "best-individual-sequence": [23, 20, 25, 21, 12, 19, 17, 16, 24, 13, 10, 14, 22, 18, 1, 2, 11, 7, 28, 9, 3, 6, 26, 4, 8, 15, 29, 27, 5],
                "best-individual-distance": 72538.41076540186,
                "worst-individual-sequence": [10, 11, 1, 20, 18, 7, 2, 16, 23, 3, 28, 6, 24, 25, 8, 26, 4, 19, 15, 21, 22, 9, 12, 14, 5, 29, 13, 27, 17],
                "worst-individual-distance": 120220.38353224043,
                "average-distance": 106494.18463256261,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 20, 25, 21, 12, 19, 17, 16, 24, 13, 10, 14, 22, 18, 1, 2, 11, 7, 28, 9, 3, 6, 26, 4, 8, 15, 29, 27, 5],
                "best-individual-distance": 72538.41076540186,
                "worst-individual-sequence": [16, 19, 29, 7, 11, 21, 2, 8, 15, 10, 18, 4, 17, 1, 28, 12, 20, 22, 25, 27, 26, 13, 5, 3, 24, 23, 9, 14, 6],
                "worst-individual-distance": 115799.33434040609,
                "average-distance": 103983.4892317519,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 20, 25, 21, 12, 19, 17, 16, 24, 13, 10, 14, 22, 18, 1, 2, 11, 7, 28, 9, 3, 6, 26, 4, 8, 15, 29, 27, 5],
                "best-individual-distance": 72538.41076540186,
                "worst-individual-sequence": [27, 13, 8, 22, 14, 17, 5, 16, 2, 11, 3, 12, 21, 20, 29, 15, 18, 24, 6, 7, 4, 26, 1, 9, 28, 23, 19, 25, 10],
                "worst-individual-distance": 112503.56372266203,
                "average-distance": 101774.39258664081,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 24, 12, 19, 29, 14, 18, 10, 15, 6, 4, 9, 3, 7, 13, 25, 17, 20, 26, 23, 21, 28, 27, 16, 5, 22, 8, 11, 2],
                "best-individual-distance": 65918.63712935746,
                "worst-individual-sequence": [14, 10, 11, 19, 20, 21, 24, 12, 1, 16, 6, 8, 27, 2, 29, 18, 17, 3, 9, 4, 28, 23, 5, 26, 25, 15, 22, 13, 7],
                "worst-individual-distance": 109577.65128796264,
                "average-distance": 99541.35688647153,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 24, 12, 19, 29, 14, 18, 10, 15, 6, 4, 9, 3, 7, 13, 25, 17, 20, 26, 23, 21, 28, 27, 16, 5, 22, 8, 11, 2],
                "best-individual-distance": 65918.63712935746,
                "worst-individual-sequence": [5, 13, 2, 23, 4, 25, 15, 7, 3, 12, 8, 1, 14, 27, 6, 18, 28, 19, 17, 29, 21, 10, 11, 20, 26, 9, 24, 22, 16],
                "worst-individual-distance": 107159.95687098216,
                "average-distance": 97594.35630720665,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 24, 12, 19, 29, 14, 18, 10, 15, 6, 4, 9, 3, 7, 13, 25, 17, 20, 26, 23, 21, 28, 27, 16, 5, 22, 8, 11, 2],
                "best-individual-distance": 65918.63712935746,
                "worst-individual-sequence": [16, 4, 14, 25, 23, 8, 3, 19, 26, 24, 21, 5, 11, 12, 2, 20, 29, 22, 9, 28, 17, 13, 6, 1, 27, 10, 18, 15, 7],
                "worst-individual-distance": 105280.42582742836,
                "average-distance": 95769.61960225108,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 24, 12, 19, 29, 14, 18, 10, 15, 6, 4, 9, 3, 7, 13, 25, 17, 20, 26, 23, 21, 28, 27, 16, 5, 22, 8, 11, 2],
                "best-individual-distance": 65918.63712935746,
                "worst-individual-sequence": [9, 7, 27, 23, 2, 16, 17, 11, 24, 21, 5, 8, 19, 25, 20, 14, 15, 29, 18, 26, 3, 4, 10, 13, 6, 12, 1, 22, 28],
                "worst-individual-distance": 103081.30336614835,
                "average-distance": 93905.13758335426,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 24, 12, 19, 29, 14, 18, 10, 15, 6, 4, 9, 3, 7, 13, 25, 17, 20, 26, 23, 21, 28, 27, 16, 5, 22, 8, 11, 2],
                "best-individual-distance": 65918.63712935746,
                "worst-individual-sequence": [4, 24, 26, 3, 8, 7, 29, 13, 2, 15, 27, 14, 21, 19, 28, 10, 16, 20, 9, 12, 23, 22, 17, 18, 5, 1, 25, 11, 6],
                "worst-individual-distance": 101105.86234039707,
                "average-distance": 91991.37785855998,
                "individual-distances": []
            }, {
                "best-individual-sequence": [13, 12, 11, 6, 2, 1, 27, 18, 26, 15, 17, 20, 28, 14, 16, 24, 25, 21, 23, 19, 5, 3, 4, 7, 8, 29, 9, 10, 22],
                "best-individual-distance": 65737.78266237742,
                "worst-individual-sequence": [16, 20, 19, 5, 6, 15, 18, 14, 8, 10, 21, 28, 24, 22, 2, 17, 29, 7, 13, 9, 27, 25, 4, 23, 1, 11, 3, 12, 26],
                "worst-individual-distance": 99218.93377870196,
                "average-distance": 90206.00563750116,
                "individual-distances": []
            }, {
                "best-individual-sequence": [13, 12, 11, 6, 2, 1, 27, 18, 26, 15, 17, 20, 28, 14, 16, 24, 25, 21, 23, 19, 5, 3, 4, 7, 8, 29, 9, 10, 22],
                "best-individual-distance": 65737.78266237742,
                "worst-individual-sequence": [22, 5, 17, 9, 10, 13, 6, 11, 28, 4, 24, 15, 7, 2, 1, 12, 8, 25, 16, 20, 3, 26, 19, 29, 23, 27, 21, 14, 18],
                "worst-individual-distance": 97204.6148926433,
                "average-distance": 88366.68993564551,
                "individual-distances": []
            }, {
                "best-individual-sequence": [25, 26, 29, 27, 16, 23, 9, 12, 7, 3, 8, 13, 24, 5, 28, 19, 15, 4, 11, 1, 2, 6, 10, 22, 20, 17, 18, 14, 21],
                "best-individual-distance": 65112.94764712791,
                "worst-individual-sequence": [1, 2, 25, 18, 17, 29, 10, 24, 19, 3, 4, 27, 21, 14, 6, 12, 5, 7, 26, 23, 15, 28, 13, 8, 9, 22, 16, 20, 11],
                "worst-individual-distance": 95460.13727314079,
                "average-distance": 86640.02719508173,
                "individual-distances": []
            }, {
                "best-individual-sequence": [6, 25, 16, 24, 29, 23, 27, 26, 19, 2, 13, 18, 21, 28, 22, 14, 20, 11, 7, 4, 9, 15, 12, 8, 3, 1, 5, 17, 10],
                "best-individual-distance": 62333.266964003844,
                "worst-individual-sequence": [14, 13, 12, 22, 17, 8, 15, 4, 18, 25, 27, 11, 6, 20, 23, 7, 1, 5, 2, 9, 29, 24, 21, 10, 3, 19, 28, 26, 16],
                "worst-individual-distance": 93618.54073899833,
                "average-distance": 84916.26471877459,
                "individual-distances": []
            }, {
                "best-individual-sequence": [6, 25, 16, 24, 29, 23, 27, 26, 19, 2, 13, 18, 21, 28, 22, 14, 20, 11, 7, 4, 9, 15, 12, 8, 3, 1, 5, 17, 10],
                "best-individual-distance": 62333.266964003844,
                "worst-individual-sequence": [11, 5, 13, 19, 14, 22, 10, 12, 2, 9, 4, 15, 26, 1, 3, 7, 24, 16, 23, 27, 6, 28, 21, 18, 29, 17, 25, 20, 8],
                "worst-individual-distance": 91797.93490924087,
                "average-distance": 83457.94683152162,
                "individual-distances": []
            }, {
                "best-individual-sequence": [18, 9, 6, 2, 1, 11, 12, 15, 22, 27, 17, 20, 28, 14, 16, 24, 25, 21, 23, 19, 10, 3, 4, 7, 8, 29, 26, 5, 13],
                "best-individual-distance": 61950.17607792774,
                "worst-individual-sequence": [2, 11, 14, 12, 8, 13, 5, 6, 10, 29, 18, 4, 22, 1, 7, 20, 9, 27, 15, 19, 16, 28, 21, 24, 25, 26, 17, 23, 3],
                "worst-individual-distance": 90072.31184858743,
                "average-distance": 82067.11523516467,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 21, 29, 18, 16, 19, 27, 26, 15, 13, 17, 23, 24, 25, 12, 11, 10, 6, 4, 8, 2, 5, 1, 7, 3, 9, 14, 22, 28],
                "best-individual-distance": 59767.13234401178,
                "worst-individual-sequence": [5, 14, 8, 7, 25, 20, 27, 11, 15, 22, 17, 23, 21, 16, 19, 2, 4, 1, 6, 10, 26, 18, 12, 9, 3, 24, 29, 13, 28],
                "worst-individual-distance": 88555.73670041788,
                "average-distance": 80720.52871298569,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 21, 29, 18, 16, 19, 27, 26, 15, 13, 17, 23, 24, 25, 12, 11, 10, 6, 4, 8, 2, 5, 1, 7, 3, 9, 14, 22, 28],
                "best-individual-distance": 59767.13234401178,
                "worst-individual-sequence": [3, 4, 8, 20, 26, 19, 14, 5, 7, 17, 24, 9, 1, 10, 13, 6, 11, 28, 27, 21, 12, 25, 16, 15, 22, 23, 18, 29, 2],
                "worst-individual-distance": 86919.48831312601,
                "average-distance": 79454.21560967981,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 21, 29, 18, 16, 19, 27, 26, 15, 13, 17, 23, 24, 25, 12, 11, 10, 6, 4, 8, 2, 5, 1, 7, 3, 9, 14, 22, 28],
                "best-individual-distance": 59767.13234401178,
                "worst-individual-sequence": [24, 13, 14, 17, 2, 4, 7, 3, 8, 28, 16, 18, 19, 5, 10, 11, 9, 26, 15, 29, 27, 23, 20, 25, 21, 12, 22, 6, 1],
                "worst-individual-distance": 85359.20494412657,
                "average-distance": 78277.65248219778,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 21, 29, 18, 16, 19, 27, 26, 15, 13, 17, 23, 24, 25, 12, 11, 10, 6, 4, 8, 2, 5, 1, 7, 3, 9, 14, 22, 28],
                "best-individual-distance": 59767.13234401178,
                "worst-individual-sequence": [24, 25, 22, 13, 23, 15, 19, 3, 28, 26, 2, 1, 18, 10, 11, 5, 6, 4, 12, 14, 20, 8, 21, 27, 16, 17, 7, 9, 29],
                "worst-individual-distance": 83928.17570109577,
                "average-distance": 77204.29582822003,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 25, 16, 20, 13, 8, 7, 9, 5, 3, 4, 14, 12, 2, 1, 6, 23, 18, 28, 27, 24, 22, 19, 15, 29, 21, 17, 10, 11],
                "best-individual-distance": 56754.225786046714,
                "worst-individual-sequence": [6, 11, 12, 4, 8, 2, 7, 15, 18, 17, 24, 9, 1, 13, 19, 27, 29, 20, 28, 16, 3, 22, 21, 26, 25, 23, 14, 5, 10],
                "worst-individual-distance": 82675.72044869904,
                "average-distance": 76155.53742807728,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 25, 16, 20, 13, 8, 7, 9, 5, 3, 4, 14, 12, 2, 1, 6, 23, 18, 28, 27, 24, 22, 19, 15, 29, 21, 17, 10, 11],
                "best-individual-distance": 56754.225786046714,
                "worst-individual-sequence": [15, 28, 9, 1, 6, 4, 2, 11, 8, 26, 16, 24, 23, 7, 13, 14, 27, 22, 25, 20, 5, 12, 19, 10, 3, 17, 29, 18, 21],
                "worst-individual-distance": 81489.15653351395,
                "average-distance": 75288.63257745953,
                "individual-distances": []
            }, {
                "best-individual-sequence": [14, 15, 19, 16, 25, 26, 27, 24, 22, 20, 28, 13, 8, 7, 18, 4, 5, 11, 9, 3, 6, 1, 2, 10, 12, 21, 29, 23, 17],
                "best-individual-distance": 56016.99543907722,
                "worst-individual-sequence": [4, 15, 27, 3, 6, 8, 2, 7, 9, 1, 10, 13, 11, 12, 29, 5, 14, 19, 18, 20, 16, 28, 21, 24, 25, 26, 17, 23, 22],
                "worst-individual-distance": 80191.09884584637,
                "average-distance": 74129.63524557129,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 9, 1, 2, 11, 5, 7, 3, 8, 4, 15, 19, 29, 18, 28, 22, 20, 24, 25, 23, 21, 27, 16, 17, 26, 14, 13, 6, 12],
                "best-individual-distance": 55913.55192124808,
                "worst-individual-sequence": [1, 12, 29, 22, 15, 20, 7, 18, 14, 25, 28, 13, 8, 9, 5, 3, 2, 4, 6, 24, 21, 23, 19, 27, 16, 17, 26, 10, 11],
                "worst-individual-distance": 79148.93503501105,
                "average-distance": 73217.48572265026,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 9, 1, 2, 11, 5, 7, 3, 8, 4, 15, 19, 29, 18, 28, 22, 20, 24, 25, 23, 21, 27, 16, 17, 26, 14, 13, 6, 12],
                "best-individual-distance": 55913.55192124808,
                "worst-individual-sequence": [14, 3, 2, 23, 29, 21, 15, 13, 19, 28, 16, 25, 26, 27, 20, 18, 24, 22, 8, 11, 4, 9, 17, 5, 1, 7, 10, 6, 12],
                "worst-individual-distance": 77921.1218669762,
                "average-distance": 72397.53746384464,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 9, 1, 2, 11, 5, 7, 3, 8, 4, 15, 19, 29, 18, 28, 22, 20, 24, 25, 23, 21, 27, 16, 17, 26, 14, 13, 6, 12],
                "best-individual-distance": 55913.55192124808,
                "worst-individual-sequence": [14, 15, 29, 9, 6, 4, 10, 19, 24, 23, 16, 25, 26, 20, 28, 13, 21, 7, 8, 11, 2, 1, 5, 12, 18, 22, 27, 3, 17],
                "worst-individual-distance": 77019.41840075172,
                "average-distance": 71612.32024810601,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 16, 24, 27, 20, 17, 29, 21, 22, 19, 18, 9, 5, 3, 4, 10, 11, 12, 8, 6, 1, 2, 7, 25, 15, 13, 28, 14, 23],
                "best-individual-distance": 52387.31424985281,
                "worst-individual-sequence": [20, 8, 9, 12, 2, 1, 6, 10, 15, 16, 7, 3, 23, 27, 17, 26, 18, 28, 24, 29, 21, 22, 19, 25, 5, 4, 14, 13, 11],
                "worst-individual-distance": 76086.23217856744,
                "average-distance": 70805.03124599051,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 16, 24, 27, 20, 17, 29, 21, 22, 19, 18, 9, 5, 3, 4, 10, 11, 12, 8, 6, 1, 2, 7, 25, 15, 13, 28, 14, 23],
                "best-individual-distance": 52387.31424985281,
                "worst-individual-sequence": [26, 9, 13, 6, 4, 11, 5, 2, 1, 10, 7, 14, 20, 8, 28, 23, 27, 24, 22, 3, 12, 17, 16, 29, 19, 21, 18, 15, 25],
                "worst-individual-distance": 75220.01937125038,
                "average-distance": 70055.77328273038,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 16, 24, 27, 20, 17, 29, 21, 22, 19, 18, 9, 5, 3, 4, 10, 11, 12, 8, 6, 1, 2, 7, 25, 15, 13, 28, 14, 23],
                "best-individual-distance": 52387.31424985281,
                "worst-individual-sequence": [7, 12, 2, 10, 18, 24, 13, 14, 16, 15, 29, 21, 28, 22, 23, 20, 11, 9, 6, 1, 5, 3, 4, 8, 25, 19, 27, 26, 17],
                "worst-individual-distance": 74300.54918216485,
                "average-distance": 69361.41177125525,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 16, 24, 27, 20, 17, 29, 21, 22, 19, 18, 9, 5, 3, 4, 10, 11, 12, 8, 6, 1, 2, 7, 25, 15, 13, 28, 14, 23],
                "best-individual-distance": 52387.31424985281,
                "worst-individual-sequence": [13, 5, 3, 23, 21, 20, 25, 26, 27, 28, 24, 16, 1, 6, 4, 2, 9, 22, 17, 29, 10, 11, 12, 8, 19, 7, 14, 15, 18],
                "worst-individual-distance": 73450.27918299651,
                "average-distance": 68639.87863708954,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 16, 24, 27, 20, 17, 29, 21, 22, 19, 18, 9, 5, 3, 4, 10, 11, 12, 8, 6, 1, 2, 7, 25, 15, 13, 28, 14, 23],
                "best-individual-distance": 52387.31424985281,
                "worst-individual-sequence": [3, 6, 2, 8, 19, 13, 5, 4, 10, 15, 23, 16, 29, 18, 9, 17, 11, 1, 12, 20, 27, 25, 24, 21, 14, 26, 22, 28, 7],
                "worst-individual-distance": 72882.22790912351,
                "average-distance": 67901.94507075183,
                "individual-distances": []
            }, {
                "best-individual-sequence": [29, 28, 14, 11, 10, 8, 13, 17, 20, 21, 23, 22, 7, 6, 1, 5, 3, 4, 2, 9, 12, 15, 19, 18, 26, 25, 24, 16, 27],
                "best-individual-distance": 52132.75530846864,
                "worst-individual-sequence": [13, 8, 12, 10, 1, 2, 11, 5, 4, 14, 20, 18, 21, 29, 22, 24, 7, 6, 3, 27, 19, 25, 16, 9, 17, 15, 26, 23, 28],
                "worst-individual-distance": 72125.09702397193,
                "average-distance": 67264.02273266457,
                "individual-distances": []
            }, {
                "best-individual-sequence": [29, 28, 14, 11, 10, 8, 13, 17, 20, 21, 23, 22, 7, 6, 1, 5, 3, 4, 2, 9, 12, 15, 19, 18, 26, 25, 24, 16, 27],
                "best-individual-distance": 52132.75530846864,
                "worst-individual-sequence": [5, 18, 20, 25, 23, 22, 10, 8, 13, 24, 15, 29, 21, 28, 26, 19, 6, 11, 7, 4, 9, 27, 16, 17, 14, 3, 12, 1, 2],
                "worst-individual-distance": 71367.48849261853,
                "average-distance": 66553.13655853245,
                "individual-distances": []
            }, {
                "best-individual-sequence": [29, 28, 14, 11, 10, 8, 13, 17, 20, 21, 23, 22, 7, 6, 1, 5, 3, 4, 2, 9, 12, 15, 19, 18, 26, 25, 24, 16, 27],
                "best-individual-distance": 52132.75530846864,
                "worst-individual-sequence": [10, 6, 2, 12, 29, 14, 18, 21, 28, 5, 20, 16, 26, 27, 17, 19, 13, 8, 3, 4, 11, 15, 22, 24, 25, 23, 9, 7, 1],
                "worst-individual-distance": 70556.12512794838,
                "average-distance": 65896.83907861594,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 6, 1, 29, 11, 10, 17, 20, 28, 14, 16, 24, 25, 21, 23, 18, 27, 26, 19, 22, 13, 15, 12, 8, 3, 7, 9, 5, 2],
                "best-individual-distance": 51750.89691966409,
                "worst-individual-sequence": [27, 16, 23, 9, 7, 3, 8, 13, 24, 4, 29, 21, 28, 26, 19, 11, 22, 20, 17, 15, 6, 1, 5, 2, 10, 12, 18, 14, 25],
                "worst-individual-distance": 69851.8689412056,
                "average-distance": 65340.52897178489,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 6, 1, 29, 11, 10, 17, 20, 28, 14, 16, 24, 25, 21, 23, 18, 27, 26, 19, 22, 13, 15, 12, 8, 3, 7, 9, 5, 2],
                "best-individual-distance": 51750.89691966409,
                "worst-individual-sequence": [13, 22, 15, 14, 12, 2, 1, 10, 7, 3, 8, 11, 9, 5, 24, 29, 20, 21, 23, 25, 16, 17, 19, 18, 26, 28, 27, 6, 4],
                "worst-individual-distance": 69284.36048348657,
                "average-distance": 64715.65007758929,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 6, 1, 29, 11, 10, 17, 20, 28, 14, 16, 24, 25, 21, 23, 18, 27, 26, 19, 22, 13, 15, 12, 8, 3, 7, 9, 5, 2],
                "best-individual-distance": 51750.89691966409,
                "worst-individual-sequence": [7, 27, 22, 13, 23, 15, 19, 16, 28, 26, 18, 5, 4, 9, 3, 2, 6, 1, 17, 29, 21, 10, 11, 12, 14, 24, 25, 20, 8],
                "worst-individual-distance": 68643.46120201831,
                "average-distance": 64104.034523108094,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 26, 20, 18, 7, 3, 8, 13, 5, 4, 11, 1, 2, 6, 10, 9, 12, 19, 15, 28, 21, 27, 25, 24, 16, 22, 29, 23, 14],
                "best-individual-distance": 49051.24893401129,
                "worst-individual-sequence": [9, 8, 24, 29, 21, 11, 5, 3, 4, 6, 12, 7, 13, 28, 26, 19, 15, 1, 2, 10, 22, 20, 17, 18, 14, 25, 27, 16, 23],
                "worst-individual-distance": 67850.48963066071,
                "average-distance": 63443.234342958334,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 26, 20, 18, 7, 3, 8, 13, 5, 4, 11, 1, 2, 6, 10, 9, 12, 19, 15, 28, 21, 27, 25, 24, 16, 22, 29, 23, 14],
                "best-individual-distance": 49051.24893401129,
                "worst-individual-sequence": [28, 19, 5, 4, 8, 6, 18, 11, 7, 3, 12, 2, 1, 10, 14, 20, 29, 21, 27, 24, 22, 25, 26, 13, 9, 15, 23, 17, 16],
                "worst-individual-distance": 67271.89098028764,
                "average-distance": 62864.39898925717,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 2, 5, 3, 7, 13, 20, 26, 28, 23, 22, 21, 25, 24, 27, 16, 14, 10, 4, 8, 11, 12, 15, 19, 18, 17, 29, 6, 9],
                "best-individual-distance": 45627.3734416411,
                "worst-individual-sequence": [14, 29, 21, 20, 13, 18, 5, 4, 9, 28, 23, 17, 16, 3, 10, 11, 12, 8, 6, 1, 2, 7, 15, 27, 26, 22, 24, 25, 19],
                "worst-individual-distance": 66756.60032264798,
                "average-distance": 62186.319535290415,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 2, 5, 3, 7, 13, 20, 26, 28, 23, 22, 21, 25, 24, 27, 16, 14, 10, 4, 8, 11, 12, 15, 19, 18, 17, 29, 6, 9],
                "best-individual-distance": 45627.3734416411,
                "worst-individual-sequence": [29, 27, 26, 19, 18, 21, 8, 24, 25, 16, 23, 20, 28, 13, 7, 9, 5, 3, 2, 4, 15, 22, 17, 14, 12, 10, 11, 1, 6],
                "worst-individual-distance": 66138.46212501291,
                "average-distance": 61600.818505455456,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 2, 5, 3, 7, 13, 20, 26, 28, 23, 22, 21, 25, 24, 27, 16, 14, 10, 4, 8, 11, 12, 15, 19, 18, 17, 29, 6, 9],
                "best-individual-distance": 45627.3734416411,
                "worst-individual-sequence": [19, 25, 16, 23, 13, 7, 5, 3, 8, 20, 26, 9, 12, 2, 1, 6, 4, 18, 28, 27, 24, 22, 17, 29, 21, 10, 11, 14, 15],
                "worst-individual-distance": 65487.24320934166,
                "average-distance": 61029.87029311891,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 2, 5, 3, 7, 13, 20, 26, 28, 23, 22, 21, 25, 24, 27, 16, 14, 10, 4, 8, 11, 12, 15, 19, 18, 17, 29, 6, 9],
                "best-individual-distance": 45627.3734416411,
                "worst-individual-sequence": [8, 22, 20, 24, 13, 21, 23, 7, 6, 1, 5, 3, 4, 2, 9, 12, 15, 19, 26, 17, 18, 14, 25, 16, 27, 29, 28, 11, 10],
                "worst-individual-distance": 64831.57295707824,
                "average-distance": 60397.71002163219,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 2, 5, 3, 7, 13, 20, 26, 28, 23, 22, 21, 25, 24, 27, 16, 14, 10, 4, 8, 11, 12, 15, 19, 18, 17, 29, 6, 9],
                "best-individual-distance": 45627.3734416411,
                "worst-individual-sequence": [27, 16, 23, 9, 7, 3, 8, 13, 24, 4, 29, 21, 28, 26, 19, 11, 22, 20, 17, 15, 6, 1, 5, 2, 10, 12, 18, 14, 25],
                "worst-individual-distance": 64160.23268440585,
                "average-distance": 59861.85806117815,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 25, 24, 27, 16, 14, 9, 3, 4, 1, 2, 11, 5, 6, 10, 12, 7, 8, 13, 19, 29, 18, 15, 17, 20, 26, 28, 23, 22],
                "best-individual-distance": 42317.9770014434,
                "worst-individual-sequence": [5, 14, 27, 29, 20, 22, 17, 23, 15, 10, 12, 9, 28, 26, 16, 24, 25, 21, 19, 18, 4, 7, 8, 11, 13, 6, 2, 3, 1],
                "worst-individual-distance": 63618.94373256116,
                "average-distance": 59262.16621149063,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 25, 24, 27, 16, 14, 9, 3, 4, 1, 2, 11, 5, 6, 10, 12, 7, 8, 13, 19, 29, 18, 15, 17, 20, 26, 28, 23, 22],
                "best-individual-distance": 42317.9770014434,
                "worst-individual-sequence": [1, 6, 13, 26, 19, 23, 18, 10, 12, 14, 27, 24, 22, 17, 15, 11, 7, 4, 5, 3, 8, 9, 25, 16, 29, 21, 20, 28, 2],
                "worst-individual-distance": 63007.18285788814,
                "average-distance": 58738.782933288,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 25, 24, 27, 16, 14, 9, 3, 4, 1, 2, 11, 5, 6, 10, 12, 7, 8, 13, 19, 29, 18, 15, 17, 20, 26, 28, 23, 22],
                "best-individual-distance": 42317.9770014434,
                "worst-individual-sequence": [23, 13, 7, 8, 3, 15, 16, 14, 20, 29, 21, 24, 26, 22, 19, 9, 11, 4, 6, 1, 5, 2, 10, 12, 17, 25, 27, 28, 18],
                "worst-individual-distance": 62341.714749238046,
                "average-distance": 58218.93507346685,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 25, 24, 27, 16, 14, 9, 3, 4, 1, 2, 11, 5, 6, 10, 12, 7, 8, 13, 19, 29, 18, 15, 17, 20, 26, 28, 23, 22],
                "best-individual-distance": 42317.9770014434,
                "worst-individual-sequence": [19, 29, 21, 20, 13, 18, 3, 4, 10, 11, 12, 17, 25, 24, 27, 16, 14, 9, 8, 6, 1, 2, 28, 7, 5, 15, 26, 22, 23],
                "worst-individual-distance": 61748.739616844985,
                "average-distance": 57692.186142624196,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 25, 24, 27, 16, 14, 9, 3, 4, 1, 2, 11, 5, 6, 10, 12, 7, 8, 13, 19, 29, 18, 15, 17, 20, 26, 28, 23, 22],
                "best-individual-distance": 42317.9770014434,
                "worst-individual-sequence": [20, 24, 7, 3, 13, 5, 4, 11, 1, 2, 8, 9, 12, 6, 22, 18, 10, 15, 17, 14, 23, 29, 21, 19, 28, 16, 25, 26, 27],
                "worst-individual-distance": 61075.52748724071,
                "average-distance": 57185.32361355257,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 25, 24, 27, 16, 14, 9, 3, 4, 1, 2, 11, 5, 6, 10, 12, 7, 8, 13, 19, 29, 18, 15, 17, 20, 26, 28, 23, 22],
                "best-individual-distance": 42317.9770014434,
                "worst-individual-sequence": [3, 1, 4, 7, 8, 27, 20, 28, 14, 16, 24, 25, 29, 10, 11, 9, 12, 21, 23, 19, 17, 18, 26, 22, 15, 13, 5, 6, 2],
                "worst-individual-distance": 60508.47083030723,
                "average-distance": 56643.065024026495,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 25, 24, 27, 16, 14, 9, 3, 4, 1, 2, 11, 5, 6, 10, 12, 7, 8, 13, 19, 29, 18, 15, 17, 20, 26, 28, 23, 22],
                "best-individual-distance": 42317.9770014434,
                "worst-individual-sequence": [12, 15, 19, 16, 25, 26, 27, 24, 22, 20, 28, 13, 8, 7, 4, 18, 11, 5, 9, 3, 17, 14, 21, 29, 23, 10, 1, 2, 6],
                "worst-individual-distance": 60044.021533535924,
                "average-distance": 56177.965111320926,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 25, 24, 27, 16, 14, 9, 3, 4, 1, 2, 11, 5, 6, 10, 12, 7, 8, 13, 19, 29, 18, 15, 17, 20, 26, 28, 23, 22],
                "best-individual-distance": 42317.9770014434,
                "worst-individual-sequence": [22, 23, 28, 20, 17, 12, 7, 8, 26, 13, 18, 9, 5, 3, 4, 10, 11, 6, 1, 2, 29, 14, 21, 15, 19, 27, 24, 25, 16],
                "worst-individual-distance": 59478.74998173548,
                "average-distance": 55641.748353968724,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 25, 24, 27, 16, 14, 9, 3, 4, 1, 2, 11, 5, 6, 10, 12, 7, 8, 13, 19, 29, 18, 15, 17, 20, 26, 28, 23, 22],
                "best-individual-distance": 42317.9770014434,
                "worst-individual-sequence": [20, 21, 23, 18, 26, 17, 25, 27, 8, 1, 2, 11, 5, 3, 4, 6, 12, 9, 7, 10, 24, 22, 19, 15, 28, 16, 29, 14, 13],
                "worst-individual-distance": 59018.2189839072,
                "average-distance": 55215.07314207144,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 25, 24, 27, 16, 14, 9, 3, 4, 1, 2, 11, 5, 6, 10, 12, 7, 8, 13, 19, 29, 18, 15, 17, 20, 26, 28, 23, 22],
                "best-individual-distance": 42317.9770014434,
                "worst-individual-sequence": [1, 10, 7, 14, 27, 23, 25, 24, 16, 22, 19, 15, 29, 20, 21, 26, 9, 11, 12, 17, 28, 18, 13, 3, 4, 5, 8, 6, 2],
                "worst-individual-distance": 58555.27694859491,
                "average-distance": 54806.89047852126,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 25, 24, 27, 16, 14, 9, 3, 4, 1, 2, 11, 5, 6, 10, 12, 7, 8, 13, 19, 29, 18, 15, 17, 20, 26, 28, 23, 22],
                "best-individual-distance": 42317.9770014434,
                "worst-individual-sequence": [27, 24, 15, 19, 18, 21, 28, 22, 13, 10, 8, 6, 2, 5, 3, 1, 11, 7, 4, 16, 26, 23, 29, 9, 12, 14, 17, 20, 25],
                "worst-individual-distance": 58126.050112771445,
                "average-distance": 54424.21078400226,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 25, 24, 27, 16, 14, 9, 3, 4, 1, 2, 11, 5, 6, 10, 12, 7, 8, 13, 19, 29, 18, 15, 17, 20, 26, 28, 23, 22],
                "best-individual-distance": 42317.9770014434,
                "worst-individual-sequence": [12, 17, 23, 18, 28, 22, 24, 25, 27, 16, 9, 6, 4, 2, 1, 5, 3, 7, 8, 10, 26, 14, 29, 21, 20, 13, 11, 15, 19],
                "worst-individual-distance": 57724.655785298215,
                "average-distance": 53980.81752611248,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 25, 24, 27, 16, 14, 9, 3, 4, 1, 2, 11, 5, 6, 10, 12, 7, 8, 13, 19, 29, 18, 15, 17, 20, 26, 28, 23, 22],
                "best-individual-distance": 42317.9770014434,
                "worst-individual-sequence": [26, 27, 24, 22, 28, 3, 9, 15, 4, 1, 2, 11, 5, 6, 10, 12, 7, 8, 13, 19, 18, 17, 20, 21, 14, 23, 29, 16, 25],
                "worst-individual-distance": 57305.633444025596,
                "average-distance": 53627.10648511081,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 25, 24, 27, 16, 14, 9, 3, 4, 1, 2, 11, 5, 6, 10, 12, 7, 8, 13, 19, 29, 18, 15, 17, 20, 26, 28, 23, 22],
                "best-individual-distance": 42317.9770014434,
                "worst-individual-sequence": [1, 10, 7, 14, 27, 23, 25, 24, 16, 22, 19, 15, 29, 20, 21, 26, 9, 11, 12, 17, 28, 18, 13, 3, 4, 5, 8, 6, 2],
                "worst-individual-distance": 56984.344502037005,
                "average-distance": 53267.800451204006,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 25, 24, 27, 16, 14, 9, 3, 4, 1, 2, 11, 5, 6, 10, 12, 7, 8, 13, 19, 29, 18, 15, 17, 20, 26, 28, 23, 22],
                "best-individual-distance": 42317.9770014434,
                "worst-individual-sequence": [19, 29, 18, 28, 20, 21, 27, 16, 13, 26, 17, 23, 24, 25, 12, 11, 10, 6, 4, 8, 2, 5, 1, 7, 3, 9, 14, 22, 15],
                "worst-individual-distance": 56499.867261808984,
                "average-distance": 52899.33140869917,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 25, 24, 27, 16, 14, 9, 3, 4, 1, 2, 11, 5, 6, 10, 12, 7, 8, 13, 19, 29, 18, 15, 17, 20, 26, 28, 23, 22],
                "best-individual-distance": 42317.9770014434,
                "worst-individual-sequence": [16, 17, 24, 27, 14, 23, 20, 25, 26, 13, 18, 9, 5, 3, 4, 10, 11, 12, 8, 6, 1, 2, 7, 29, 28, 19, 15, 22, 21],
                "worst-individual-distance": 56189.648918583334,
                "average-distance": 52548.85940428646,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 25, 24, 27, 16, 14, 9, 3, 4, 1, 2, 11, 5, 6, 10, 12, 7, 8, 13, 19, 29, 18, 15, 17, 20, 26, 28, 23, 22],
                "best-individual-distance": 42317.9770014434,
                "worst-individual-sequence": [5, 3, 10, 11, 22, 18, 23, 28, 20, 17, 13, 9, 12, 2, 1, 6, 4, 8, 7, 15, 25, 14, 26, 16, 24, 27, 29, 21, 19],
                "worst-individual-distance": 55765.418719652924,
                "average-distance": 52179.22063294251,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 25, 24, 27, 16, 14, 9, 3, 4, 1, 2, 11, 5, 6, 10, 12, 7, 8, 13, 19, 29, 18, 15, 17, 20, 26, 28, 23, 22],
                "best-individual-distance": 42317.9770014434,
                "worst-individual-sequence": [25, 16, 27, 18, 20, 28, 9, 12, 2, 1, 6, 4, 5, 3, 7, 8, 10, 17, 26, 22, 15, 13, 11, 14, 29, 21, 19, 23, 24],
                "worst-individual-distance": 55286.8811317492,
                "average-distance": 51852.98892803221,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 25, 24, 27, 16, 14, 9, 3, 4, 1, 2, 11, 5, 6, 10, 12, 7, 8, 13, 19, 29, 18, 15, 17, 20, 26, 28, 23, 22],
                "best-individual-distance": 42317.9770014434,
                "worst-individual-sequence": [23, 19, 26, 17, 22, 20, 28, 14, 13, 7, 8, 3, 9, 11, 4, 15, 18, 6, 1, 5, 2, 10, 12, 21, 29, 16, 25, 27, 24],
                "worst-individual-distance": 54942.56413885525,
                "average-distance": 51576.94941838601,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 25, 24, 27, 16, 14, 9, 3, 4, 1, 2, 11, 5, 6, 10, 12, 7, 8, 13, 19, 29, 18, 15, 17, 20, 26, 28, 23, 22],
                "best-individual-distance": 42317.9770014434,
                "worst-individual-sequence": [4, 11, 1, 2, 6, 10, 9, 25, 20, 27, 16, 18, 21, 23, 26, 17, 24, 22, 19, 15, 28, 29, 14, 12, 7, 3, 8, 13, 5],
                "worst-individual-distance": 54560.5824387348,
                "average-distance": 51260.27126324838,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 25, 24, 27, 16, 14, 9, 3, 4, 1, 2, 11, 5, 6, 10, 12, 7, 8, 13, 19, 29, 18, 15, 17, 20, 26, 28, 23, 22],
                "best-individual-distance": 42317.9770014434,
                "worst-individual-sequence": [28, 14, 9, 12, 2, 1, 6, 3, 4, 11, 5, 10, 7, 8, 13, 19, 18, 17, 20, 21, 27, 16, 25, 23, 22, 15, 26, 24, 29],
                "worst-individual-distance": 54192.64548109005,
                "average-distance": 50972.869998043345,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 25, 24, 27, 16, 14, 9, 3, 4, 1, 2, 11, 5, 6, 10, 12, 7, 8, 13, 19, 29, 18, 15, 17, 20, 26, 28, 23, 22],
                "best-individual-distance": 42317.9770014434,
                "worst-individual-sequence": [23, 17, 24, 21, 25, 16, 28, 27, 29, 22, 2, 9, 13, 11, 1, 6, 4, 5, 3, 7, 8, 10, 12, 14, 15, 19, 18, 20, 26],
                "worst-individual-distance": 53930.51398407396,
                "average-distance": 50704.53892371344,
                "individual-distances": []
            }, {
                "best-individual-sequence": [28, 23, 21, 22, 15, 14, 9, 3, 4, 1, 2, 11, 5, 6, 10, 12, 7, 8, 13, 19, 18, 17, 20, 16, 24, 25, 27, 26, 29],
                "best-individual-distance": 40278.94680541415,
                "worst-individual-sequence": [25, 26, 27, 24, 22, 28, 1, 9, 3, 4, 2, 11, 5, 6, 10, 12, 7, 8, 13, 19, 18, 17, 20, 21, 29, 23, 14, 15, 16],
                "worst-individual-distance": 53629.34532911234,
                "average-distance": 50329.31099423549,
                "individual-distances": []
            }, {
                "best-individual-sequence": [28, 23, 21, 22, 15, 14, 9, 3, 4, 1, 2, 11, 5, 6, 10, 12, 7, 8, 13, 19, 18, 17, 20, 16, 24, 25, 27, 26, 29],
                "best-individual-distance": 40278.94680541415,
                "worst-individual-sequence": [3, 9, 6, 10, 12, 19, 2, 11, 5, 4, 7, 8, 1, 29, 15, 18, 28, 22, 20, 24, 25, 23, 21, 27, 16, 17, 26, 14, 13],
                "worst-individual-distance": 53311.82392681332,
                "average-distance": 50005.81829222292,
                "individual-distances": []
            }, {
                "best-individual-sequence": [28, 23, 21, 22, 15, 14, 9, 3, 4, 1, 2, 11, 5, 6, 10, 12, 7, 8, 13, 19, 18, 17, 20, 16, 24, 25, 27, 26, 29],
                "best-individual-distance": 40278.94680541415,
                "worst-individual-sequence": [2, 12, 7, 3, 4, 10, 8, 11, 9, 27, 29, 20, 28, 14, 16, 24, 25, 21, 23, 19, 17, 18, 26, 22, 15, 13, 5, 6, 1],
                "worst-individual-distance": 52951.20818244587,
                "average-distance": 49670.36079732054,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 9, 4, 3, 11, 12, 8, 6, 1, 2, 5, 7, 13, 19, 18, 17, 20, 16, 24, 27, 25, 28, 22, 15, 29, 26, 23, 21, 14],
                "best-individual-distance": 39386.82355218286,
                "worst-individual-sequence": [29, 28, 14, 11, 10, 8, 13, 17, 20, 21, 23, 22, 7, 6, 1, 5, 3, 4, 2, 9, 12, 15, 19, 18, 26, 25, 24, 16, 27],
                "worst-individual-distance": 52606.182455046954,
                "average-distance": 49307.964275825274,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 9, 4, 3, 11, 12, 8, 6, 1, 2, 5, 7, 13, 19, 18, 17, 20, 16, 24, 27, 25, 28, 22, 15, 29, 26, 23, 21, 14],
                "best-individual-distance": 39386.82355218286,
                "worst-individual-sequence": [17, 15, 19, 16, 25, 26, 27, 24, 21, 20, 28, 13, 11, 7, 3, 9, 8, 4, 6, 1, 5, 2, 10, 12, 22, 18, 14, 23, 29],
                "worst-individual-distance": 52316.06129168351,
                "average-distance": 49008.01009082551,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 9, 4, 3, 11, 12, 8, 6, 1, 2, 5, 7, 13, 19, 18, 17, 20, 16, 24, 27, 25, 28, 22, 15, 29, 26, 23, 21, 14],
                "best-individual-distance": 39386.82355218286,
                "worst-individual-sequence": [14, 29, 21, 20, 13, 11, 5, 3, 4, 7, 8, 9, 12, 2, 1, 6, 10, 18, 28, 27, 24, 22, 19, 15, 25, 16, 26, 23, 17],
                "worst-individual-distance": 51990.00661634039,
                "average-distance": 48720.24080630068,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 9, 4, 3, 11, 12, 8, 6, 1, 2, 5, 7, 13, 19, 18, 17, 20, 16, 24, 27, 25, 28, 22, 15, 29, 26, 23, 21, 14],
                "best-individual-distance": 39386.82355218286,
                "worst-individual-sequence": [18, 23, 28, 20, 17, 12, 8, 7, 9, 2, 1, 6, 4, 5, 10, 11, 15, 21, 25, 27, 26, 14, 13, 3, 29, 19, 24, 16, 22],
                "worst-individual-distance": 51677.5374887884,
                "average-distance": 48422.82166408722,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 9, 4, 3, 11, 12, 8, 6, 1, 2, 5, 7, 13, 19, 18, 17, 20, 16, 24, 27, 25, 28, 22, 15, 29, 26, 23, 21, 14],
                "best-individual-distance": 39386.82355218286,
                "worst-individual-sequence": [1, 10, 11, 6, 17, 20, 14, 16, 24, 25, 21, 23, 18, 29, 26, 28, 19, 15, 22, 13, 12, 8, 2, 5, 3, 7, 4, 9, 27],
                "worst-individual-distance": 51407.548524234815,
                "average-distance": 48125.999594798064,
                "individual-distances": []
            }, {
                "best-individual-sequence": [7, 13, 20, 26, 28, 23, 22, 21, 25, 24, 27, 16, 14, 9, 4, 10, 11, 12, 8, 6, 1, 2, 5, 19, 29, 18, 15, 17, 3],
                "best-individual-distance": 39222.11072717939,
                "worst-individual-sequence": [21, 22, 23, 20, 13, 7, 8, 11, 9, 14, 6, 1, 5, 3, 4, 2, 10, 12, 15, 19, 18, 26, 25, 27, 16, 17, 24, 29, 28],
                "worst-individual-distance": 51006.29292505617,
                "average-distance": 47792.109734757425,
                "individual-distances": []
            }, {
                "best-individual-sequence": [7, 13, 20, 26, 28, 23, 22, 21, 25, 24, 27, 16, 14, 9, 4, 10, 11, 12, 8, 6, 1, 2, 5, 19, 29, 18, 15, 17, 3],
                "best-individual-distance": 39222.11072717939,
                "worst-individual-sequence": [7, 26, 28, 23, 21, 22, 13, 20, 25, 24, 27, 16, 14, 9, 4, 10, 11, 12, 8, 6, 1, 2, 5, 19, 29, 18, 15, 17, 3],
                "worst-individual-distance": 50569.980348880774,
                "average-distance": 47505.04362482322,
                "individual-distances": []
            }, {
                "best-individual-sequence": [7, 13, 20, 26, 28, 23, 22, 21, 25, 24, 27, 16, 14, 9, 4, 10, 11, 12, 8, 6, 1, 2, 5, 19, 29, 18, 15, 17, 3],
                "best-individual-distance": 39222.11072717939,
                "worst-individual-sequence": [5, 12, 13, 17, 23, 19, 26, 20, 21, 29, 22, 18, 28, 24, 25, 27, 16, 14, 3, 7, 8, 4, 9, 15, 10, 11, 6, 2, 1],
                "worst-individual-distance": 50242.8711731528,
                "average-distance": 47251.43745365727,
                "individual-distances": []
            }, {
                "best-individual-sequence": [7, 13, 20, 26, 28, 23, 22, 21, 25, 24, 27, 16, 14, 9, 4, 10, 11, 12, 8, 6, 1, 2, 5, 19, 29, 18, 15, 17, 3],
                "best-individual-distance": 39222.11072717939,
                "worst-individual-sequence": [24, 16, 20, 28, 14, 9, 15, 3, 4, 1, 2, 11, 5, 6, 10, 12, 7, 8, 13, 19, 18, 21, 23, 29, 17, 22, 25, 26, 27],
                "worst-individual-distance": 49874.40509762136,
                "average-distance": 46970.70165202453,
                "individual-distances": []
            }, {
                "best-individual-sequence": [7, 13, 20, 26, 28, 23, 22, 21, 25, 24, 27, 16, 14, 9, 4, 10, 11, 12, 8, 6, 1, 2, 5, 19, 29, 18, 15, 17, 3],
                "best-individual-distance": 39222.11072717939,
                "worst-individual-sequence": [26, 22, 23, 19, 17, 14, 20, 28, 18, 15, 10, 13, 8, 7, 3, 9, 11, 4, 6, 1, 5, 2, 12, 21, 29, 16, 25, 27, 24],
                "worst-individual-distance": 49518.17814901975,
                "average-distance": 46697.54084080032,
                "individual-distances": []
            }, {
                "best-individual-sequence": [7, 3, 9, 4, 5, 2, 1, 6, 10, 11, 13, 14, 15, 19, 18, 21, 29, 22, 28, 27, 24, 26, 23, 12, 16, 20, 17, 25, 8],
                "best-individual-distance": 38558.372639271234,
                "worst-individual-sequence": [17, 23, 29, 19, 28, 12, 9, 8, 6, 1, 2, 7, 5, 3, 4, 10, 11, 14, 21, 22, 26, 27, 24, 16, 25, 20, 13, 18, 15],
                "worst-individual-distance": 49231.85774351987,
                "average-distance": 46476.33014548658,
                "individual-distances": []
            }, {
                "best-individual-sequence": [7, 3, 9, 4, 5, 2, 1, 6, 10, 11, 13, 14, 15, 19, 18, 21, 29, 22, 28, 27, 24, 26, 23, 12, 16, 20, 17, 25, 8],
                "best-individual-distance": 38558.372639271234,
                "worst-individual-sequence": [17, 13, 18, 14, 9, 3, 4, 10, 11, 12, 8, 6, 1, 2, 7, 5, 27, 21, 15, 19, 24, 29, 25, 16, 26, 22, 23, 20, 28],
                "worst-individual-distance": 48976.35188854,
                "average-distance": 46236.86053508943,
                "individual-distances": []
            }, {
                "best-individual-sequence": [7, 3, 9, 4, 5, 2, 1, 6, 10, 11, 13, 14, 15, 19, 18, 21, 29, 22, 28, 27, 24, 26, 23, 12, 16, 20, 17, 25, 8],
                "best-individual-distance": 38558.372639271234,
                "worst-individual-sequence": [16, 17, 14, 13, 9, 5, 3, 4, 11, 12, 8, 6, 1, 2, 7, 10, 26, 19, 29, 20, 21, 23, 22, 15, 18, 28, 24, 25, 27],
                "worst-individual-distance": 48733.556673010215,
                "average-distance": 46008.57080781314,
                "individual-distances": []
            }, {
                "best-individual-sequence": [7, 3, 9, 4, 5, 2, 1, 6, 10, 11, 13, 14, 15, 19, 18, 21, 29, 22, 28, 27, 24, 26, 23, 12, 16, 20, 17, 25, 8],
                "best-individual-distance": 38558.372639271234,
                "worst-individual-sequence": [21, 23, 22, 15, 19, 18, 26, 10, 11, 12, 8, 9, 28, 24, 25, 27, 16, 17, 14, 13, 3, 6, 1, 2, 5, 4, 7, 29, 20],
                "worst-individual-distance": 48499.119879555445,
                "average-distance": 45805.708710315055,
                "individual-distances": []
            }, {
                "best-individual-sequence": [7, 3, 9, 4, 5, 2, 1, 6, 10, 11, 13, 14, 15, 19, 18, 21, 29, 22, 28, 27, 24, 26, 23, 12, 16, 20, 17, 25, 8],
                "best-individual-distance": 38558.372639271234,
                "worst-individual-sequence": [10, 29, 20, 21, 23, 22, 19, 15, 11, 12, 8, 9, 18, 28, 24, 25, 27, 16, 17, 26, 14, 13, 3, 6, 1, 2, 5, 4, 7],
                "worst-individual-distance": 48173.44001068006,
                "average-distance": 45621.97530658805,
                "individual-distances": []
            }, {
                "best-individual-sequence": [7, 3, 9, 4, 5, 2, 1, 6, 10, 11, 13, 14, 15, 19, 18, 21, 29, 22, 28, 27, 24, 26, 23, 12, 16, 20, 17, 25, 8],
                "best-individual-distance": 38558.372639271234,
                "worst-individual-sequence": [23, 21, 18, 22, 24, 25, 27, 16, 28, 20, 29, 19, 9, 1, 2, 10, 11, 12, 5, 3, 4, 7, 8, 14, 15, 6, 13, 17, 26],
                "worst-individual-distance": 47987.01121302172,
                "average-distance": 45362.388164186064,
                "individual-distances": []
            }, {
                "best-individual-sequence": [7, 3, 9, 4, 5, 2, 1, 6, 10, 11, 13, 14, 15, 19, 18, 21, 29, 22, 28, 27, 24, 26, 23, 12, 16, 20, 17, 25, 8],
                "best-individual-distance": 38558.372639271234,
                "worst-individual-sequence": [21, 15, 26, 19, 22, 18, 23, 20, 28, 17, 13, 9, 12, 2, 1, 6, 4, 5, 3, 7, 8, 10, 11, 14, 29, 27, 16, 25, 24],
                "worst-individual-distance": 47767.813549744926,
                "average-distance": 45124.16190276575,
                "individual-distances": []
            }, {
                "best-individual-sequence": [19, 18, 26, 25, 24, 27, 16, 14, 4, 12, 11, 10, 9, 8, 6, 1, 2, 5, 3, 7, 13, 15, 17, 21, 23, 22, 29, 20, 28],
                "best-individual-distance": 38375.10863055197,
                "worst-individual-sequence": [9, 7, 8, 13, 18, 29, 21, 3, 4, 11, 1, 2, 5, 6, 10, 12, 15, 19, 27, 24, 25, 16, 26, 22, 23, 20, 28, 17, 14],
                "worst-individual-distance": 47470.80402042678,
                "average-distance": 44949.50620405711,
                "individual-distances": []
            }, {
                "best-individual-sequence": [19, 18, 26, 25, 24, 27, 16, 14, 4, 12, 11, 10, 9, 8, 6, 1, 2, 5, 3, 7, 13, 15, 17, 21, 23, 22, 29, 20, 28],
                "best-individual-distance": 38375.10863055197,
                "worst-individual-sequence": [4, 7, 15, 18, 29, 20, 21, 23, 22, 10, 11, 12, 8, 9, 19, 28, 24, 25, 27, 16, 17, 26, 14, 13, 3, 6, 1, 2, 5],
                "worst-individual-distance": 47233.44882776349,
                "average-distance": 44771.97273922642,
                "individual-distances": []
            }, {
                "best-individual-sequence": [19, 18, 26, 25, 24, 27, 16, 14, 4, 12, 11, 10, 9, 8, 6, 1, 2, 5, 3, 7, 13, 15, 17, 21, 23, 22, 29, 20, 28],
                "best-individual-distance": 38375.10863055197,
                "worst-individual-sequence": [14, 9, 3, 4, 11, 22, 1, 5, 6, 10, 12, 7, 8, 13, 18, 20, 16, 25, 24, 2, 19, 15, 29, 21, 17, 23, 27, 26, 28],
                "worst-individual-distance": 46998.56380420193,
                "average-distance": 44576.60924465278,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 21, 23, 22, 18, 15, 19, 14, 12, 7, 3, 9, 4, 8, 6, 1, 2, 5, 10, 11, 13, 17, 27, 24, 25, 16, 26, 28, 29],
                "best-individual-distance": 38319.65654928862,
                "worst-individual-sequence": [20, 28, 14, 9, 3, 4, 1, 2, 11, 5, 6, 10, 12, 7, 8, 13, 19, 18, 23, 29, 17, 16, 24, 25, 21, 15, 22, 26, 27],
                "worst-individual-distance": 46673.14236838661,
                "average-distance": 44364.860127394415,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 21, 23, 22, 18, 15, 19, 14, 12, 7, 3, 9, 4, 8, 6, 1, 2, 5, 10, 11, 13, 17, 27, 24, 25, 16, 26, 28, 29],
                "best-individual-distance": 38319.65654928862,
                "worst-individual-sequence": [4, 7, 15, 18, 29, 20, 21, 23, 22, 10, 11, 12, 8, 9, 19, 28, 24, 25, 27, 16, 17, 26, 14, 13, 3, 6, 1, 2, 5],
                "worst-individual-distance": 46558.770440247295,
                "average-distance": 44149.54897071085,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 21, 23, 22, 18, 15, 19, 14, 12, 7, 3, 9, 4, 8, 6, 1, 2, 5, 10, 11, 13, 17, 27, 24, 25, 16, 26, 28, 29],
                "best-individual-distance": 38319.65654928862,
                "worst-individual-sequence": [22, 29, 28, 14, 9, 3, 11, 5, 4, 2, 1, 6, 10, 12, 7, 8, 13, 19, 18, 17, 20, 16, 24, 25, 23, 27, 26, 21, 15],
                "worst-individual-distance": 46405.02542799136,
                "average-distance": 43994.056670082726,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 21, 23, 22, 18, 15, 19, 14, 12, 7, 3, 9, 4, 8, 6, 1, 2, 5, 10, 11, 13, 17, 27, 24, 25, 16, 26, 28, 29],
                "best-individual-distance": 38319.65654928862,
                "worst-individual-sequence": [2, 1, 6, 10, 11, 26, 25, 15, 19, 18, 21, 29, 22, 28, 27, 13, 14, 16, 24, 20, 23, 17, 12, 8, 7, 3, 9, 4, 5],
                "worst-individual-distance": 46232.868896279084,
                "average-distance": 43827.435644457546,
                "individual-distances": []
            }, {
                "best-individual-sequence": [13, 17, 23, 26, 27, 24, 16, 25, 20, 21, 29, 22, 18, 28, 14, 19, 15, 12, 8, 7, 3, 9, 4, 5, 2, 1, 6, 10, 11],
                "best-individual-distance": 37717.55245147539,
                "worst-individual-sequence": [5, 15, 14, 9, 23, 19, 26, 20, 21, 29, 22, 18, 28, 24, 25, 27, 16, 17, 13, 7, 3, 4, 10, 11, 12, 8, 6, 1, 2],
                "worst-individual-distance": 45972.635811566426,
                "average-distance": 43641.18472068004,
                "individual-distances": []
            }, {
                "best-individual-sequence": [6, 10, 11, 13, 15, 19, 26, 20, 21, 29, 22, 18, 28, 24, 25, 27, 16, 14, 23, 17, 12, 8, 7, 3, 9, 4, 5, 2, 1],
                "best-individual-distance": 36952.08391092713,
                "worst-individual-sequence": [21, 16, 24, 27, 25, 28, 22, 15, 13, 14, 17, 9, 5, 3, 4, 10, 11, 12, 8, 6, 1, 2, 7, 26, 20, 29, 23, 19, 18],
                "worst-individual-distance": 45821.588061574475,
                "average-distance": 43493.08512818933,
                "individual-distances": []
            }, {
                "best-individual-sequence": [6, 10, 11, 13, 15, 19, 26, 20, 21, 29, 22, 18, 28, 24, 25, 27, 16, 14, 23, 17, 12, 8, 7, 3, 9, 4, 5, 2, 1],
                "best-individual-distance": 36952.08391092713,
                "worst-individual-sequence": [19, 26, 20, 21, 29, 22, 18, 28, 24, 25, 27, 16, 14, 15, 10, 6, 4, 5, 3, 7, 8, 9, 11, 2, 1, 12, 13, 17, 23],
                "worst-individual-distance": 45642.23189489606,
                "average-distance": 43333.020063422904,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 12, 8, 15, 19, 26, 20, 23, 21, 29, 22, 18, 28, 24, 25, 27, 16, 14, 17, 13, 7, 9, 3, 4, 5, 2, 1, 6, 10],
                "best-individual-distance": 35999.59207228486,
                "worst-individual-sequence": [21, 23, 22, 18, 14, 9, 3, 4, 1, 2, 11, 5, 6, 10, 12, 7, 8, 13, 17, 25, 26, 27, 24, 16, 28, 15, 19, 29, 20],
                "worst-individual-distance": 45482.1762319328,
                "average-distance": 43151.046586138604,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 12, 8, 15, 19, 26, 20, 23, 21, 29, 22, 18, 28, 24, 25, 27, 16, 14, 17, 13, 7, 9, 3, 4, 5, 2, 1, 6, 10],
                "best-individual-distance": 35999.59207228486,
                "worst-individual-sequence": [18, 23, 20, 14, 29, 21, 15, 19, 28, 17, 13, 9, 12, 2, 1, 6, 4, 5, 3, 7, 8, 10, 11, 27, 24, 25, 16, 26, 22],
                "worst-individual-distance": 45214.59542644709,
                "average-distance": 42984.92772770362,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 12, 8, 15, 19, 26, 20, 23, 21, 29, 22, 18, 28, 24, 25, 27, 16, 14, 17, 13, 7, 9, 3, 4, 5, 2, 1, 6, 10],
                "best-individual-distance": 35999.59207228486,
                "worst-individual-sequence": [2, 1, 13, 17, 23, 19, 26, 20, 21, 29, 22, 18, 28, 24, 25, 27, 16, 14, 15, 10, 11, 12, 8, 9, 3, 4, 6, 5, 7],
                "worst-individual-distance": 45034.26897893069,
                "average-distance": 42828.68810872454,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 12, 8, 15, 19, 26, 20, 23, 21, 29, 22, 18, 28, 24, 25, 27, 16, 14, 17, 13, 7, 9, 3, 4, 5, 2, 1, 6, 10],
                "best-individual-distance": 35999.59207228486,
                "worst-individual-sequence": [20, 21, 29, 22, 18, 28, 24, 25, 27, 14, 16, 19, 23, 26, 17, 15, 12, 7, 3, 9, 4, 8, 10, 11, 2, 1, 6, 5, 13],
                "worst-individual-distance": 44719.36650086052,
                "average-distance": 42680.02717947332,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 12, 8, 15, 19, 26, 20, 23, 21, 29, 22, 18, 28, 24, 25, 27, 16, 14, 17, 13, 7, 9, 3, 4, 5, 2, 1, 6, 10],
                "best-individual-distance": 35999.59207228486,
                "worst-individual-sequence": [26, 28, 29, 20, 21, 23, 22, 18, 15, 19, 14, 12, 8, 7, 3, 9, 4, 6, 1, 5, 2, 13, 11, 10, 17, 27, 24, 25, 16],
                "worst-individual-distance": 44542.76524446244,
                "average-distance": 42541.15179865225,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 12, 8, 15, 19, 26, 20, 23, 21, 29, 22, 18, 28, 24, 25, 27, 16, 14, 17, 13, 7, 9, 3, 4, 5, 2, 1, 6, 10],
                "best-individual-distance": 35999.59207228486,
                "worst-individual-sequence": [17, 15, 19, 20, 22, 18, 21, 3, 4, 1, 2, 11, 5, 6, 10, 12, 7, 8, 13, 14, 16, 25, 27, 24, 9, 29, 23, 28, 26],
                "worst-individual-distance": 44341.54227177949,
                "average-distance": 42406.43410106738,
                "individual-distances": []
            }
        ],
        [
            [{
                "time_cost": 0
            }], {
                "best-individual-sequence": [26, 20, 28, 23, 21, 17, 11, 1, 5, 4, 12, 18, 24, 22, 15, 3, 6, 8, 13, 14, 10, 25, 27, 7, 9, 2, 29, 19, 16],
                "best-individual-distance": 77087.67669516691,
                "worst-individual-sequence": [19, 14, 1, 21, 22, 3, 15, 13, 20, 27, 10, 9, 6, 17, 28, 16, 5, 25, 8, 2, 23, 7, 4, 26, 24, 11, 29, 12, 18],
                "worst-individual-distance": 120370.4487939824,
                "average-distance": 106922.46950963809,
                "individual-distances": []
            }, {
                "best-individual-sequence": [24, 3, 28, 26, 25, 16, 9, 17, 4, 7, 2, 1, 14, 23, 11, 19, 22, 15, 13, 29, 5, 6, 10, 20, 21, 12, 8, 18, 27],
                "best-individual-distance": 74281.33593967829,
                "worst-individual-sequence": [6, 26, 24, 9, 16, 5, 28, 23, 21, 22, 15, 2, 14, 29, 7, 13, 4, 1, 17, 20, 11, 12, 18, 3, 19, 27, 10, 8, 25],
                "worst-individual-distance": 116217.64762439951,
                "average-distance": 104367.9115632665,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 9, 10, 11, 13, 22, 29, 16, 20, 15, 26, 7, 21, 27, 19, 12, 2, 1, 6, 5, 18, 3, 25, 28, 23, 24, 14, 8, 4],
                "best-individual-distance": 71478.39564516972,
                "worst-individual-sequence": [25, 22, 18, 12, 11, 9, 8, 16, 24, 27, 2, 28, 14, 15, 19, 5, 17, 23, 3, 26, 13, 29, 4, 6, 21, 10, 1, 20, 7],
                "worst-individual-distance": 112993.36643756287,
                "average-distance": 102048.18670138711,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 9, 10, 11, 13, 22, 29, 16, 20, 15, 26, 7, 21, 27, 19, 12, 2, 1, 6, 5, 18, 3, 25, 28, 23, 24, 14, 8, 4],
                "best-individual-distance": 71478.39564516972,
                "worst-individual-sequence": [2, 9, 13, 24, 1, 29, 27, 7, 3, 16, 14, 5, 4, 12, 28, 8, 25, 20, 15, 6, 17, 10, 26, 18, 11, 22, 23, 21, 19],
                "worst-individual-distance": 110296.36833807778,
                "average-distance": 99973.78504214637,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 9, 10, 11, 13, 22, 29, 16, 20, 15, 26, 7, 21, 27, 19, 12, 2, 1, 6, 5, 18, 3, 25, 28, 23, 24, 14, 8, 4],
                "best-individual-distance": 71478.39564516972,
                "worst-individual-sequence": [2, 12, 27, 23, 6, 11, 29, 14, 16, 13, 7, 19, 10, 15, 25, 1, 3, 9, 26, 21, 17, 22, 8, 24, 28, 5, 4, 20, 18],
                "worst-individual-distance": 107731.66968116915,
                "average-distance": 97946.18742377961,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 16, 7, 14, 5, 4, 8, 13, 24, 18, 23, 19, 10, 15, 9, 3, 1, 2, 11, 6, 29, 22, 21, 27, 25, 28, 20, 26, 12],
                "best-individual-distance": 70396.21356777832,
                "worst-individual-sequence": [13, 3, 21, 16, 1, 10, 12, 29, 17, 9, 8, 26, 15, 7, 14, 22, 19, 5, 6, 2, 27, 4, 28, 25, 20, 18, 24, 11, 23],
                "worst-individual-distance": 105528.73783705386,
                "average-distance": 96035.88995554812,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 16, 7, 14, 5, 4, 8, 13, 24, 18, 23, 19, 10, 15, 9, 3, 1, 2, 11, 6, 29, 22, 21, 27, 25, 28, 20, 26, 12],
                "best-individual-distance": 70396.21356777832,
                "worst-individual-sequence": [26, 28, 10, 14, 7, 16, 21, 11, 1, 23, 24, 6, 17, 9, 27, 20, 18, 25, 22, 3, 5, 2, 8, 13, 29, 19, 12, 4, 15],
                "worst-individual-distance": 103259.80373908486,
                "average-distance": 94144.7424434322,
                "individual-distances": []
            }, {
                "best-individual-sequence": [8, 22, 20, 15, 26, 23, 21, 27, 25, 16, 14, 19, 12, 2, 1, 6, 5, 3, 7, 4, 24, 28, 13, 11, 9, 29, 17, 18, 10],
                "best-individual-distance": 66407.10073489955,
                "worst-individual-sequence": [27, 3, 8, 4, 13, 11, 20, 1, 7, 2, 14, 28, 15, 18, 24, 12, 22, 6, 9, 23, 29, 21, 5, 10, 25, 19, 17, 16, 26],
                "worst-individual-distance": 101211.90625619749,
                "average-distance": 92414.58665525999,
                "individual-distances": []
            }, {
                "best-individual-sequence": [8, 22, 20, 15, 26, 23, 21, 27, 25, 16, 14, 19, 12, 2, 1, 6, 5, 3, 7, 4, 24, 28, 13, 11, 9, 29, 17, 18, 10],
                "best-individual-distance": 66407.10073489955,
                "worst-individual-sequence": [27, 26, 8, 9, 2, 23, 7, 17, 25, 29, 13, 16, 14, 3, 21, 5, 12, 1, 15, 10, 11, 6, 28, 19, 18, 22, 4, 20, 24],
                "worst-individual-distance": 99565.61343812171,
                "average-distance": 90893.05971567518,
                "individual-distances": []
            }, {
                "best-individual-sequence": [8, 22, 20, 15, 26, 23, 21, 27, 25, 16, 14, 19, 12, 2, 1, 6, 5, 3, 7, 4, 24, 28, 13, 11, 9, 29, 17, 18, 10],
                "best-individual-distance": 66407.10073489955,
                "worst-individual-sequence": [3, 24, 13, 8, 1, 2, 25, 12, 5, 22, 14, 9, 7, 20, 21, 15, 16, 6, 10, 26, 28, 17, 4, 11, 18, 19, 27, 23, 29],
                "worst-individual-distance": 97741.64521888124,
                "average-distance": 89276.25862066365,
                "individual-distances": []
            }, {
                "best-individual-sequence": [6, 5, 3, 10, 9, 13, 14, 25, 27, 17, 21, 29, 15, 12, 23, 26, 20, 24, 16, 18, 19, 22, 8, 4, 2, 1, 7, 28, 11],
                "best-individual-distance": 64406.85276764434,
                "worst-individual-sequence": [29, 10, 2, 17, 26, 13, 7, 18, 20, 12, 22, 28, 14, 11, 1, 5, 24, 23, 21, 27, 3, 4, 19, 9, 6, 8, 15, 25, 16],
                "worst-individual-distance": 95910.27793044514,
                "average-distance": 87957.47005310403,
                "individual-distances": []
            }, {
                "best-individual-sequence": [6, 5, 3, 10, 9, 13, 14, 25, 27, 17, 21, 29, 15, 12, 23, 26, 20, 24, 16, 18, 19, 22, 8, 4, 2, 1, 7, 28, 11],
                "best-individual-distance": 64406.85276764434,
                "worst-individual-sequence": [15, 16, 5, 4, 19, 27, 23, 3, 9, 20, 21, 1, 2, 10, 24, 25, 7, 6, 13, 29, 8, 11, 14, 18, 17, 12, 22, 26, 28],
                "worst-individual-distance": 94298.45150727416,
                "average-distance": 86518.31712285959,
                "individual-distances": []
            }, {
                "best-individual-sequence": [13, 7, 11, 15, 26, 23, 21, 27, 25, 16, 14, 17, 19, 12, 2, 1, 6, 5, 8, 10, 4, 18, 28, 20, 22, 9, 3, 24, 29],
                "best-individual-distance": 63597.16293278802,
                "worst-individual-sequence": [21, 15, 20, 26, 18, 17, 6, 7, 19, 28, 29, 27, 22, 4, 1, 12, 10, 8, 25, 23, 3, 11, 2, 9, 16, 24, 13, 14, 5],
                "worst-individual-distance": 92701.05428560739,
                "average-distance": 85202.04482953437,
                "individual-distances": []
            }, {
                "best-individual-sequence": [13, 7, 11, 15, 26, 23, 21, 27, 25, 16, 14, 17, 19, 12, 2, 1, 6, 5, 8, 10, 4, 18, 28, 20, 22, 9, 3, 24, 29],
                "best-individual-distance": 63597.16293278802,
                "worst-individual-sequence": [22, 12, 18, 26, 24, 27, 20, 16, 13, 8, 7, 4, 23, 10, 21, 14, 2, 3, 15, 28, 17, 5, 1, 6, 19, 11, 25, 9, 29],
                "worst-individual-distance": 90991.2176953862,
                "average-distance": 83876.18223469725,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 9, 1, 2, 11, 12, 6, 3, 7, 8, 5, 4, 10, 28, 15, 25, 13, 18, 17, 21, 26, 27, 14, 20, 24, 16, 19, 29, 22],
                "best-individual-distance": 62589.20999592834,
                "worst-individual-sequence": [19, 25, 23, 8, 24, 16, 14, 5, 4, 21, 15, 20, 26, 18, 17, 6, 2, 1, 12, 27, 10, 11, 22, 28, 9, 3, 29, 13, 7],
                "worst-individual-distance": 89353.4124346447,
                "average-distance": 82684.32770993108,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 13, 6, 2, 12, 11, 24, 25, 27, 26, 17, 22, 15, 16, 20, 28, 10, 8, 7, 4, 14, 18, 19, 29, 23, 21, 9, 3, 1],
                "best-individual-distance": 62136.59521765126,
                "worst-individual-sequence": [20, 25, 26, 23, 19, 11, 21, 4, 1, 10, 7, 3, 12, 8, 28, 24, 14, 22, 17, 13, 29, 5, 16, 15, 18, 2, 6, 9, 27],
                "worst-individual-distance": 88169.69823321173,
                "average-distance": 81490.65092062841,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 13, 6, 2, 12, 11, 24, 25, 27, 26, 17, 22, 15, 16, 20, 28, 10, 8, 7, 4, 14, 18, 19, 29, 23, 21, 9, 3, 1],
                "best-individual-distance": 62136.59521765126,
                "worst-individual-sequence": [9, 7, 21, 13, 12, 3, 11, 14, 6, 1, 8, 16, 18, 23, 20, 25, 28, 27, 26, 10, 29, 17, 19, 22, 15, 5, 2, 4, 24],
                "worst-individual-distance": 87045.07944265334,
                "average-distance": 80399.00479856013,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 13, 6, 2, 12, 11, 24, 25, 27, 26, 17, 22, 15, 16, 20, 28, 10, 8, 7, 4, 14, 18, 19, 29, 23, 21, 9, 3, 1],
                "best-individual-distance": 62136.59521765126,
                "worst-individual-sequence": [13, 4, 1, 5, 2, 20, 10, 11, 19, 21, 12, 29, 22, 24, 8, 7, 3, 26, 15, 28, 18, 23, 6, 17, 25, 27, 16, 9, 14],
                "worst-individual-distance": 85718.41562145665,
                "average-distance": 79355.40260364939,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 13, 6, 2, 12, 11, 24, 25, 27, 26, 17, 22, 15, 16, 20, 28, 10, 8, 7, 4, 14, 18, 19, 29, 23, 21, 9, 3, 1],
                "best-individual-distance": 62136.59521765126,
                "worst-individual-sequence": [24, 25, 13, 22, 2, 4, 17, 5, 1, 10, 12, 14, 28, 9, 23, 21, 15, 20, 26, 27, 18, 11, 19, 7, 8, 6, 3, 16, 29],
                "worst-individual-distance": 84574.40115204843,
                "average-distance": 78313.47252038692,
                "individual-distances": []
            }, {
                "best-individual-sequence": [22, 15, 26, 20, 19, 10, 12, 2, 1, 6, 5, 7, 3, 4, 11, 8, 13, 29, 21, 18, 23, 28, 25, 24, 16, 9, 14, 17, 27],
                "best-individual-distance": 52380.070956314936,
                "worst-individual-sequence": [20, 27, 15, 25, 29, 16, 18, 9, 7, 19, 26, 28, 21, 17, 8, 4, 3, 12, 2, 5, 1, 6, 24, 11, 13, 22, 14, 10, 23],
                "worst-individual-distance": 83310.26520394336,
                "average-distance": 77329.8580872375,
                "individual-distances": []
            }, {
                "best-individual-sequence": [22, 15, 26, 20, 19, 10, 12, 2, 1, 6, 5, 7, 3, 4, 11, 8, 13, 29, 21, 18, 23, 28, 25, 24, 16, 9, 14, 17, 27],
                "best-individual-distance": 52380.070956314936,
                "worst-individual-sequence": [5, 1, 2, 17, 20, 13, 4, 3, 15, 26, 24, 7, 16, 19, 14, 27, 25, 29, 23, 21, 10, 8, 12, 6, 11, 28, 9, 18, 22],
                "worst-individual-distance": 82316.81434258574,
                "average-distance": 76401.84808041043,
                "individual-distances": []
            }, {
                "best-individual-sequence": [22, 15, 26, 20, 19, 10, 12, 2, 1, 6, 5, 7, 3, 4, 11, 8, 13, 29, 21, 18, 23, 28, 25, 24, 16, 9, 14, 17, 27],
                "best-individual-distance": 52380.070956314936,
                "worst-individual-sequence": [16, 29, 23, 19, 25, 13, 5, 1, 4, 14, 15, 2, 8, 28, 11, 6, 22, 27, 20, 18, 17, 26, 21, 10, 12, 9, 7, 3, 24],
                "worst-individual-distance": 81243.75705039555,
                "average-distance": 75473.30840551786,
                "individual-distances": []
            }, {
                "best-individual-sequence": [22, 15, 26, 20, 19, 10, 12, 2, 1, 6, 5, 7, 3, 4, 11, 8, 13, 29, 21, 18, 23, 28, 25, 24, 16, 9, 14, 17, 27],
                "best-individual-distance": 52380.070956314936,
                "worst-individual-sequence": [14, 7, 4, 29, 25, 16, 21, 6, 5, 28, 20, 19, 24, 27, 26, 22, 12, 8, 2, 1, 3, 18, 17, 23, 13, 10, 9, 15, 11],
                "worst-individual-distance": 80133.16459012112,
                "average-distance": 74497.0430874331,
                "individual-distances": []
            }, {
                "best-individual-sequence": [22, 15, 26, 20, 19, 10, 12, 2, 1, 6, 5, 7, 3, 4, 11, 8, 13, 29, 21, 18, 23, 28, 25, 24, 16, 9, 14, 17, 27],
                "best-individual-distance": 52380.070956314936,
                "worst-individual-sequence": [20, 25, 26, 27, 24, 2, 23, 17, 29, 18, 9, 1, 3, 5, 11, 19, 22, 14, 12, 10, 13, 6, 4, 7, 15, 8, 21, 28, 16],
                "worst-individual-distance": 79100.90571680435,
                "average-distance": 73481.36478564465,
                "individual-distances": []
            }, {
                "best-individual-sequence": [22, 15, 26, 20, 19, 10, 12, 2, 1, 6, 5, 7, 3, 4, 11, 8, 13, 29, 21, 18, 23, 28, 25, 24, 16, 9, 14, 17, 27],
                "best-individual-distance": 52380.070956314936,
                "worst-individual-sequence": [29, 20, 23, 7, 9, 14, 13, 19, 15, 26, 24, 11, 3, 27, 25, 6, 2, 5, 1, 8, 10, 4, 17, 18, 16, 12, 22, 28, 21],
                "worst-individual-distance": 78213.91929682675,
                "average-distance": 72622.2139259246,
                "individual-distances": []
            }, {
                "best-individual-sequence": [22, 15, 26, 20, 19, 10, 12, 2, 1, 6, 5, 7, 3, 4, 11, 8, 13, 29, 21, 18, 23, 28, 25, 24, 16, 9, 14, 17, 27],
                "best-individual-distance": 52380.070956314936,
                "worst-individual-sequence": [18, 19, 21, 29, 20, 15, 17, 3, 13, 25, 23, 11, 22, 7, 8, 4, 6, 12, 14, 16, 27, 26, 24, 28, 1, 5, 9, 10, 2],
                "worst-individual-distance": 77187.95355052484,
                "average-distance": 71779.14869007583,
                "individual-distances": []
            }, {
                "best-individual-sequence": [22, 15, 26, 20, 19, 10, 12, 2, 1, 6, 5, 7, 3, 4, 11, 8, 13, 29, 21, 18, 23, 28, 25, 24, 16, 9, 14, 17, 27],
                "best-individual-distance": 52380.070956314936,
                "worst-individual-sequence": [26, 25, 27, 2, 1, 13, 20, 28, 16, 9, 14, 17, 22, 15, 21, 24, 10, 8, 7, 4, 18, 19, 29, 23, 11, 12, 6, 3, 5],
                "worst-individual-distance": 76255.75060650655,
                "average-distance": 70947.14744822629,
                "individual-distances": []
            }, {
                "best-individual-sequence": [22, 15, 26, 20, 19, 10, 12, 2, 1, 6, 5, 7, 3, 4, 11, 8, 13, 29, 21, 18, 23, 28, 25, 24, 16, 9, 14, 17, 27],
                "best-individual-distance": 52380.070956314936,
                "worst-individual-sequence": [2, 1, 6, 11, 15, 12, 23, 26, 18, 19, 9, 22, 14, 17, 10, 13, 8, 4, 27, 28, 25, 24, 16, 20, 29, 5, 7, 21, 3],
                "worst-individual-distance": 75260.73603402465,
                "average-distance": 70108.66813980126,
                "individual-distances": []
            }, {
                "best-individual-sequence": [22, 15, 26, 20, 19, 10, 12, 2, 1, 6, 5, 7, 3, 4, 11, 8, 13, 29, 21, 18, 23, 28, 25, 24, 16, 9, 14, 17, 27],
                "best-individual-distance": 52380.070956314936,
                "worst-individual-sequence": [25, 9, 7, 28, 18, 19, 21, 29, 20, 15, 17, 3, 22, 16, 24, 8, 4, 12, 2, 5, 1, 6, 11, 13, 14, 10, 23, 27, 26],
                "worst-individual-distance": 74454.10297186143,
                "average-distance": 69301.03809339066,
                "individual-distances": []
            }, {
                "best-individual-sequence": [22, 15, 26, 20, 19, 10, 12, 2, 1, 6, 5, 7, 3, 4, 11, 8, 13, 29, 21, 18, 23, 28, 25, 24, 16, 9, 14, 17, 27],
                "best-individual-distance": 52380.070956314936,
                "worst-individual-sequence": [14, 13, 22, 23, 27, 21, 11, 16, 20, 15, 26, 25, 19, 12, 2, 1, 6, 5, 18, 3, 7, 28, 24, 29, 17, 10, 4, 8, 9],
                "worst-individual-distance": 73652.74663698777,
                "average-distance": 68516.27664820381,
                "individual-distances": []
            }, {
                "best-individual-sequence": [22, 15, 26, 20, 19, 10, 12, 2, 1, 6, 5, 7, 3, 4, 11, 8, 13, 29, 21, 18, 23, 28, 25, 24, 16, 9, 14, 17, 27],
                "best-individual-distance": 52380.070956314936,
                "worst-individual-sequence": [21, 14, 3, 16, 20, 24, 19, 5, 6, 12, 10, 2, 1, 25, 28, 29, 26, 22, 23, 18, 9, 15, 13, 11, 7, 8, 4, 17, 27],
                "worst-individual-distance": 72876.58751672435,
                "average-distance": 67794.03483946038,
                "individual-distances": []
            }, {
                "best-individual-sequence": [22, 15, 26, 20, 19, 10, 12, 2, 1, 6, 5, 7, 3, 4, 11, 8, 13, 29, 21, 18, 23, 28, 25, 24, 16, 9, 14, 17, 27],
                "best-individual-distance": 52380.070956314936,
                "worst-individual-sequence": [29, 25, 14, 6, 2, 4, 5, 3, 7, 28, 21, 10, 1, 17, 20, 24, 27, 16, 19, 26, 22, 23, 18, 9, 12, 15, 13, 11, 8],
                "worst-individual-distance": 72116.57843750394,
                "average-distance": 67100.36382950106,
                "individual-distances": []
            }, {
                "best-individual-sequence": [22, 15, 26, 20, 19, 10, 12, 2, 1, 6, 5, 7, 3, 4, 11, 8, 13, 29, 21, 18, 23, 28, 25, 24, 16, 9, 14, 17, 27],
                "best-individual-distance": 52380.070956314936,
                "worst-individual-sequence": [6, 28, 25, 24, 9, 22, 17, 18, 16, 20, 26, 14, 12, 1, 2, 11, 13, 19, 15, 8, 5, 3, 7, 4, 10, 23, 29, 21, 27],
                "worst-individual-distance": 71310.9393147122,
                "average-distance": 66389.95949070936,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 8, 14, 18, 13, 27, 24, 25, 16, 20, 28, 10, 12, 2, 1, 6, 5, 3, 7, 4, 9, 26, 15, 22, 29, 23, 21, 17, 19],
                "best-individual-distance": 52344.8285911596,
                "worst-individual-sequence": [16, 9, 17, 2, 1, 12, 3, 7, 8, 5, 4, 14, 11, 19, 22, 10, 13, 6, 29, 18, 15, 21, 28, 27, 26, 23, 20, 24, 25],
                "worst-individual-distance": 70446.60993095869,
                "average-distance": 65608.73471855294,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 8, 14, 18, 13, 27, 24, 25, 16, 20, 28, 10, 12, 2, 1, 6, 5, 3, 7, 4, 9, 26, 15, 22, 29, 23, 21, 17, 19],
                "best-individual-distance": 52344.8285911596,
                "worst-individual-sequence": [6, 28, 29, 23, 9, 14, 15, 26, 24, 25, 27, 20, 17, 18, 21, 19, 22, 8, 3, 12, 7, 5, 16, 2, 1, 4, 11, 10, 13],
                "worst-individual-distance": 69649.07653633432,
                "average-distance": 64923.656421348445,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 29, 15, 23, 26, 20, 24, 16, 18, 19, 22, 13, 12, 2, 1, 6, 5, 3, 7, 4, 8, 11, 28, 10, 9, 14, 25, 27, 17],
                "best-individual-distance": 51489.705821237636,
                "worst-individual-sequence": [27, 18, 9, 7, 28, 16, 17, 8, 4, 3, 2, 1, 6, 11, 10, 5, 21, 20, 19, 25, 26, 24, 29, 23, 12, 15, 13, 22, 14],
                "worst-individual-distance": 68969.03296523305,
                "average-distance": 64243.31457584249,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 10, 7, 4, 11, 14, 15, 26, 24, 25, 27, 20, 16, 2, 9, 8, 13, 22, 23, 17, 21, 29, 28, 18, 19, 12, 3, 1, 6],
                "best-individual-distance": 51098.14116869689,
                "worst-individual-sequence": [19, 21, 29, 20, 15, 17, 7, 8, 13, 6, 12, 14, 16, 27, 23, 25, 24, 22, 26, 18, 28, 5, 2, 1, 4, 9, 10, 11, 3],
                "worst-individual-distance": 68285.51989123314,
                "average-distance": 63591.93830464537,
                "individual-distances": []
            }, {
                "best-individual-sequence": [19, 12, 2, 1, 6, 5, 3, 4, 10, 11, 8, 15, 29, 16, 25, 24, 27, 26, 18, 14, 13, 9, 7, 20, 28, 21, 22, 17, 23],
                "best-individual-distance": 46000.37259440694,
                "worst-individual-sequence": [7, 5, 3, 10, 9, 13, 14, 18, 22, 25, 23, 21, 28, 12, 16, 27, 24, 26, 2, 8, 4, 6, 1, 11, 15, 29, 19, 20, 17],
                "worst-individual-distance": 67589.84868197562,
                "average-distance": 63025.69916596529,
                "individual-distances": []
            }, {
                "best-individual-sequence": [19, 12, 2, 1, 6, 5, 3, 4, 10, 11, 8, 15, 29, 16, 25, 24, 27, 26, 18, 14, 13, 9, 7, 20, 28, 21, 22, 17, 23],
                "best-individual-distance": 46000.37259440694,
                "worst-individual-sequence": [20, 15, 18, 24, 16, 17, 2, 1, 7, 8, 10, 13, 12, 4, 3, 6, 5, 23, 28, 22, 11, 9, 14, 29, 21, 26, 25, 27, 19],
                "worst-individual-distance": 66980.49827113778,
                "average-distance": 62438.63961112077,
                "individual-distances": []
            }, {
                "best-individual-sequence": [19, 12, 2, 1, 6, 5, 3, 4, 10, 11, 8, 15, 29, 16, 25, 24, 27, 26, 18, 14, 13, 9, 7, 20, 28, 21, 22, 17, 23],
                "best-individual-distance": 46000.37259440694,
                "worst-individual-sequence": [27, 25, 16, 14, 19, 2, 1, 4, 20, 12, 5, 11, 10, 8, 7, 13, 6, 3, 9, 29, 17, 22, 28, 24, 18, 15, 26, 23, 21],
                "worst-individual-distance": 66210.11819664351,
                "average-distance": 61733.715966858865,
                "individual-distances": []
            }, {
                "best-individual-sequence": [19, 12, 2, 1, 6, 5, 3, 4, 10, 11, 8, 15, 29, 16, 25, 24, 27, 26, 18, 14, 13, 9, 7, 20, 28, 21, 22, 17, 23],
                "best-individual-distance": 46000.37259440694,
                "worst-individual-sequence": [5, 7, 13, 23, 17, 8, 4, 3, 2, 1, 6, 11, 29, 14, 15, 28, 27, 20, 24, 25, 16, 9, 18, 19, 10, 26, 22, 21, 12],
                "worst-individual-distance": 65526.29689533198,
                "average-distance": 61151.08489093351,
                "individual-distances": []
            }, {
                "best-individual-sequence": [19, 12, 2, 1, 6, 5, 3, 4, 10, 11, 8, 15, 29, 16, 25, 24, 27, 26, 18, 14, 13, 9, 7, 20, 28, 21, 22, 17, 23],
                "best-individual-distance": 46000.37259440694,
                "worst-individual-sequence": [21, 26, 27, 8, 10, 12, 2, 1, 6, 5, 3, 7, 4, 28, 25, 23, 20, 24, 16, 18, 19, 15, 13, 22, 9, 14, 17, 11, 29],
                "worst-individual-distance": 64915.37847525663,
                "average-distance": 60586.3854522149,
                "individual-distances": []
            }, {
                "best-individual-sequence": [19, 12, 2, 1, 6, 5, 3, 4, 10, 11, 8, 15, 29, 16, 25, 24, 27, 26, 18, 14, 13, 9, 7, 20, 28, 21, 22, 17, 23],
                "best-individual-distance": 46000.37259440694,
                "worst-individual-sequence": [28, 2, 11, 13, 4, 12, 6, 3, 7, 8, 5, 10, 1, 15, 25, 18, 17, 21, 26, 27, 14, 20, 24, 16, 19, 29, 22, 23, 9],
                "worst-individual-distance": 64341.40201281425,
                "average-distance": 60036.819393915575,
                "individual-distances": []
            }, {
                "best-individual-sequence": [27, 14, 18, 19, 29, 23, 12, 25, 1, 6, 5, 11, 10, 8, 3, 7, 4, 9, 13, 2, 28, 21, 22, 15, 17, 20, 26, 16, 24],
                "best-individual-distance": 43771.063134100514,
                "worst-individual-sequence": [28, 19, 12, 11, 1, 6, 13, 3, 8, 5, 4, 10, 2, 7, 14, 18, 24, 29, 23, 21, 9, 25, 27, 26, 17, 22, 15, 16, 20],
                "worst-individual-distance": 63673.91409995394,
                "average-distance": 59466.539619075345,
                "individual-distances": []
            }, {
                "best-individual-sequence": [27, 14, 18, 19, 29, 23, 12, 25, 1, 6, 5, 11, 10, 8, 3, 7, 4, 9, 13, 2, 28, 21, 22, 15, 17, 20, 26, 16, 24],
                "best-individual-distance": 43771.063134100514,
                "worst-individual-sequence": [3, 5, 6, 15, 18, 25, 29, 27, 24, 21, 20, 28, 16, 22, 23, 13, 19, 26, 9, 14, 17, 7, 10, 12, 2, 1, 11, 4, 8],
                "worst-individual-distance": 63171.89108615237,
                "average-distance": 59029.47021489467,
                "individual-distances": []
            }, {
                "best-individual-sequence": [27, 14, 18, 19, 29, 23, 12, 25, 1, 6, 5, 11, 10, 8, 3, 7, 4, 9, 13, 2, 28, 21, 22, 15, 17, 20, 26, 16, 24],
                "best-individual-distance": 43771.063134100514,
                "worst-individual-sequence": [9, 8, 21, 12, 2, 6, 1, 5, 7, 13, 23, 29, 14, 15, 28, 27, 20, 24, 25, 16, 11, 10, 17, 18, 26, 22, 19, 3, 4],
                "worst-individual-distance": 62504.46755998125,
                "average-distance": 58442.94269208725,
                "individual-distances": []
            }, {
                "best-individual-sequence": [27, 14, 18, 19, 29, 23, 12, 25, 1, 6, 5, 11, 10, 8, 3, 7, 4, 9, 13, 2, 28, 21, 22, 15, 17, 20, 26, 16, 24],
                "best-individual-distance": 43771.063134100514,
                "worst-individual-sequence": [28, 14, 16, 25, 24, 15, 20, 27, 19, 8, 10, 13, 12, 2, 1, 6, 5, 3, 7, 11, 17, 22, 21, 18, 23, 4, 9, 26, 29],
                "worst-individual-distance": 61928.17668536493,
                "average-distance": 57960.816810900695,
                "individual-distances": []
            }, {
                "best-individual-sequence": [27, 14, 18, 19, 29, 23, 12, 25, 1, 6, 5, 11, 10, 8, 3, 7, 4, 9, 13, 2, 28, 21, 22, 15, 17, 20, 26, 16, 24],
                "best-individual-distance": 43771.063134100514,
                "worst-individual-sequence": [13, 27, 24, 21, 20, 16, 23, 28, 22, 12, 5, 4, 2, 1, 18, 19, 25, 26, 17, 29, 15, 14, 9, 3, 8, 7, 11, 6, 10],
                "worst-individual-distance": 61420.21579538113,
                "average-distance": 57517.954430348494,
                "individual-distances": []
            }, {
                "best-individual-sequence": [27, 14, 18, 19, 29, 23, 12, 25, 1, 6, 5, 11, 10, 8, 3, 7, 4, 9, 13, 2, 28, 21, 22, 15, 17, 20, 26, 16, 24],
                "best-individual-distance": 43771.063134100514,
                "worst-individual-sequence": [20, 28, 22, 12, 14, 18, 2, 1, 6, 5, 4, 10, 11, 9, 8, 3, 13, 7, 15, 19, 29, 23, 27, 25, 17, 21, 24, 26, 16],
                "worst-individual-distance": 60932.38705490072,
                "average-distance": 57077.34789379997,
                "individual-distances": []
            }, {
                "best-individual-sequence": [27, 14, 18, 19, 29, 23, 12, 25, 1, 6, 5, 11, 10, 8, 3, 7, 4, 9, 13, 2, 28, 21, 22, 15, 17, 20, 26, 16, 24],
                "best-individual-distance": 43771.063134100514,
                "worst-individual-sequence": [15, 10, 14, 26, 23, 21, 27, 25, 16, 19, 12, 2, 1, 6, 5, 9, 3, 7, 4, 28, 13, 11, 8, 20, 24, 17, 29, 22, 18],
                "worst-individual-distance": 60428.60908136353,
                "average-distance": 56642.80712124943,
                "individual-distances": []
            }, {
                "best-individual-sequence": [27, 14, 18, 19, 29, 23, 25, 5, 2, 1, 6, 11, 10, 8, 3, 7, 4, 28, 13, 12, 9, 21, 22, 15, 17, 20, 26, 16, 24],
                "best-individual-distance": 42724.89056099277,
                "worst-individual-sequence": [22, 29, 21, 26, 18, 15, 20, 27, 19, 8, 10, 13, 12, 2, 1, 6, 5, 3, 7, 4, 23, 28, 25, 24, 16, 9, 14, 17, 11],
                "worst-individual-distance": 59965.34815557088,
                "average-distance": 56257.87901538761,
                "individual-distances": []
            }, {
                "best-individual-sequence": [27, 14, 18, 19, 29, 23, 25, 5, 2, 1, 6, 11, 10, 8, 3, 7, 4, 28, 13, 12, 9, 21, 22, 15, 17, 20, 26, 16, 24],
                "best-individual-distance": 42724.89056099277,
                "worst-individual-sequence": [24, 27, 16, 18, 28, 12, 2, 1, 6, 11, 10, 5, 9, 14, 13, 22, 20, 15, 17, 21, 29, 26, 23, 25, 19, 8, 7, 4, 3],
                "worst-individual-distance": 59606.477949803855,
                "average-distance": 55883.92977353882,
                "individual-distances": []
            }, {
                "best-individual-sequence": [27, 14, 18, 19, 29, 23, 25, 5, 2, 1, 6, 11, 10, 8, 3, 7, 4, 28, 13, 12, 9, 21, 22, 15, 17, 20, 26, 16, 24],
                "best-individual-distance": 42724.89056099277,
                "worst-individual-sequence": [15, 27, 26, 20, 24, 16, 28, 22, 12, 2, 1, 6, 11, 10, 5, 9, 14, 18, 19, 29, 23, 13, 25, 21, 17, 8, 4, 3, 7],
                "worst-individual-distance": 59140.648256239474,
                "average-distance": 55491.682182978446,
                "individual-distances": []
            }, {
                "best-individual-sequence": [27, 14, 18, 19, 29, 23, 25, 5, 2, 1, 6, 11, 10, 8, 3, 7, 4, 28, 13, 12, 9, 21, 22, 15, 17, 20, 26, 16, 24],
                "best-individual-distance": 42724.89056099277,
                "worst-individual-sequence": [20, 28, 22, 12, 5, 23, 21, 27, 25, 16, 14, 4, 2, 1, 6, 10, 8, 18, 19, 29, 24, 26, 11, 13, 9, 7, 3, 15, 17],
                "worst-individual-distance": 58687.689534823054,
                "average-distance": 55078.09013069222,
                "individual-distances": []
            }, {
                "best-individual-sequence": [27, 14, 18, 19, 29, 23, 25, 5, 2, 1, 6, 11, 10, 8, 3, 7, 4, 28, 13, 12, 9, 21, 22, 15, 17, 20, 26, 16, 24],
                "best-individual-distance": 42724.89056099277,
                "worst-individual-sequence": [25, 24, 26, 13, 23, 12, 2, 1, 6, 5, 10, 8, 7, 4, 3, 11, 17, 18, 19, 22, 21, 15, 20, 9, 29, 28, 14, 27, 16],
                "worst-individual-distance": 58237.70199420526,
                "average-distance": 54711.52319302474,
                "individual-distances": []
            }, {
                "best-individual-sequence": [27, 14, 18, 19, 29, 23, 25, 5, 2, 1, 6, 11, 10, 8, 3, 7, 4, 28, 13, 12, 9, 21, 22, 15, 17, 20, 26, 16, 24],
                "best-individual-distance": 42724.89056099277,
                "worst-individual-sequence": [8, 12, 5, 4, 2, 1, 6, 11, 3, 19, 22, 15, 14, 10, 13, 7, 9, 28, 27, 26, 23, 20, 24, 25, 16, 21, 17, 29, 18],
                "worst-individual-distance": 57913.10877786925,
                "average-distance": 54400.06155355915,
                "individual-distances": []
            }, {
                "best-individual-sequence": [27, 14, 18, 19, 29, 23, 25, 5, 2, 1, 6, 11, 10, 8, 3, 7, 4, 28, 13, 12, 9, 21, 22, 15, 17, 20, 26, 16, 24],
                "best-individual-distance": 42724.89056099277,
                "worst-individual-sequence": [4, 8, 3, 24, 16, 17, 20, 28, 22, 12, 2, 1, 6, 11, 10, 5, 9, 15, 14, 18, 19, 29, 23, 13, 25, 27, 26, 21, 7],
                "worst-individual-distance": 57423.827894676695,
                "average-distance": 54017.079258604834,
                "individual-distances": []
            }, {
                "best-individual-sequence": [27, 14, 18, 19, 29, 23, 25, 5, 2, 1, 6, 11, 10, 8, 3, 7, 4, 28, 13, 12, 9, 21, 22, 15, 17, 20, 26, 16, 24],
                "best-individual-distance": 42724.89056099277,
                "worst-individual-sequence": [22, 23, 20, 27, 21, 10, 28, 25, 24, 16, 14, 13, 12, 2, 1, 6, 5, 3, 7, 4, 9, 26, 15, 8, 11, 18, 17, 29, 19],
                "worst-individual-distance": 56968.70133908581,
                "average-distance": 53653.92751971776,
                "individual-distances": []
            }, {
                "best-individual-sequence": [27, 14, 18, 19, 29, 23, 25, 5, 2, 1, 6, 11, 10, 8, 3, 7, 4, 28, 13, 12, 9, 21, 22, 15, 17, 20, 26, 16, 24],
                "best-individual-distance": 42724.89056099277,
                "worst-individual-sequence": [19, 29, 18, 27, 22, 20, 26, 15, 8, 13, 12, 2, 1, 6, 5, 3, 7, 4, 9, 28, 25, 24, 16, 23, 11, 10, 14, 21, 17],
                "worst-individual-distance": 56691.44481283221,
                "average-distance": 53308.76650338802,
                "individual-distances": []
            }, {
                "best-individual-sequence": [27, 14, 18, 19, 29, 23, 25, 5, 2, 1, 6, 11, 10, 8, 3, 7, 4, 28, 13, 12, 9, 21, 22, 15, 17, 20, 26, 16, 24],
                "best-individual-distance": 42724.89056099277,
                "worst-individual-sequence": [28, 15, 20, 25, 24, 16, 27, 19, 11, 8, 10, 13, 12, 4, 3, 2, 1, 6, 5, 9, 14, 17, 22, 29, 21, 18, 26, 7, 23],
                "worst-individual-distance": 56349.15994282069,
                "average-distance": 52970.33826505244,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 29, 22, 13, 12, 11, 2, 1, 6, 5, 10, 8, 7, 4, 3, 9, 14, 15, 18, 19, 23, 21, 28, 26, 17, 25, 24, 27, 16],
                "best-individual-distance": 38734.414528987945,
                "worst-individual-sequence": [2, 1, 6, 5, 11, 10, 7, 13, 21, 26, 28, 20, 18, 29, 23, 22, 15, 14, 9, 25, 17, 8, 4, 3, 16, 24, 27, 19, 12],
                "worst-individual-distance": 55986.69315876601,
                "average-distance": 52586.855034690285,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 29, 22, 13, 12, 11, 2, 1, 6, 5, 10, 8, 7, 4, 3, 9, 14, 15, 18, 19, 23, 21, 28, 26, 17, 25, 24, 27, 16],
                "best-individual-distance": 38734.414528987945,
                "worst-individual-sequence": [18, 15, 20, 27, 19, 2, 1, 6, 11, 10, 12, 8, 7, 4, 5, 3, 28, 25, 24, 16, 17, 13, 9, 23, 14, 22, 29, 21, 26],
                "worst-individual-distance": 55597.52909111904,
                "average-distance": 52262.40938320666,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 29, 22, 13, 12, 11, 2, 1, 6, 5, 10, 8, 7, 4, 3, 9, 14, 15, 18, 19, 23, 21, 28, 26, 17, 25, 24, 27, 16],
                "best-individual-distance": 38734.414528987945,
                "worst-individual-sequence": [27, 25, 16, 14, 19, 12, 2, 1, 6, 5, 10, 8, 7, 3, 4, 11, 28, 20, 29, 22, 24, 9, 13, 18, 17, 15, 26, 23, 21],
                "worst-individual-distance": 55279.77992365358,
                "average-distance": 51961.260636456536,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 29, 22, 13, 12, 11, 2, 1, 6, 5, 10, 8, 7, 4, 3, 9, 14, 15, 18, 19, 23, 21, 28, 26, 17, 25, 24, 27, 16],
                "best-individual-distance": 38734.414528987945,
                "worst-individual-sequence": [3, 5, 2, 1, 6, 11, 28, 26, 17, 25, 24, 27, 16, 18, 14, 13, 9, 22, 20, 15, 10, 7, 29, 23, 21, 19, 12, 8, 4],
                "worst-individual-distance": 54933.94563377386,
                "average-distance": 51621.553293585035,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 29, 22, 13, 12, 11, 2, 1, 6, 5, 10, 8, 7, 4, 3, 9, 14, 15, 18, 19, 23, 21, 28, 26, 17, 25, 24, 27, 16],
                "best-individual-distance": 38734.414528987945,
                "worst-individual-sequence": [27, 23, 13, 28, 25, 19, 12, 2, 1, 6, 5, 11, 10, 8, 7, 4, 3, 9, 24, 16, 20, 14, 17, 22, 29, 21, 26, 18, 15],
                "worst-individual-distance": 54464.48358938712,
                "average-distance": 51231.00803412238,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 29, 22, 13, 12, 11, 2, 1, 6, 5, 10, 8, 7, 4, 3, 9, 14, 15, 18, 19, 23, 21, 28, 26, 17, 25, 24, 27, 16],
                "best-individual-distance": 38734.414528987945,
                "worst-individual-sequence": [8, 4, 3, 7, 24, 16, 20, 28, 22, 12, 2, 1, 6, 11, 10, 5, 9, 15, 14, 18, 19, 29, 23, 13, 25, 27, 26, 21, 17],
                "worst-individual-distance": 54105.087148801,
                "average-distance": 50934.71066009928,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 29, 22, 13, 12, 11, 2, 1, 6, 5, 10, 8, 7, 4, 3, 9, 14, 15, 18, 19, 23, 21, 28, 26, 17, 25, 24, 27, 16],
                "best-individual-distance": 38734.414528987945,
                "worst-individual-sequence": [6, 2, 11, 10, 8, 9, 14, 13, 15, 17, 21, 28, 26, 23, 20, 24, 16, 18, 19, 29, 22, 27, 25, 1, 12, 5, 4, 3, 7],
                "worst-individual-distance": 53820.491086748756,
                "average-distance": 50668.80215867038,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 29, 22, 13, 12, 11, 2, 1, 6, 5, 10, 8, 7, 4, 3, 9, 14, 15, 18, 19, 23, 21, 28, 26, 17, 25, 24, 27, 16],
                "best-individual-distance": 38734.414528987945,
                "worst-individual-sequence": [18, 19, 23, 12, 2, 6, 8, 1, 5, 10, 7, 4, 3, 9, 14, 13, 15, 11, 17, 21, 16, 29, 28, 26, 27, 24, 25, 20, 22],
                "worst-individual-distance": 53552.93089547787,
                "average-distance": 50358.6263901244,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 29, 22, 13, 12, 11, 2, 1, 6, 5, 10, 8, 7, 4, 3, 9, 14, 15, 18, 19, 23, 21, 28, 26, 17, 25, 24, 27, 16],
                "best-individual-distance": 38734.414528987945,
                "worst-individual-sequence": [23, 18, 14, 29, 28, 21, 17, 26, 24, 16, 27, 8, 4, 6, 5, 3, 7, 12, 2, 1, 11, 10, 13, 9, 22, 20, 25, 19, 15],
                "worst-individual-distance": 53275.46925876427,
                "average-distance": 50044.62143229592,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 29, 22, 13, 12, 11, 2, 1, 6, 5, 10, 8, 7, 4, 3, 9, 14, 15, 18, 19, 23, 21, 28, 26, 17, 25, 24, 27, 16],
                "best-individual-distance": 38734.414528987945,
                "worst-individual-sequence": [27, 17, 21, 28, 26, 23, 20, 24, 11, 10, 8, 7, 4, 2, 1, 6, 16, 18, 19, 29, 22, 15, 12, 5, 3, 9, 13, 14, 25],
                "worst-individual-distance": 52991.89948176465,
                "average-distance": 49805.14965726319,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 29, 22, 13, 12, 11, 2, 1, 6, 5, 10, 8, 7, 4, 3, 9, 14, 15, 18, 19, 23, 21, 28, 26, 17, 25, 24, 27, 16],
                "best-individual-distance": 38734.414528987945,
                "worst-individual-sequence": [27, 24, 25, 16, 20, 28, 13, 12, 2, 1, 6, 5, 3, 7, 4, 9, 10, 26, 15, 29, 23, 17, 22, 21, 19, 11, 8, 14, 18],
                "worst-individual-distance": 52665.97424983963,
                "average-distance": 49536.189353808084,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 29, 22, 13, 12, 11, 2, 1, 6, 5, 10, 8, 7, 4, 3, 9, 14, 15, 18, 19, 23, 21, 28, 26, 17, 25, 24, 27, 16],
                "best-individual-distance": 38734.414528987945,
                "worst-individual-sequence": [25, 21, 22, 15, 18, 23, 24, 28, 16, 14, 19, 12, 2, 1, 6, 5, 3, 7, 4, 8, 17, 13, 9, 11, 10, 29, 20, 26, 27],
                "worst-individual-distance": 52407.26631170376,
                "average-distance": 49247.54621702439,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 29, 22, 13, 12, 11, 2, 1, 6, 5, 10, 8, 7, 4, 3, 9, 14, 15, 18, 19, 23, 21, 28, 26, 17, 25, 24, 27, 16],
                "best-individual-distance": 38734.414528987945,
                "worst-individual-sequence": [16, 28, 18, 19, 13, 8, 12, 2, 1, 6, 5, 3, 7, 4, 9, 20, 26, 15, 22, 29, 21, 17, 11, 10, 23, 27, 24, 14, 25],
                "worst-individual-distance": 52154.30429259285,
                "average-distance": 49004.30319456286,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 29, 22, 13, 12, 11, 2, 1, 6, 5, 10, 8, 7, 4, 3, 9, 14, 15, 18, 19, 23, 21, 28, 26, 17, 25, 24, 27, 16],
                "best-individual-distance": 38734.414528987945,
                "worst-individual-sequence": [23, 27, 25, 24, 16, 20, 28, 12, 2, 1, 6, 11, 10, 5, 9, 8, 19, 18, 22, 21, 4, 3, 13, 7, 14, 15, 17, 26, 29],
                "worst-individual-distance": 51869.984095513915,
                "average-distance": 48713.07191156948,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 29, 22, 13, 12, 11, 2, 1, 6, 5, 10, 8, 7, 4, 3, 9, 14, 15, 18, 19, 23, 21, 28, 26, 17, 25, 24, 27, 16],
                "best-individual-distance": 38734.414528987945,
                "worst-individual-sequence": [19, 12, 4, 3, 2, 1, 11, 10, 8, 9, 6, 5, 7, 14, 13, 15, 22, 17, 21, 23, 16, 29, 28, 20, 27, 24, 25, 18, 26],
                "worst-individual-distance": 51529.31043038369,
                "average-distance": 48399.540691179485,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 29, 22, 13, 12, 11, 2, 1, 6, 5, 10, 8, 7, 4, 3, 9, 14, 15, 18, 19, 23, 21, 28, 26, 17, 25, 24, 27, 16],
                "best-individual-distance": 38734.414528987945,
                "worst-individual-sequence": [24, 27, 16, 19, 23, 15, 11, 10, 13, 12, 8, 4, 3, 2, 1, 6, 5, 7, 22, 14, 9, 28, 20, 21, 29, 18, 26, 17, 25],
                "worst-individual-distance": 51199.343743208105,
                "average-distance": 48144.440776182906,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 29, 22, 13, 12, 11, 2, 1, 6, 5, 10, 8, 7, 4, 3, 9, 14, 15, 18, 19, 23, 21, 28, 26, 17, 25, 24, 27, 16],
                "best-individual-distance": 38734.414528987945,
                "worst-individual-sequence": [20, 24, 27, 25, 16, 14, 12, 2, 1, 6, 4, 8, 18, 13, 11, 10, 5, 3, 7, 29, 19, 22, 15, 9, 17, 28, 21, 23, 26],
                "worst-individual-distance": 50905.50813768475,
                "average-distance": 47849.56778436968,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 29, 22, 13, 12, 11, 2, 1, 6, 5, 10, 8, 7, 4, 3, 9, 14, 15, 18, 19, 23, 21, 28, 26, 17, 25, 24, 27, 16],
                "best-individual-distance": 38734.414528987945,
                "worst-individual-sequence": [24, 27, 16, 20, 29, 22, 13, 4, 8, 12, 2, 1, 6, 11, 10, 5, 9, 15, 14, 18, 19, 23, 7, 3, 21, 28, 26, 17, 25],
                "worst-individual-distance": 50560.14675562552,
                "average-distance": 47559.712252795216,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 7, 9, 4, 8, 11, 10, 15, 18, 19, 22, 21, 29, 23, 28, 17, 26, 25, 24, 27, 16, 14, 13, 20, 2, 12, 1, 6, 5],
                "best-individual-distance": 38673.366815640955,
                "worst-individual-sequence": [24, 25, 1, 26, 19, 12, 2, 18, 7, 6, 5, 11, 10, 8, 4, 3, 9, 14, 13, 15, 22, 17, 21, 23, 16, 29, 28, 20, 27],
                "worst-individual-distance": 50273.46874141933,
                "average-distance": 47349.1421422029,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 7, 9, 4, 8, 11, 10, 15, 18, 19, 22, 21, 29, 23, 28, 17, 26, 25, 24, 27, 16, 14, 13, 20, 2, 12, 1, 6, 5],
                "best-individual-distance": 38673.366815640955,
                "worst-individual-sequence": [12, 3, 7, 4, 5, 18, 1, 6, 2, 11, 10, 8, 9, 14, 17, 15, 29, 21, 22, 19, 23, 24, 25, 27, 26, 16, 20, 28, 13],
                "worst-individual-distance": 50014.153156148976,
                "average-distance": 47109.6754492274,
                "individual-distances": []
            }, {
                "best-individual-sequence": [25, 26, 16, 14, 12, 5, 2, 1, 6, 11, 10, 8, 4, 3, 9, 7, 13, 15, 18, 19, 22, 17, 28, 21, 23, 29, 20, 27, 24],
                "best-individual-distance": 35762.26872606582,
                "worst-individual-sequence": [24, 26, 18, 19, 2, 12, 11, 1, 6, 5, 10, 8, 7, 4, 3, 9, 14, 13, 15, 22, 17, 21, 23, 16, 29, 28, 20, 27, 25],
                "worst-individual-distance": 49655.66156053678,
                "average-distance": 46823.024417319226,
                "individual-distances": []
            }, {
                "best-individual-sequence": [25, 26, 16, 14, 12, 5, 2, 1, 6, 11, 10, 8, 4, 3, 9, 7, 13, 15, 18, 19, 22, 17, 28, 21, 23, 29, 20, 27, 24],
                "best-individual-distance": 35762.26872606582,
                "worst-individual-sequence": [19, 12, 10, 4, 2, 1, 6, 11, 5, 3, 7, 9, 8, 25, 24, 26, 14, 13, 15, 18, 23, 27, 20, 28, 29, 16, 17, 21, 22],
                "worst-individual-distance": 49364.63364827546,
                "average-distance": 46602.92562041682,
                "individual-distances": []
            }, {
                "best-individual-sequence": [25, 26, 16, 14, 12, 5, 2, 1, 6, 11, 10, 8, 4, 3, 9, 7, 13, 15, 18, 19, 22, 17, 28, 21, 23, 29, 20, 27, 24],
                "best-individual-distance": 35762.26872606582,
                "worst-individual-sequence": [29, 28, 22, 12, 2, 1, 6, 5, 10, 8, 7, 4, 3, 9, 23, 21, 20, 24, 16, 18, 19, 14, 13, 11, 15, 17, 25, 27, 26],
                "worst-individual-distance": 49065.9918948309,
                "average-distance": 46316.27432903837,
                "individual-distances": []
            }, {
                "best-individual-sequence": [25, 26, 16, 14, 12, 5, 2, 1, 6, 11, 10, 8, 4, 3, 9, 7, 13, 15, 18, 19, 22, 17, 28, 21, 23, 29, 20, 27, 24],
                "best-individual-distance": 35762.26872606582,
                "worst-individual-sequence": [20, 24, 27, 25, 16, 14, 12, 2, 1, 6, 5, 3, 7, 4, 8, 17, 13, 11, 10, 18, 19, 22, 15, 9, 29, 28, 21, 23, 26],
                "worst-individual-distance": 48810.92987460525,
                "average-distance": 46079.65590838122,
                "individual-distances": []
            }, {
                "best-individual-sequence": [25, 26, 16, 14, 12, 5, 2, 1, 6, 11, 10, 8, 4, 3, 9, 7, 13, 15, 18, 19, 22, 17, 28, 21, 23, 29, 20, 27, 24],
                "best-individual-distance": 35762.26872606582,
                "worst-individual-sequence": [29, 18, 15, 20, 27, 19, 13, 12, 2, 1, 6, 11, 10, 8, 7, 4, 5, 3, 9, 28, 25, 24, 16, 23, 21, 22, 14, 26, 17],
                "worst-individual-distance": 48489.82220236404,
                "average-distance": 45834.99688845991,
                "individual-distances": []
            }, {
                "best-individual-sequence": [25, 26, 16, 14, 12, 5, 2, 1, 6, 11, 10, 8, 4, 3, 9, 7, 13, 15, 18, 19, 22, 17, 28, 21, 23, 29, 20, 27, 24],
                "best-individual-distance": 35762.26872606582,
                "worst-individual-sequence": [24, 25, 27, 13, 8, 9, 14, 18, 19, 12, 2, 1, 6, 11, 10, 5, 3, 7, 4, 29, 23, 22, 15, 17, 26, 16, 28, 21, 20],
                "worst-individual-distance": 48326.210066437736,
                "average-distance": 45613.015843067245,
                "individual-distances": []
            }, {
                "best-individual-sequence": [25, 26, 16, 14, 12, 5, 2, 1, 6, 11, 10, 8, 4, 3, 9, 7, 13, 15, 18, 19, 22, 17, 28, 21, 23, 29, 20, 27, 24],
                "best-individual-distance": 35762.26872606582,
                "worst-individual-sequence": [19, 29, 23, 25, 28, 5, 10, 11, 2, 1, 6, 8, 3, 7, 4, 9, 13, 12, 21, 22, 15, 17, 20, 27, 24, 16, 14, 26, 18],
                "worst-individual-distance": 47992.807004025475,
                "average-distance": 45406.354872789816,
                "individual-distances": []
            }, {
                "best-individual-sequence": [25, 26, 16, 14, 12, 5, 2, 1, 6, 11, 10, 8, 4, 3, 9, 7, 13, 15, 18, 19, 22, 17, 28, 21, 23, 29, 20, 27, 24],
                "best-individual-distance": 35762.26872606582,
                "worst-individual-sequence": [27, 5, 13, 7, 2, 1, 6, 11, 10, 8, 4, 3, 9, 14, 18, 19, 28, 22, 21, 23, 29, 15, 12, 17, 26, 16, 20, 24, 25],
                "worst-individual-distance": 47712.27277561293,
                "average-distance": 45177.48618411652,
                "individual-distances": []
            }, {
                "best-individual-sequence": [25, 26, 16, 14, 12, 5, 2, 1, 6, 11, 10, 8, 4, 3, 9, 7, 13, 15, 18, 19, 22, 17, 28, 21, 23, 29, 20, 27, 24],
                "best-individual-distance": 35762.26872606582,
                "worst-individual-sequence": [9, 17, 25, 14, 19, 23, 15, 11, 10, 12, 2, 1, 6, 5, 3, 7, 4, 8, 16, 22, 21, 29, 28, 26, 27, 24, 18, 20, 13],
                "worst-individual-distance": 47488.69809241286,
                "average-distance": 44969.71023382879,
                "individual-distances": []
            }, {
                "best-individual-sequence": [25, 26, 16, 14, 12, 5, 2, 1, 6, 11, 10, 8, 4, 3, 9, 7, 13, 15, 18, 19, 22, 17, 28, 21, 23, 29, 20, 27, 24],
                "best-individual-distance": 35762.26872606582,
                "worst-individual-sequence": [20, 22, 18, 19, 23, 12, 17, 1, 6, 5, 10, 8, 7, 4, 3, 9, 14, 13, 15, 11, 2, 21, 16, 29, 28, 26, 27, 24, 25],
                "worst-individual-distance": 47278.89807171386,
                "average-distance": 44726.19143469123,
                "individual-distances": []
            }, {
                "best-individual-sequence": [25, 26, 16, 14, 12, 5, 2, 1, 6, 11, 10, 8, 4, 3, 9, 7, 13, 15, 18, 19, 22, 17, 28, 21, 23, 29, 20, 27, 24],
                "best-individual-distance": 35762.26872606582,
                "worst-individual-sequence": [20, 29, 22, 13, 8, 12, 2, 1, 6, 7, 4, 10, 11, 3, 5, 9, 15, 14, 18, 19, 23, 21, 28, 26, 17, 25, 24, 27, 16],
                "worst-individual-distance": 47056.45420942828,
                "average-distance": 44500.89863554402,
                "individual-distances": []
            }, {
                "best-individual-sequence": [13, 12, 7, 5, 2, 1, 6, 11, 10, 8, 4, 3, 9, 14, 18, 22, 17, 21, 23, 29, 28, 26, 20, 16, 27, 25, 24, 19, 15],
                "best-individual-distance": 35690.49041754107,
                "worst-individual-sequence": [12, 16, 1, 6, 5, 10, 8, 7, 4, 3, 9, 14, 15, 11, 2, 29, 28, 26, 27, 24, 25, 20, 22, 18, 19, 23, 17, 21, 13],
                "worst-individual-distance": 46777.81849399758,
                "average-distance": 44252.18978678325,
                "individual-distances": []
            }, {
                "best-individual-sequence": [13, 12, 7, 5, 2, 1, 6, 11, 10, 8, 4, 3, 9, 14, 18, 22, 17, 21, 23, 29, 28, 26, 20, 16, 27, 25, 24, 19, 15],
                "best-individual-distance": 35690.49041754107,
                "worst-individual-sequence": [21, 13, 9, 19, 29, 23, 12, 5, 2, 1, 6, 11, 10, 8, 7, 4, 3, 14, 18, 22, 15, 28, 17, 26, 20, 16, 27, 25, 24],
                "worst-individual-distance": 46511.88243102221,
                "average-distance": 44012.37825313729,
                "individual-distances": []
            }, {
                "best-individual-sequence": [13, 12, 7, 5, 2, 1, 6, 11, 10, 8, 4, 3, 9, 14, 18, 22, 17, 21, 23, 29, 28, 26, 20, 16, 27, 25, 24, 19, 15],
                "best-individual-distance": 35690.49041754107,
                "worst-individual-sequence": [27, 25, 16, 12, 2, 1, 6, 5, 8, 7, 11, 10, 29, 4, 3, 9, 14, 13, 15, 18, 19, 22, 17, 28, 21, 23, 26, 20, 24],
                "worst-individual-distance": 46195.09419970622,
                "average-distance": 43725.88960865948,
                "individual-distances": []
            }, {
                "best-individual-sequence": [13, 12, 7, 5, 2, 1, 6, 11, 10, 8, 4, 3, 9, 14, 18, 22, 17, 21, 23, 29, 28, 26, 20, 16, 27, 25, 24, 19, 15],
                "best-individual-distance": 35690.49041754107,
                "worst-individual-sequence": [22, 19, 12, 2, 1, 6, 5, 10, 8, 7, 4, 3, 9, 14, 13, 15, 11, 18, 23, 28, 25, 24, 27, 26, 20, 29, 16, 17, 21],
                "worst-individual-distance": 46009.535945274154,
                "average-distance": 43501.533538678945,
                "individual-distances": []
            }, {
                "best-individual-sequence": [13, 12, 7, 5, 2, 1, 6, 11, 10, 8, 4, 3, 9, 14, 18, 22, 17, 21, 23, 29, 28, 26, 20, 16, 27, 25, 24, 19, 15],
                "best-individual-distance": 35690.49041754107,
                "worst-individual-sequence": [6, 5, 7, 4, 3, 9, 14, 13, 10, 11, 8, 15, 29, 16, 21, 22, 19, 23, 24, 25, 27, 26, 20, 28, 18, 17, 12, 2, 1],
                "worst-individual-distance": 45770.956019748424,
                "average-distance": 43300.78740833513,
                "individual-distances": []
            }, {
                "best-individual-sequence": [16, 14, 12, 11, 10, 2, 1, 6, 5, 8, 4, 3, 9, 7, 13, 15, 22, 17, 18, 19, 28, 21, 23, 29, 20, 27, 24, 25, 26],
                "best-individual-distance": 35094.31758065323,
                "worst-individual-sequence": [4, 7, 24, 25, 27, 16, 2, 1, 6, 11, 10, 8, 3, 9, 14, 18, 19, 29, 23, 21, 22, 15, 17, 28, 26, 20, 13, 12, 5],
                "worst-individual-distance": 45583.60012136034,
                "average-distance": 43089.5270702157,
                "individual-distances": []
            }, {
                "best-individual-sequence": [16, 14, 12, 11, 10, 2, 1, 6, 5, 8, 4, 3, 9, 7, 13, 15, 22, 17, 18, 19, 28, 21, 23, 29, 20, 27, 24, 25, 26],
                "best-individual-distance": 35094.31758065323,
                "worst-individual-sequence": [13, 21, 16, 18, 29, 19, 12, 2, 1, 6, 5, 11, 10, 8, 4, 3, 9, 7, 17, 23, 22, 15, 28, 26, 27, 24, 25, 20, 14],
                "worst-individual-distance": 45398.72081930248,
                "average-distance": 42786.56346404038,
                "individual-distances": []
            }, {
                "best-individual-sequence": [16, 14, 12, 11, 10, 2, 1, 6, 5, 8, 4, 3, 9, 7, 13, 15, 22, 17, 18, 19, 28, 21, 23, 29, 20, 27, 24, 25, 26],
                "best-individual-distance": 35094.31758065323,
                "worst-individual-sequence": [13, 14, 19, 15, 12, 16, 1, 6, 5, 11, 10, 8, 7, 4, 3, 9, 2, 28, 18, 17, 21, 20, 22, 25, 24, 27, 26, 23, 29],
                "worst-individual-distance": 45245.97909889069,
                "average-distance": 42567.493977692284,
                "individual-distances": []
            }, {
                "best-individual-sequence": [16, 14, 12, 11, 10, 2, 1, 6, 5, 8, 4, 3, 9, 7, 13, 15, 22, 17, 18, 19, 28, 21, 23, 29, 20, 27, 24, 25, 26],
                "best-individual-distance": 35094.31758065323,
                "worst-individual-sequence": [18, 19, 12, 2, 1, 6, 5, 11, 10, 8, 3, 7, 4, 9, 13, 21, 23, 22, 26, 17, 20, 24, 28, 27, 25, 16, 29, 14, 15],
                "worst-individual-distance": 44984.01783956182,
                "average-distance": 42342.37829018494,
                "individual-distances": []
            }
        ],
        [
            [{
                "time_cost": 0
            }], {
                "best-individual-sequence": [8, 21, 18, 15, 20, 14, 17, 10, 11, 19, 28, 26, 12, 3, 4, 23, 29, 22, 27, 1, 2, 6, 9, 25, 24, 16, 7, 13, 5],
                "best-individual-distance": 71363.15216004537,
                "worst-individual-sequence": [8, 24, 22, 14, 21, 25, 19, 5, 27, 18, 26, 4, 20, 23, 17, 12, 6, 7, 2, 29, 9, 16, 11, 13, 10, 3, 28, 1, 15],
                "worst-individual-distance": 120844.13560190191,
                "average-distance": 106753.53105487277,
                "individual-distances": []
            }, {
                "best-individual-sequence": [8, 21, 18, 15, 20, 14, 17, 10, 11, 19, 28, 26, 12, 3, 4, 23, 29, 22, 27, 1, 2, 6, 9, 25, 24, 16, 7, 13, 5],
                "best-individual-distance": 71363.15216004537,
                "worst-individual-sequence": [19, 6, 8, 13, 22, 3, 27, 18, 14, 24, 15, 11, 26, 1, 25, 23, 21, 17, 16, 7, 9, 5, 29, 12, 10, 4, 28, 2, 20],
                "worst-individual-distance": 116036.51392473189,
                "average-distance": 103942.1248455558,
                "individual-distances": []
            }, {
                "best-individual-sequence": [8, 21, 18, 15, 20, 14, 17, 10, 11, 19, 28, 26, 12, 3, 4, 23, 29, 22, 27, 1, 2, 6, 9, 25, 24, 16, 7, 13, 5],
                "best-individual-distance": 71363.15216004537,
                "worst-individual-sequence": [22, 23, 7, 10, 18, 13, 15, 24, 29, 8, 28, 25, 20, 5, 16, 11, 19, 12, 21, 2, 1, 14, 27, 26, 3, 17, 6, 9, 4],
                "worst-individual-distance": 112636.59067466746,
                "average-distance": 101620.39698900016,
                "individual-distances": []
            }, {
                "best-individual-sequence": [7, 3, 4, 1, 17, 8, 6, 5, 2, 22, 28, 15, 14, 21, 23, 26, 25, 16, 27, 24, 13, 29, 18, 9, 20, 19, 10, 12, 11],
                "best-individual-distance": 67051.23597320597,
                "worst-individual-sequence": [10, 24, 25, 29, 16, 19, 3, 28, 9, 14, 12, 13, 8, 4, 15, 11, 21, 27, 23, 6, 20, 17, 5, 1, 18, 7, 22, 26, 2],
                "worst-individual-distance": 109835.95941618702,
                "average-distance": 99365.99975124781,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 29, 22, 21, 25, 14, 11, 26, 23, 28, 27, 17, 7, 8, 4, 2, 1, 6, 5, 9, 16, 24, 20, 3, 18, 19, 15, 13, 12],
                "best-individual-distance": 65957.07409321635,
                "worst-individual-sequence": [28, 27, 24, 12, 9, 6, 22, 3, 15, 4, 23, 7, 8, 29, 25, 16, 14, 11, 1, 26, 13, 17, 10, 2, 5, 18, 21, 20, 19],
                "worst-individual-distance": 107027.37344149669,
                "average-distance": 97201.93581274788,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 29, 22, 21, 25, 14, 11, 26, 23, 28, 27, 17, 7, 8, 4, 2, 1, 6, 5, 9, 16, 24, 20, 3, 18, 19, 15, 13, 12],
                "best-individual-distance": 65957.07409321635,
                "worst-individual-sequence": [6, 2, 28, 11, 10, 14, 13, 15, 27, 12, 3, 7, 8, 4, 18, 1, 24, 21, 9, 25, 29, 19, 20, 17, 23, 16, 22, 5, 26],
                "worst-individual-distance": 104778.04225569565,
                "average-distance": 95353.98010092296,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 29, 22, 21, 25, 14, 11, 26, 23, 28, 27, 17, 7, 8, 4, 2, 1, 6, 5, 9, 16, 24, 20, 3, 18, 19, 15, 13, 12],
                "best-individual-distance": 65957.07409321635,
                "worst-individual-sequence": [13, 19, 17, 29, 2, 22, 14, 3, 18, 24, 27, 16, 25, 5, 9, 20, 26, 21, 11, 12, 4, 15, 1, 7, 10, 8, 28, 6, 23],
                "worst-individual-distance": 102614.69280497759,
                "average-distance": 93416.61908232213,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 29, 22, 21, 25, 14, 11, 26, 23, 28, 27, 17, 7, 8, 4, 2, 1, 6, 5, 9, 16, 24, 20, 3, 18, 19, 15, 13, 12],
                "best-individual-distance": 65957.07409321635,
                "worst-individual-sequence": [27, 22, 23, 16, 28, 18, 20, 8, 11, 19, 21, 10, 15, 3, 14, 26, 29, 13, 2, 1, 24, 12, 17, 4, 6, 9, 25, 7, 5],
                "worst-individual-distance": 100594.60357517144,
                "average-distance": 91595.75843365812,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 29, 22, 21, 25, 14, 11, 26, 23, 28, 27, 17, 7, 8, 4, 2, 1, 6, 5, 9, 16, 24, 20, 3, 18, 19, 15, 13, 12],
                "best-individual-distance": 65957.07409321635,
                "worst-individual-sequence": [5, 6, 20, 15, 8, 11, 26, 22, 29, 7, 13, 18, 25, 16, 9, 23, 21, 10, 2, 24, 27, 1, 12, 17, 19, 28, 3, 14, 4],
                "worst-individual-distance": 98594.77811579638,
                "average-distance": 89982.44734224415,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 29, 22, 21, 25, 14, 11, 26, 23, 28, 27, 17, 7, 8, 4, 2, 1, 6, 5, 9, 16, 24, 20, 3, 18, 19, 15, 13, 12],
                "best-individual-distance": 65957.07409321635,
                "worst-individual-sequence": [21, 16, 1, 11, 29, 19, 17, 12, 25, 20, 14, 23, 5, 3, 15, 2, 8, 24, 26, 22, 13, 7, 4, 27, 9, 6, 10, 18, 28],
                "worst-individual-distance": 96746.35252346803,
                "average-distance": 88389.08636880653,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 29, 22, 21, 25, 14, 11, 26, 23, 28, 27, 17, 7, 8, 4, 2, 1, 6, 5, 9, 16, 24, 20, 3, 18, 19, 15, 13, 12],
                "best-individual-distance": 65957.07409321635,
                "worst-individual-sequence": [16, 26, 23, 25, 9, 29, 17, 11, 4, 10, 22, 18, 28, 20, 7, 13, 5, 14, 1, 24, 27, 21, 15, 12, 3, 8, 19, 2, 6],
                "worst-individual-distance": 94918.6908578447,
                "average-distance": 86937.71747633159,
                "individual-distances": []
            }, {
                "best-individual-sequence": [16, 29, 18, 26, 6, 28, 21, 1, 2, 5, 27, 8, 12, 15, 17, 22, 19, 20, 25, 24, 23, 13, 9, 4, 3, 14, 11, 10, 7],
                "best-individual-distance": 63857.07932337919,
                "worst-individual-sequence": [7, 6, 25, 18, 15, 26, 24, 29, 23, 27, 22, 5, 8, 20, 14, 11, 28, 21, 9, 10, 2, 13, 4, 3, 1, 12, 16, 17, 19],
                "worst-individual-distance": 93425.6188123601,
                "average-distance": 85730.62637314925,
                "individual-distances": []
            }, {
                "best-individual-sequence": [16, 29, 18, 26, 6, 28, 21, 1, 2, 5, 27, 8, 12, 15, 17, 22, 19, 20, 25, 24, 23, 13, 9, 4, 3, 14, 11, 10, 7],
                "best-individual-distance": 63857.07932337919,
                "worst-individual-sequence": [24, 17, 18, 20, 12, 26, 3, 21, 29, 19, 5, 11, 14, 7, 6, 2, 27, 4, 1, 8, 9, 10, 22, 23, 25, 28, 15, 13, 16],
                "worst-individual-distance": 91825.4656510116,
                "average-distance": 84315.3841097285,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 29, 22, 21, 25, 14, 11, 26, 23, 28, 27, 17, 7, 8, 4, 2, 1, 6, 5, 9, 16, 24, 20, 3, 18, 19, 15, 13, 12],
                "best-individual-distance": 60317.035107161326,
                "worst-individual-sequence": [24, 7, 4, 3, 17, 18, 13, 26, 21, 10, 5, 27, 14, 20, 28, 25, 23, 12, 6, 1, 11, 2, 15, 19, 8, 16, 29, 9, 22],
                "worst-individual-distance": 90225.27135656613,
                "average-distance": 83132.5295640333,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 29, 22, 21, 25, 14, 11, 26, 23, 28, 27, 17, 7, 8, 4, 2, 1, 6, 5, 9, 16, 24, 20, 3, 18, 19, 15, 13, 12],
                "best-individual-distance": 60317.035107161326,
                "worst-individual-sequence": [29, 8, 9, 5, 6, 2, 3, 4, 1, 17, 18, 20, 19, 12, 26, 7, 14, 27, 23, 22, 16, 25, 10, 21, 28, 15, 24, 11, 13],
                "worst-individual-distance": 88880.30396093843,
                "average-distance": 81779.57935715915,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 29, 22, 21, 25, 14, 11, 26, 23, 28, 27, 17, 7, 8, 4, 2, 1, 6, 5, 9, 16, 24, 20, 3, 18, 19, 15, 13, 12],
                "best-individual-distance": 60317.035107161326,
                "worst-individual-sequence": [23, 7, 5, 15, 6, 11, 22, 17, 12, 18, 19, 14, 4, 3, 13, 2, 1, 29, 25, 28, 24, 26, 20, 21, 8, 27, 16, 9, 10],
                "worst-individual-distance": 87602.18983640305,
                "average-distance": 80661.24080640943,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 29, 22, 21, 25, 14, 11, 26, 23, 28, 27, 17, 7, 8, 4, 2, 1, 6, 5, 9, 16, 24, 20, 3, 18, 19, 15, 13, 12],
                "best-individual-distance": 60317.035107161326,
                "worst-individual-sequence": [25, 14, 20, 16, 9, 3, 4, 1, 11, 18, 5, 8, 10, 23, 17, 13, 2, 12, 6, 27, 7, 15, 24, 22, 21, 28, 29, 26, 19],
                "worst-individual-distance": 86355.72653318045,
                "average-distance": 79517.85514073638,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 29, 22, 21, 25, 14, 11, 26, 23, 28, 27, 17, 7, 8, 4, 2, 1, 6, 5, 9, 16, 24, 20, 3, 18, 19, 15, 13, 12],
                "best-individual-distance": 60317.035107161326,
                "worst-individual-sequence": [1, 6, 12, 9, 18, 11, 3, 8, 28, 26, 17, 21, 25, 24, 19, 27, 29, 5, 20, 14, 13, 7, 2, 4, 23, 15, 16, 22, 10],
                "worst-individual-distance": 84973.505974466,
                "average-distance": 78373.01398431536,
                "individual-distances": []
            }, {
                "best-individual-sequence": [18, 13, 12, 17, 20, 29, 28, 19, 10, 21, 23, 26, 25, 16, 27, 24, 22, 15, 14, 4, 3, 5, 6, 1, 7, 9, 8, 2, 11],
                "best-individual-distance": 58639.69381004628,
                "worst-individual-sequence": [17, 23, 22, 19, 14, 16, 6, 8, 1, 27, 13, 25, 24, 20, 9, 3, 7, 2, 11, 28, 21, 10, 12, 29, 26, 15, 5, 4, 18],
                "worst-individual-distance": 83739.4201743251,
                "average-distance": 77237.09007316566,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 17, 13, 6, 5, 2, 1, 28, 8, 23, 26, 15, 18, 22, 29, 10, 14, 16, 27, 25, 20, 24, 21, 3, 7, 4, 11, 19, 12],
                "best-individual-distance": 58271.15189603939,
                "worst-individual-sequence": [26, 25, 23, 5, 10, 11, 22, 7, 13, 29, 17, 12, 19, 14, 4, 3, 9, 1, 2, 8, 21, 18, 28, 6, 20, 15, 27, 16, 24],
                "worst-individual-distance": 82676.8185247898,
                "average-distance": 76303.16269743064,
                "individual-distances": []
            }, {
                "best-individual-sequence": [28, 18, 14, 23, 26, 25, 27, 24, 13, 10, 11, 1, 17, 21, 29, 16, 19, 20, 2, 6, 7, 3, 8, 4, 5, 12, 9, 15, 22],
                "best-individual-distance": 56114.616582619245,
                "worst-individual-sequence": [16, 24, 4, 3, 17, 12, 7, 5, 2, 1, 10, 29, 20, 27, 8, 13, 9, 21, 19, 28, 22, 11, 6, 18, 26, 14, 23, 25, 15],
                "worst-individual-distance": 81426.28613993256,
                "average-distance": 75219.81101947054,
                "individual-distances": []
            }, {
                "best-individual-sequence": [28, 18, 14, 23, 26, 25, 27, 24, 13, 10, 11, 1, 17, 21, 29, 16, 19, 20, 2, 6, 7, 3, 8, 4, 5, 12, 9, 15, 22],
                "best-individual-distance": 56114.616582619245,
                "worst-individual-sequence": [26, 16, 12, 3, 29, 22, 23, 21, 9, 4, 15, 10, 8, 7, 28, 19, 11, 1, 18, 27, 24, 20, 14, 13, 6, 2, 5, 25, 17],
                "worst-individual-distance": 80366.47451043855,
                "average-distance": 74414.94365421262,
                "individual-distances": []
            }, {
                "best-individual-sequence": [28, 18, 14, 23, 26, 25, 27, 24, 13, 10, 11, 1, 17, 21, 29, 16, 19, 20, 2, 6, 7, 3, 8, 4, 5, 12, 9, 15, 22],
                "best-individual-distance": 56114.616582619245,
                "worst-individual-sequence": [24, 23, 25, 14, 28, 7, 19, 27, 16, 17, 22, 21, 26, 20, 18, 4, 6, 8, 9, 11, 5, 10, 13, 2, 3, 1, 12, 15, 29],
                "worst-individual-distance": 79259.76424412921,
                "average-distance": 73551.12432660803,
                "individual-distances": []
            }, {
                "best-individual-sequence": [28, 18, 14, 23, 26, 25, 27, 24, 13, 10, 11, 1, 17, 21, 29, 16, 19, 20, 2, 6, 7, 3, 8, 4, 5, 12, 9, 15, 22],
                "best-individual-distance": 56114.616582619245,
                "worst-individual-sequence": [9, 22, 23, 15, 14, 25, 28, 18, 7, 8, 5, 19, 17, 21, 29, 12, 10, 3, 4, 1, 6, 13, 16, 11, 2, 27, 26, 24, 20],
                "worst-individual-distance": 78237.18238743901,
                "average-distance": 72716.56293866303,
                "individual-distances": []
            }, {
                "best-individual-sequence": [28, 18, 14, 23, 26, 25, 27, 24, 13, 10, 11, 1, 17, 21, 29, 16, 19, 20, 2, 6, 7, 3, 8, 4, 5, 12, 9, 15, 22],
                "best-individual-distance": 56114.616582619245,
                "worst-individual-sequence": [8, 22, 23, 16, 28, 18, 15, 6, 11, 13, 29, 7, 26, 5, 10, 25, 20, 24, 27, 19, 21, 17, 14, 9, 4, 3, 12, 1, 2],
                "worst-individual-distance": 77325.48982157579,
                "average-distance": 71954.9021180782,
                "individual-distances": []
            }, {
                "best-individual-sequence": [14, 15, 11, 10, 22, 12, 7, 3, 18, 28, 21, 23, 26, 25, 16, 27, 24, 29, 20, 19, 17, 9, 4, 6, 1, 2, 8, 5, 13],
                "best-individual-distance": 53844.26133659914,
                "worst-individual-sequence": [24, 19, 27, 22, 23, 9, 15, 26, 18, 20, 29, 6, 8, 4, 7, 16, 21, 14, 10, 12, 11, 1, 2, 5, 3, 28, 17, 13, 25],
                "worst-individual-distance": 76336.01461959214,
                "average-distance": 71202.82063288245,
                "individual-distances": []
            }, {
                "best-individual-sequence": [14, 15, 11, 10, 22, 12, 7, 3, 18, 28, 21, 23, 26, 25, 16, 27, 24, 29, 20, 19, 17, 9, 4, 6, 1, 2, 8, 5, 13],
                "best-individual-distance": 53844.26133659914,
                "worst-individual-sequence": [8, 7, 21, 14, 25, 23, 29, 13, 4, 6, 3, 12, 2, 10, 20, 17, 18, 28, 26, 16, 24, 27, 22, 19, 9, 15, 11, 1, 5],
                "worst-individual-distance": 75596.52846069887,
                "average-distance": 70527.02109614182,
                "individual-distances": []
            }, {
                "best-individual-sequence": [14, 15, 11, 10, 22, 12, 7, 3, 18, 28, 21, 23, 26, 25, 16, 27, 24, 29, 20, 19, 17, 9, 4, 6, 1, 2, 8, 5, 13],
                "best-individual-distance": 53844.26133659914,
                "worst-individual-sequence": [3, 1, 2, 5, 6, 22, 21, 24, 16, 19, 10, 8, 12, 15, 17, 20, 25, 23, 13, 9, 28, 14, 11, 7, 29, 18, 26, 27, 4],
                "worst-individual-distance": 74654.77755002839,
                "average-distance": 69785.12161375883,
                "individual-distances": []
            }, {
                "best-individual-sequence": [14, 15, 11, 10, 22, 12, 7, 3, 18, 28, 21, 23, 26, 25, 16, 27, 24, 29, 20, 19, 17, 9, 4, 6, 1, 2, 8, 5, 13],
                "best-individual-distance": 53844.26133659914,
                "worst-individual-sequence": [24, 13, 17, 28, 22, 29, 15, 12, 8, 19, 20, 21, 11, 10, 23, 16, 27, 14, 4, 3, 5, 26, 7, 6, 1, 2, 9, 18, 25],
                "worst-individual-distance": 74012.68784115028,
                "average-distance": 69139.6555132312,
                "individual-distances": []
            }, {
                "best-individual-sequence": [14, 15, 11, 10, 22, 12, 7, 3, 18, 28, 21, 23, 26, 25, 16, 27, 24, 29, 20, 19, 17, 9, 4, 6, 1, 2, 8, 5, 13],
                "best-individual-distance": 53844.26133659914,
                "worst-individual-sequence": [11, 23, 18, 19, 17, 15, 8, 3, 12, 9, 26, 4, 2, 1, 10, 29, 16, 25, 20, 24, 28, 27, 14, 13, 7, 21, 22, 5, 6],
                "worst-individual-distance": 73202.58064162667,
                "average-distance": 68504.75040571776,
                "individual-distances": []
            }, {
                "best-individual-sequence": [15, 29, 25, 20, 10, 18, 28, 26, 16, 24, 27, 17, 21, 8, 4, 2, 1, 6, 5, 22, 13, 9, 12, 14, 3, 11, 7, 23, 19],
                "best-individual-distance": 53442.67197867254,
                "worst-individual-sequence": [29, 19, 12, 25, 20, 14, 13, 7, 8, 21, 17, 18, 28, 26, 16, 3, 4, 1, 23, 22, 24, 27, 9, 15, 11, 2, 6, 5, 10],
                "worst-individual-distance": 72470.16975277936,
                "average-distance": 67752.23149261683,
                "individual-distances": []
            }, {
                "best-individual-sequence": [15, 29, 25, 20, 10, 18, 28, 26, 16, 24, 27, 17, 21, 8, 4, 2, 1, 6, 5, 22, 13, 9, 12, 14, 3, 11, 7, 23, 19],
                "best-individual-distance": 53442.67197867254,
                "worst-individual-sequence": [27, 25, 14, 26, 19, 22, 21, 23, 17, 7, 8, 4, 2, 11, 1, 6, 5, 24, 13, 9, 12, 20, 28, 16, 15, 18, 10, 3, 29],
                "worst-individual-distance": 71840.76033628176,
                "average-distance": 67122.06551468215,
                "individual-distances": []
            }, {
                "best-individual-sequence": [15, 29, 25, 20, 10, 18, 28, 26, 16, 24, 27, 17, 21, 8, 4, 2, 1, 6, 5, 22, 13, 9, 12, 14, 3, 11, 7, 23, 19],
                "best-individual-distance": 53442.67197867254,
                "worst-individual-sequence": [27, 18, 23, 28, 22, 29, 15, 12, 8, 19, 20, 21, 25, 10, 2, 6, 11, 24, 26, 17, 13, 3, 14, 4, 5, 1, 7, 9, 16],
                "worst-individual-distance": 71114.76730162017,
                "average-distance": 66492.77102940861,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 24, 16, 27, 25, 17, 29, 15, 22, 28, 2, 1, 6, 5, 10, 13, 9, 3, 8, 11, 7, 4, 14, 12, 19, 26, 18, 21, 23],
                "best-individual-distance": 51997.563176639815,
                "worst-individual-sequence": [18, 15, 24, 26, 25, 19, 21, 16, 22, 29, 23, 17, 7, 8, 4, 2, 1, 6, 5, 9, 12, 28, 27, 14, 13, 11, 3, 10, 20],
                "worst-individual-distance": 70437.1846274486,
                "average-distance": 65756.75766385952,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 24, 16, 27, 25, 17, 29, 15, 22, 28, 2, 1, 6, 5, 10, 13, 9, 3, 8, 11, 7, 4, 14, 12, 19, 26, 18, 21, 23],
                "best-individual-distance": 51997.563176639815,
                "worst-individual-sequence": [25, 24, 16, 21, 13, 14, 10, 3, 7, 26, 28, 17, 23, 20, 27, 22, 29, 11, 1, 8, 19, 6, 2, 4, 5, 12, 9, 15, 18],
                "worst-individual-distance": 69802.20076916313,
                "average-distance": 65110.98086321429,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 8, 4, 5, 2, 11, 9, 3, 7, 13, 28, 18, 22, 29, 14, 16, 27, 25, 20, 24, 21, 23, 26, 19, 17, 15, 1, 6, 10],
                "best-individual-distance": 51198.65485313646,
                "worst-individual-sequence": [6, 15, 11, 1, 2, 8, 10, 4, 5, 12, 9, 18, 21, 14, 28, 25, 16, 27, 24, 13, 29, 23, 20, 26, 22, 3, 19, 17, 7],
                "worst-individual-distance": 69102.28398277848,
                "average-distance": 64459.55984572061,
                "individual-distances": []
            }, {
                "best-individual-sequence": [22, 2, 15, 12, 14, 26, 25, 27, 24, 28, 23, 20, 17, 21, 29, 16, 19, 1, 18, 13, 9, 10, 11, 7, 3, 4, 8, 6, 5],
                "best-individual-distance": 49364.293959275856,
                "worst-individual-sequence": [6, 5, 10, 29, 19, 12, 25, 20, 14, 13, 7, 23, 8, 4, 21, 17, 18, 28, 26, 16, 24, 27, 22, 3, 9, 15, 11, 1, 2],
                "worst-individual-distance": 68446.04808921723,
                "average-distance": 63872.96420368914,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 14, 24, 17, 21, 23, 26, 15, 18, 22, 29, 28, 16, 27, 25, 20, 19, 13, 9, 12, 11, 7, 3, 4, 8, 6, 5, 1, 2],
                "best-individual-distance": 47909.48575475627,
                "worst-individual-sequence": [5, 12, 15, 18, 21, 23, 13, 9, 29, 22, 19, 11, 17, 7, 2, 1, 8, 10, 26, 16, 25, 20, 24, 28, 27, 14, 3, 6, 4],
                "worst-individual-distance": 67804.13474846177,
                "average-distance": 63305.98619600063,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 14, 24, 17, 21, 23, 26, 15, 18, 22, 29, 28, 16, 27, 25, 20, 19, 13, 9, 12, 11, 7, 3, 4, 8, 6, 5, 1, 2],
                "best-individual-distance": 47909.48575475627,
                "worst-individual-sequence": [28, 17, 8, 6, 5, 2, 1, 25, 21, 23, 26, 15, 18, 22, 29, 10, 14, 16, 27, 24, 13, 9, 20, 19, 12, 11, 7, 3, 4],
                "worst-individual-distance": 67145.26847146692,
                "average-distance": 62713.11580461988,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 14, 24, 17, 21, 23, 26, 15, 18, 22, 29, 28, 16, 27, 25, 20, 19, 13, 9, 12, 11, 7, 3, 4, 8, 6, 5, 1, 2],
                "best-individual-distance": 47909.48575475627,
                "worst-individual-sequence": [6, 29, 12, 21, 23, 26, 22, 28, 17, 25, 27, 14, 3, 10, 5, 9, 16, 24, 20, 18, 19, 15, 13, 8, 4, 11, 1, 2, 7],
                "worst-individual-distance": 66416.14829407829,
                "average-distance": 62032.4402556408,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 14, 24, 17, 21, 23, 26, 15, 18, 22, 29, 28, 16, 27, 25, 20, 19, 13, 9, 12, 11, 7, 3, 4, 8, 6, 5, 1, 2],
                "best-individual-distance": 47909.48575475627,
                "worst-individual-sequence": [5, 14, 10, 23, 16, 27, 24, 28, 29, 22, 19, 3, 7, 8, 4, 2, 1, 6, 13, 15, 17, 25, 20, 26, 12, 11, 9, 21, 18],
                "worst-individual-distance": 65894.52662791371,
                "average-distance": 61457.667721338184,
                "individual-distances": []
            }, {
                "best-individual-sequence": [18, 22, 29, 28, 23, 26, 17, 16, 27, 25, 20, 24, 9, 19, 14, 13, 10, 12, 6, 1, 2, 21, 7, 4, 5, 3, 8, 11, 15],
                "best-individual-distance": 44759.68152971399,
                "worst-individual-sequence": [6, 4, 5, 14, 15, 23, 18, 8, 2, 1, 10, 25, 16, 27, 24, 29, 22, 13, 9, 12, 3, 11, 19, 21, 26, 28, 20, 17, 7],
                "worst-individual-distance": 65210.41954557728,
                "average-distance": 60854.306132082806,
                "individual-distances": []
            }, {
                "best-individual-sequence": [18, 22, 29, 28, 23, 26, 17, 16, 27, 25, 20, 24, 9, 19, 14, 13, 10, 12, 6, 1, 2, 21, 7, 4, 5, 3, 8, 11, 15],
                "best-individual-distance": 44759.68152971399,
                "worst-individual-sequence": [12, 22, 19, 14, 17, 10, 21, 16, 13, 9, 6, 2, 1, 3, 29, 23, 7, 4, 5, 8, 27, 24, 25, 20, 28, 26, 18, 15, 11],
                "worst-individual-distance": 64578.700902932294,
                "average-distance": 60288.48450252238,
                "individual-distances": []
            }, {
                "best-individual-sequence": [18, 22, 29, 28, 23, 26, 17, 16, 27, 25, 20, 24, 9, 19, 14, 13, 10, 12, 6, 1, 2, 21, 7, 4, 5, 3, 8, 11, 15],
                "best-individual-distance": 44759.68152971399,
                "worst-individual-sequence": [9, 23, 8, 18, 20, 21, 12, 11, 2, 6, 4, 5, 14, 10, 1, 26, 16, 27, 24, 28, 29, 15, 22, 19, 17, 25, 13, 7, 3],
                "worst-individual-distance": 63952.98151605113,
                "average-distance": 59764.66962642102,
                "individual-distances": []
            }, {
                "best-individual-sequence": [18, 22, 29, 28, 23, 26, 17, 16, 27, 25, 20, 24, 9, 19, 14, 13, 10, 12, 6, 1, 2, 21, 7, 4, 5, 3, 8, 11, 15],
                "best-individual-distance": 44759.68152971399,
                "worst-individual-sequence": [2, 26, 25, 27, 24, 23, 20, 17, 21, 16, 19, 22, 14, 9, 10, 7, 3, 4, 5, 12, 11, 15, 29, 28, 18, 13, 8, 6, 1],
                "worst-individual-distance": 63428.686785130965,
                "average-distance": 59252.443052333554,
                "individual-distances": []
            }, {
                "best-individual-sequence": [18, 22, 29, 28, 23, 26, 17, 16, 27, 25, 20, 24, 9, 19, 14, 13, 10, 12, 6, 1, 2, 21, 7, 4, 5, 3, 8, 11, 15],
                "best-individual-distance": 44759.68152971399,
                "worst-individual-sequence": [29, 23, 28, 27, 17, 25, 5, 9, 16, 24, 20, 26, 7, 8, 4, 2, 1, 10, 12, 13, 14, 15, 19, 18, 22, 11, 3, 6, 21],
                "worst-individual-distance": 62895.65344788225,
                "average-distance": 58823.57399627238,
                "individual-distances": []
            }, {
                "best-individual-sequence": [18, 22, 29, 28, 23, 26, 17, 16, 27, 25, 20, 24, 9, 19, 14, 13, 10, 12, 6, 1, 2, 21, 7, 4, 5, 3, 8, 11, 15],
                "best-individual-distance": 44759.68152971399,
                "worst-individual-sequence": [10, 13, 23, 15, 7, 11, 12, 29, 26, 3, 8, 4, 2, 1, 6, 5, 9, 16, 24, 20, 25, 14, 19, 22, 21, 28, 27, 17, 18],
                "worst-individual-distance": 62441.15459874623,
                "average-distance": 58354.829337909294,
                "individual-distances": []
            }, {
                "best-individual-sequence": [18, 22, 29, 28, 23, 26, 17, 16, 27, 25, 20, 24, 9, 19, 14, 13, 10, 12, 6, 1, 2, 21, 7, 4, 5, 3, 8, 11, 15],
                "best-individual-distance": 44759.68152971399,
                "worst-individual-sequence": [14, 8, 23, 20, 21, 12, 11, 1, 2, 6, 4, 5, 3, 7, 28, 16, 19, 22, 18, 13, 9, 10, 29, 17, 15, 25, 24, 27, 26],
                "worst-individual-distance": 61932.117064214435,
                "average-distance": 57901.115967069774,
                "individual-distances": []
            }, {
                "best-individual-sequence": [18, 22, 29, 28, 23, 26, 17, 16, 27, 25, 20, 24, 9, 19, 14, 13, 10, 12, 6, 1, 2, 21, 7, 4, 5, 3, 8, 11, 15],
                "best-individual-distance": 44759.68152971399,
                "worst-individual-sequence": [10, 21, 23, 27, 26, 12, 13, 8, 4, 2, 1, 6, 5, 28, 14, 15, 9, 3, 7, 16, 25, 20, 24, 29, 17, 19, 18, 22, 11],
                "worst-individual-distance": 61331.339189842794,
                "average-distance": 57420.47355629688,
                "individual-distances": []
            }, {
                "best-individual-sequence": [18, 22, 29, 28, 23, 26, 17, 16, 27, 25, 20, 24, 9, 19, 14, 13, 10, 12, 6, 1, 2, 21, 7, 4, 5, 3, 8, 11, 15],
                "best-individual-distance": 44759.68152971399,
                "worst-individual-sequence": [21, 11, 10, 24, 26, 17, 20, 28, 16, 27, 14, 3, 7, 8, 4, 2, 1, 6, 5, 9, 18, 19, 15, 13, 25, 23, 22, 29, 12],
                "worst-individual-distance": 60794.69925016426,
                "average-distance": 56971.899117891335,
                "individual-distances": []
            }, {
                "best-individual-sequence": [18, 22, 29, 28, 23, 26, 17, 16, 27, 25, 20, 24, 9, 19, 14, 13, 10, 12, 6, 1, 2, 21, 7, 4, 5, 3, 8, 11, 15],
                "best-individual-distance": 44759.68152971399,
                "worst-individual-sequence": [6, 5, 12, 17, 20, 29, 28, 19, 10, 7, 18, 26, 25, 16, 27, 24, 22, 15, 14, 11, 23, 21, 9, 3, 4, 13, 8, 2, 1],
                "worst-individual-distance": 60333.41830817318,
                "average-distance": 56529.58495720356,
                "individual-distances": []
            }, {
                "best-individual-sequence": [18, 22, 29, 28, 23, 26, 17, 16, 27, 25, 20, 24, 9, 19, 14, 13, 10, 12, 6, 1, 2, 21, 7, 4, 5, 3, 8, 11, 15],
                "best-individual-distance": 44759.68152971399,
                "worst-individual-sequence": [7, 18, 29, 21, 14, 28, 16, 23, 11, 10, 13, 12, 24, 27, 4, 2, 1, 6, 5, 9, 20, 25, 26, 22, 19, 17, 15, 8, 3],
                "worst-individual-distance": 59907.423717898164,
                "average-distance": 56139.163212679305,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 17, 16, 2, 1, 6, 5, 9, 8, 27, 25, 26, 20, 24, 21, 19, 14, 13, 7, 3, 4, 10, 11, 12, 15, 18, 22, 29, 28],
                "best-individual-distance": 44086.64094347054,
                "worst-individual-sequence": [11, 2, 13, 10, 21, 23, 26, 15, 18, 22, 29, 28, 16, 27, 25, 20, 24, 9, 7, 3, 4, 1, 8, 6, 5, 14, 17, 19, 12],
                "worst-individual-distance": 59363.17338804905,
                "average-distance": 55696.15549626788,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 17, 16, 2, 1, 6, 5, 9, 8, 27, 25, 26, 20, 24, 21, 19, 14, 13, 7, 3, 4, 10, 11, 12, 15, 18, 22, 29, 28],
                "best-individual-distance": 44086.64094347054,
                "worst-individual-sequence": [15, 29, 25, 20, 24, 27, 17, 12, 14, 13, 7, 8, 2, 1, 11, 9, 26, 28, 16, 22, 18, 10, 6, 5, 4, 3, 21, 23, 19],
                "worst-individual-distance": 58908.967718595144,
                "average-distance": 55328.71223440543,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 17, 16, 2, 1, 6, 5, 9, 8, 27, 25, 26, 20, 24, 21, 19, 14, 13, 7, 3, 4, 10, 11, 12, 15, 18, 22, 29, 28],
                "best-individual-distance": 44086.64094347054,
                "worst-individual-sequence": [24, 26, 17, 20, 15, 18, 29, 28, 22, 16, 27, 19, 14, 13, 8, 10, 6, 5, 7, 3, 4, 1, 12, 9, 2, 11, 23, 21, 25],
                "worst-individual-distance": 58487.17388110004,
                "average-distance": 54983.166985951975,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 18, 16, 15, 22, 29, 28, 26, 27, 25, 24, 20, 17, 21, 19, 14, 13, 9, 7, 12, 11, 6, 1, 2, 5, 4, 3, 8, 10],
                "best-individual-distance": 40899.760396361184,
                "worst-individual-sequence": [4, 5, 10, 12, 14, 26, 25, 27, 24, 28, 23, 20, 17, 21, 29, 16, 19, 22, 13, 2, 8, 7, 3, 9, 15, 18, 11, 1, 6],
                "worst-individual-distance": 58007.06091524591,
                "average-distance": 54639.72843302496,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 18, 16, 15, 22, 29, 28, 26, 27, 25, 24, 20, 17, 21, 19, 14, 13, 9, 7, 12, 11, 6, 1, 2, 5, 4, 3, 8, 10],
                "best-individual-distance": 40899.760396361184,
                "worst-individual-sequence": [6, 2, 28, 19, 12, 14, 23, 26, 25, 27, 24, 20, 17, 21, 29, 16, 15, 22, 18, 13, 9, 10, 11, 7, 3, 5, 4, 1, 8],
                "worst-individual-distance": 57463.644327945214,
                "average-distance": 54214.88376728861,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 18, 16, 15, 22, 29, 28, 26, 27, 25, 24, 20, 17, 21, 19, 14, 13, 9, 7, 12, 11, 6, 1, 2, 5, 4, 3, 8, 10],
                "best-individual-distance": 40899.760396361184,
                "worst-individual-sequence": [9, 18, 22, 29, 28, 16, 27, 25, 20, 14, 10, 17, 26, 24, 23, 21, 19, 15, 12, 13, 7, 11, 4, 3, 6, 1, 8, 2, 5],
                "worst-individual-distance": 57027.26468793578,
                "average-distance": 53865.35125021198,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 18, 16, 15, 22, 29, 28, 26, 27, 25, 24, 20, 17, 21, 19, 14, 13, 9, 7, 12, 11, 6, 1, 2, 5, 4, 3, 8, 10],
                "best-individual-distance": 40899.760396361184,
                "worst-individual-sequence": [7, 8, 28, 21, 25, 24, 27, 23, 26, 15, 29, 14, 9, 17, 16, 20, 19, 22, 18, 13, 12, 11, 4, 3, 6, 1, 2, 5, 10],
                "worst-individual-distance": 56684.1234753034,
                "average-distance": 53508.419103844935,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 18, 16, 15, 22, 29, 28, 26, 27, 25, 24, 20, 17, 21, 19, 14, 13, 9, 7, 12, 11, 6, 1, 2, 5, 4, 3, 8, 10],
                "best-individual-distance": 40899.760396361184,
                "worst-individual-sequence": [28, 23, 17, 21, 29, 16, 27, 25, 20, 24, 14, 12, 7, 8, 4, 2, 1, 6, 10, 15, 19, 18, 22, 13, 5, 11, 9, 3, 26],
                "worst-individual-distance": 56249.03752132649,
                "average-distance": 53149.26263115665,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 18, 16, 15, 22, 29, 28, 26, 27, 25, 24, 20, 17, 21, 19, 14, 13, 9, 7, 12, 11, 6, 1, 2, 5, 4, 3, 8, 10],
                "best-individual-distance": 40899.760396361184,
                "worst-individual-sequence": [26, 15, 18, 22, 29, 28, 16, 27, 25, 24, 20, 17, 9, 21, 19, 13, 7, 5, 3, 4, 10, 11, 14, 2, 1, 6, 12, 8, 23],
                "worst-individual-distance": 55849.51054149982,
                "average-distance": 52840.90809881121,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 18, 16, 15, 22, 29, 28, 26, 27, 25, 24, 20, 17, 21, 19, 14, 13, 9, 7, 12, 11, 6, 1, 2, 5, 4, 3, 8, 10],
                "best-individual-distance": 40899.760396361184,
                "worst-individual-sequence": [5, 10, 17, 21, 25, 24, 27, 23, 26, 15, 18, 29, 22, 14, 13, 9, 28, 16, 20, 19, 12, 11, 4, 3, 6, 1, 2, 8, 7],
                "worst-individual-distance": 55449.42007546434,
                "average-distance": 52461.140643417944,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 18, 16, 15, 22, 29, 28, 26, 27, 25, 24, 20, 17, 21, 19, 14, 13, 9, 7, 12, 11, 6, 1, 2, 5, 4, 3, 8, 10],
                "best-individual-distance": 40899.760396361184,
                "worst-individual-sequence": [27, 24, 28, 20, 21, 29, 11, 17, 23, 12, 8, 4, 2, 1, 6, 5, 3, 9, 10, 7, 13, 26, 19, 15, 18, 22, 16, 14, 25],
                "worst-individual-distance": 55107.05885628488,
                "average-distance": 52058.98731346315,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 18, 16, 15, 22, 29, 28, 26, 27, 25, 24, 20, 17, 21, 19, 14, 13, 9, 7, 12, 11, 6, 1, 2, 5, 4, 3, 8, 10],
                "best-individual-distance": 40899.760396361184,
                "worst-individual-sequence": [9, 18, 20, 1, 12, 2, 6, 4, 5, 10, 11, 15, 14, 21, 23, 26, 25, 16, 27, 24, 28, 29, 22, 7, 8, 17, 19, 13, 3],
                "worst-individual-distance": 54727.1186635657,
                "average-distance": 51754.30131288448,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 18, 16, 15, 22, 29, 28, 26, 27, 25, 24, 20, 17, 21, 19, 14, 13, 9, 7, 12, 11, 6, 1, 2, 5, 4, 3, 8, 10],
                "best-individual-distance": 40899.760396361184,
                "worst-individual-sequence": [2, 5, 17, 21, 25, 24, 27, 23, 26, 15, 18, 29, 22, 14, 13, 9, 28, 16, 20, 19, 12, 11, 4, 8, 3, 7, 10, 6, 1],
                "worst-individual-distance": 54376.203483605546,
                "average-distance": 51417.442451475974,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 18, 16, 15, 22, 29, 28, 26, 27, 25, 24, 20, 17, 21, 19, 14, 13, 9, 7, 12, 11, 6, 1, 2, 5, 4, 3, 8, 10],
                "best-individual-distance": 40899.760396361184,
                "worst-individual-sequence": [2, 15, 12, 26, 14, 28, 25, 27, 24, 23, 20, 17, 21, 29, 16, 19, 22, 18, 13, 9, 10, 11, 7, 3, 4, 8, 6, 5, 1],
                "worst-individual-distance": 54038.6237632276,
                "average-distance": 51023.272307964406,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 18, 16, 15, 22, 29, 28, 26, 27, 25, 24, 20, 17, 21, 19, 14, 13, 9, 7, 12, 11, 6, 1, 2, 5, 4, 3, 8, 10],
                "best-individual-distance": 40899.760396361184,
                "worst-individual-sequence": [2, 1, 10, 7, 3, 5, 12, 4, 11, 8, 14, 27, 24, 29, 22, 21, 19, 6, 25, 17, 15, 18, 28, 20, 26, 23, 13, 9, 16],
                "worst-individual-distance": 53683.07454285483,
                "average-distance": 50721.11821959034,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 18, 16, 15, 22, 29, 28, 26, 27, 25, 24, 20, 17, 21, 19, 14, 13, 9, 7, 12, 11, 6, 1, 2, 5, 4, 3, 8, 10],
                "best-individual-distance": 40899.760396361184,
                "worst-individual-sequence": [21, 10, 12, 9, 8, 6, 1, 2, 5, 4, 26, 25, 16, 27, 24, 20, 28, 14, 29, 17, 18, 22, 19, 23, 15, 13, 3, 7, 11],
                "worst-individual-distance": 53296.82466410996,
                "average-distance": 50380.03181576177,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 18, 16, 15, 22, 29, 28, 26, 27, 25, 24, 20, 17, 21, 19, 14, 13, 9, 7, 12, 11, 6, 1, 2, 5, 4, 3, 8, 10],
                "best-individual-distance": 40899.760396361184,
                "worst-individual-sequence": [24, 19, 26, 21, 13, 3, 7, 10, 12, 6, 1, 2, 5, 4, 9, 11, 14, 8, 15, 18, 22, 29, 28, 23, 17, 16, 27, 25, 20],
                "worst-individual-distance": 52890.41172548228,
                "average-distance": 50043.594490102994,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 18, 16, 15, 22, 29, 28, 26, 27, 25, 24, 20, 17, 21, 19, 14, 13, 9, 7, 12, 11, 6, 1, 2, 5, 4, 3, 8, 10],
                "best-individual-distance": 40899.760396361184,
                "worst-individual-sequence": [19, 12, 8, 26, 24, 20, 17, 21, 29, 16, 27, 25, 14, 28, 23, 15, 22, 18, 13, 9, 10, 11, 7, 3, 4, 2, 1, 6, 5],
                "worst-individual-distance": 52471.90121554518,
                "average-distance": 49720.052724597736,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 18, 16, 15, 22, 29, 28, 26, 27, 25, 24, 20, 17, 21, 19, 14, 13, 9, 7, 12, 11, 6, 1, 2, 5, 4, 3, 8, 10],
                "best-individual-distance": 40899.760396361184,
                "worst-individual-sequence": [8, 6, 15, 12, 14, 26, 25, 27, 24, 28, 23, 20, 17, 21, 29, 16, 19, 22, 18, 13, 9, 10, 11, 7, 5, 1, 2, 3, 4],
                "worst-individual-distance": 52059.61321418548,
                "average-distance": 49408.08818245412,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 18, 16, 15, 22, 29, 28, 26, 27, 25, 24, 20, 17, 21, 19, 14, 13, 9, 7, 12, 11, 6, 1, 2, 5, 4, 3, 8, 10],
                "best-individual-distance": 40899.760396361184,
                "worst-individual-sequence": [24, 28, 23, 20, 17, 22, 18, 21, 29, 16, 19, 12, 11, 10, 9, 14, 13, 7, 6, 3, 4, 8, 5, 1, 2, 15, 26, 25, 27],
                "worst-individual-distance": 51818.80136448346,
                "average-distance": 49106.63166367963,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 18, 16, 15, 22, 29, 28, 26, 27, 25, 24, 20, 17, 21, 19, 14, 13, 9, 7, 12, 11, 6, 1, 2, 5, 4, 3, 8, 10],
                "best-individual-distance": 40899.760396361184,
                "worst-individual-sequence": [19, 21, 14, 28, 23, 17, 8, 2, 1, 6, 5, 9, 7, 27, 25, 20, 24, 26, 16, 3, 4, 10, 11, 12, 13, 15, 18, 22, 29],
                "worst-individual-distance": 51493.87487128733,
                "average-distance": 48868.15365777339,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 18, 16, 15, 22, 29, 28, 26, 27, 25, 24, 20, 17, 21, 19, 14, 13, 9, 7, 12, 11, 6, 1, 2, 5, 4, 3, 8, 10],
                "best-individual-distance": 40899.760396361184,
                "worst-individual-sequence": [11, 8, 7, 17, 23, 26, 21, 19, 13, 3, 9, 4, 5, 22, 29, 28, 14, 16, 27, 25, 20, 24, 18, 15, 12, 2, 1, 6, 10],
                "worst-individual-distance": 51172.22256925783,
                "average-distance": 48609.930874972546,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 25, 16, 27, 24, 20, 28, 29, 23, 21, 17, 19, 22, 18, 13, 9, 12, 11, 10, 7, 3, 4, 8, 6, 1, 2, 5, 15, 14],
                "best-individual-distance": 39881.83485925733,
                "worst-individual-sequence": [10, 12, 26, 25, 27, 24, 28, 23, 21, 29, 19, 18, 22, 14, 13, 9, 17, 16, 20, 15, 11, 7, 3, 4, 8, 6, 5, 1, 2],
                "worst-individual-distance": 50853.909972541325,
                "average-distance": 48351.006343022236,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 25, 16, 27, 24, 20, 28, 29, 23, 21, 17, 19, 22, 18, 13, 9, 12, 11, 10, 7, 3, 4, 8, 6, 1, 2, 5, 15, 14],
                "best-individual-distance": 39881.83485925733,
                "worst-individual-sequence": [8, 26, 25, 16, 27, 24, 20, 28, 18, 21, 23, 17, 15, 10, 11, 12, 14, 7, 6, 1, 2, 5, 4, 22, 29, 19, 13, 3, 9],
                "worst-individual-distance": 50497.26124927526,
                "average-distance": 48099.53668291945,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 25, 16, 27, 24, 20, 28, 29, 23, 21, 17, 19, 22, 18, 13, 9, 12, 11, 10, 7, 3, 4, 8, 6, 1, 2, 5, 15, 14],
                "best-individual-distance": 39881.83485925733,
                "worst-individual-sequence": [22, 29, 15, 12, 14, 26, 25, 27, 24, 28, 23, 16, 20, 19, 13, 9, 10, 11, 7, 3, 4, 8, 6, 5, 1, 2, 17, 21, 18],
                "worst-individual-distance": 50184.77929720559,
                "average-distance": 47855.225083092715,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 25, 16, 27, 24, 20, 28, 29, 23, 21, 17, 19, 22, 18, 13, 9, 12, 11, 10, 7, 3, 4, 8, 6, 1, 2, 5, 15, 14],
                "best-individual-distance": 39881.83485925733,
                "worst-individual-sequence": [26, 25, 16, 27, 24, 20, 28, 29, 23, 21, 12, 17, 2, 6, 5, 1, 22, 19, 13, 9, 7, 11, 4, 3, 8, 10, 18, 15, 14],
                "worst-individual-distance": 49890.31618587218,
                "average-distance": 47588.2993068789,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 20, 21, 19, 14, 13, 10, 12, 11, 6, 1, 2, 5, 4, 8, 3, 7, 9, 15, 18, 22, 29, 26, 16, 25, 27, 24, 28, 23],
                "best-individual-distance": 38128.08676155582,
                "worst-individual-sequence": [20, 24, 16, 27, 25, 17, 29, 15, 22, 28, 14, 12, 19, 26, 18, 13, 9, 21, 11, 7, 3, 4, 5, 6, 1, 2, 8, 10, 23],
                "worst-individual-distance": 49656.47929578243,
                "average-distance": 47369.52116400679,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 20, 21, 19, 14, 13, 10, 12, 11, 6, 1, 2, 5, 4, 8, 3, 7, 9, 15, 18, 22, 29, 26, 16, 25, 27, 24, 28, 23],
                "best-individual-distance": 38128.08676155582,
                "worst-individual-sequence": [1, 6, 5, 19, 26, 25, 27, 24, 28, 23, 20, 29, 16, 14, 21, 17, 15, 22, 18, 13, 9, 10, 11, 7, 3, 12, 8, 4, 2],
                "worst-individual-distance": 49427.103453694515,
                "average-distance": 47170.453113165,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 20, 21, 19, 14, 13, 10, 12, 11, 6, 1, 2, 5, 4, 8, 3, 7, 9, 15, 18, 22, 29, 26, 16, 25, 27, 24, 28, 23],
                "best-individual-distance": 38128.08676155582,
                "worst-individual-sequence": [26, 25, 27, 24, 28, 15, 23, 20, 17, 21, 29, 16, 12, 22, 18, 13, 9, 10, 11, 7, 3, 4, 5, 6, 8, 2, 1, 19, 14],
                "worst-individual-distance": 49334.146690923386,
                "average-distance": 46987.58553451872,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 14, 26, 25, 16, 27, 24, 20, 17, 28, 23, 21, 29, 22, 19, 18, 15, 10, 11, 2, 6, 1, 5, 4, 3, 8, 9, 7, 13],
                "best-individual-distance": 36825.66682516426,
                "worst-individual-sequence": [24, 28, 23, 20, 21, 17, 18, 22, 29, 16, 19, 13, 9, 12, 7, 3, 4, 10, 11, 8, 6, 5, 1, 2, 15, 14, 26, 25, 27],
                "worst-individual-distance": 49011.54366567745,
                "average-distance": 46766.533513510585,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 14, 26, 25, 16, 27, 24, 20, 17, 28, 23, 21, 29, 22, 19, 18, 15, 10, 11, 2, 6, 1, 5, 4, 3, 8, 9, 7, 13],
                "best-individual-distance": 36825.66682516426,
                "worst-individual-sequence": [14, 26, 25, 27, 24, 28, 23, 20, 17, 21, 29, 16, 19, 22, 18, 13, 9, 10, 11, 7, 3, 4, 5, 6, 1, 2, 8, 15, 12],
                "worst-individual-distance": 48765.64714497522,
                "average-distance": 46543.712140135205,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 14, 26, 25, 16, 27, 24, 20, 17, 28, 23, 21, 29, 22, 19, 18, 15, 10, 11, 2, 6, 1, 5, 4, 3, 8, 9, 7, 13],
                "best-individual-distance": 36825.66682516426,
                "worst-individual-sequence": [2, 6, 7, 3, 8, 4, 12, 19, 22, 18, 15, 21, 23, 26, 28, 17, 14, 16, 27, 25, 20, 24, 29, 13, 9, 10, 5, 11, 1],
                "worst-individual-distance": 48521.54782876767,
                "average-distance": 46323.80080903497,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 14, 26, 25, 16, 27, 24, 20, 17, 28, 23, 21, 29, 22, 19, 18, 15, 10, 11, 2, 6, 1, 5, 4, 3, 8, 9, 7, 13],
                "best-individual-distance": 36825.66682516426,
                "worst-individual-sequence": [25, 27, 24, 28, 23, 20, 17, 19, 22, 21, 29, 16, 15, 18, 13, 9, 11, 7, 3, 10, 12, 6, 1, 2, 5, 4, 8, 14, 26],
                "worst-individual-distance": 48398.712734301196,
                "average-distance": 46140.2229544898,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 14, 26, 25, 16, 27, 24, 20, 17, 28, 23, 21, 29, 22, 19, 18, 15, 10, 11, 2, 6, 1, 5, 4, 3, 8, 9, 7, 13],
                "best-individual-distance": 36825.66682516426,
                "worst-individual-sequence": [15, 18, 16, 27, 24, 20, 17, 21, 29, 22, 28, 25, 9, 7, 3, 4, 10, 11, 8, 6, 5, 1, 2, 12, 14, 26, 23, 19, 13],
                "worst-individual-distance": 48091.77712422292,
                "average-distance": 45921.76037002402,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 14, 26, 25, 16, 27, 24, 20, 17, 28, 23, 21, 29, 22, 19, 18, 15, 10, 11, 2, 6, 1, 5, 4, 3, 8, 9, 7, 13],
                "best-individual-distance": 36825.66682516426,
                "worst-individual-sequence": [8, 23, 21, 29, 18, 13, 28, 16, 27, 25, 24, 20, 17, 22, 19, 15, 10, 11, 2, 6, 1, 5, 4, 3, 7, 12, 14, 26, 9],
                "worst-individual-distance": 47885.99521292824,
                "average-distance": 45688.03368834843,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 14, 26, 25, 16, 27, 24, 20, 17, 28, 23, 21, 29, 22, 19, 18, 15, 10, 11, 2, 6, 1, 5, 4, 3, 8, 9, 7, 13],
                "best-individual-distance": 36825.66682516426,
                "worst-individual-sequence": [19, 22, 18, 15, 21, 23, 24, 20, 17, 26, 28, 25, 27, 29, 14, 16, 13, 11, 5, 9, 3, 7, 8, 4, 2, 1, 6, 10, 12],
                "worst-individual-distance": 47638.80672254488,
                "average-distance": 45469.714017082595,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 14, 26, 25, 16, 27, 24, 20, 17, 28, 23, 21, 29, 22, 19, 18, 15, 10, 11, 2, 6, 1, 5, 4, 3, 8, 9, 7, 13],
                "best-individual-distance": 36825.66682516426,
                "worst-individual-sequence": [15, 18, 22, 28, 27, 25, 24, 17, 21, 29, 16, 20, 9, 7, 3, 4, 10, 11, 8, 6, 5, 1, 2, 12, 14, 26, 23, 19, 13],
                "worst-individual-distance": 47501.46250903035,
                "average-distance": 45276.481369731824,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 14, 26, 25, 16, 27, 24, 20, 17, 28, 23, 21, 29, 22, 19, 18, 15, 10, 11, 2, 6, 1, 5, 4, 3, 8, 9, 7, 13],
                "best-individual-distance": 36825.66682516426,
                "worst-individual-sequence": [29, 28, 25, 27, 23, 26, 17, 16, 20, 24, 21, 19, 14, 13, 12, 9, 3, 7, 4, 10, 11, 8, 6, 5, 1, 2, 15, 18, 22],
                "worst-individual-distance": 47296.731321171465,
                "average-distance": 45070.67721049693,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 14, 26, 25, 16, 27, 24, 20, 17, 28, 23, 21, 29, 22, 19, 18, 15, 10, 11, 2, 6, 1, 5, 4, 3, 8, 9, 7, 13],
                "best-individual-distance": 36825.66682516426,
                "worst-individual-sequence": [23, 17, 15, 22, 18, 26, 25, 16, 27, 24, 20, 28, 21, 29, 19, 13, 9, 7, 11, 2, 1, 10, 3, 4, 8, 6, 5, 12, 14],
                "worst-individual-distance": 46931.14701976749,
                "average-distance": 44835.74632688776,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 14, 26, 25, 16, 27, 24, 20, 17, 28, 23, 21, 29, 22, 19, 18, 15, 10, 11, 2, 6, 1, 5, 4, 3, 8, 9, 7, 13],
                "best-individual-distance": 36825.66682516426,
                "worst-individual-sequence": [1, 2, 12, 14, 26, 28, 23, 21, 29, 16, 27, 25, 20, 24, 19, 17, 15, 22, 18, 13, 9, 10, 11, 7, 3, 4, 8, 6, 5],
                "worst-individual-distance": 46733.89690090804,
                "average-distance": 44650.74073795269,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 14, 26, 25, 16, 27, 24, 20, 17, 28, 23, 21, 29, 22, 19, 18, 15, 10, 11, 2, 6, 1, 5, 4, 3, 8, 9, 7, 13],
                "best-individual-distance": 36825.66682516426,
                "worst-individual-sequence": [17, 19, 14, 26, 25, 27, 24, 28, 21, 23, 13, 9, 7, 4, 2, 1, 6, 5, 10, 11, 3, 8, 15, 12, 20, 16, 29, 22, 18],
                "worst-individual-distance": 46499.20482639764,
                "average-distance": 44453.10612705252,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 14, 26, 25, 16, 27, 24, 20, 17, 28, 23, 21, 29, 22, 19, 18, 15, 10, 11, 2, 6, 1, 5, 4, 3, 8, 9, 7, 13],
                "best-individual-distance": 36825.66682516426,
                "worst-individual-sequence": [21, 15, 13, 18, 22, 29, 28, 16, 27, 25, 24, 20, 17, 12, 7, 3, 4, 10, 11, 8, 6, 5, 1, 2, 9, 14, 19, 23, 26],
                "worst-individual-distance": 46359.17341832434,
                "average-distance": 44273.5593647621,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 14, 26, 25, 16, 27, 24, 20, 17, 28, 23, 21, 29, 22, 19, 18, 15, 10, 11, 2, 6, 1, 5, 4, 3, 8, 9, 7, 13],
                "best-individual-distance": 36825.66682516426,
                "worst-individual-sequence": [16, 20, 17, 29, 19, 22, 18, 21, 26, 23, 13, 9, 7, 4, 2, 1, 6, 5, 10, 11, 3, 8, 15, 12, 14, 25, 27, 24, 28],
                "worst-individual-distance": 46160.94993667021,
                "average-distance": 44076.18042394451,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 14, 26, 25, 16, 27, 24, 20, 17, 28, 23, 21, 29, 22, 19, 18, 15, 10, 11, 2, 6, 1, 5, 4, 3, 8, 9, 7, 13],
                "best-individual-distance": 36825.66682516426,
                "worst-individual-sequence": [18, 15, 28, 23, 20, 26, 25, 27, 16, 24, 17, 7, 8, 4, 2, 1, 6, 5, 10, 11, 9, 13, 3, 12, 14, 21, 29, 19, 22],
                "worst-individual-distance": 45983.65456417805,
                "average-distance": 43895.941204797586,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 29, 22, 18, 16, 27, 25, 24, 20, 17, 19, 15, 13, 9, 7, 3, 4, 10, 11, 8, 5, 6, 1, 2, 12, 14, 26, 28, 23],
                "best-individual-distance": 36754.18575573159,
                "worst-individual-sequence": [23, 21, 29, 16, 20, 26, 25, 27, 24, 17, 15, 22, 19, 18, 13, 9, 12, 11, 10, 14, 3, 4, 8, 6, 1, 2, 5, 7, 28],
                "worst-individual-distance": 45731.59282470107,
                "average-distance": 43706.06691055567,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 29, 22, 18, 16, 27, 25, 24, 20, 17, 19, 15, 13, 9, 7, 3, 4, 10, 11, 8, 5, 6, 1, 2, 12, 14, 26, 28, 23],
                "best-individual-distance": 36754.18575573159,
                "worst-individual-sequence": [16, 27, 24, 20, 28, 29, 23, 21, 15, 17, 22, 19, 13, 9, 7, 11, 10, 12, 4, 8, 2, 6, 1, 5, 3, 18, 14, 25, 26],
                "worst-individual-distance": 45557.95352285008,
                "average-distance": 43516.77636180785,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 29, 22, 18, 16, 27, 25, 24, 20, 17, 19, 15, 13, 9, 7, 3, 4, 10, 11, 8, 5, 6, 1, 2, 12, 14, 26, 28, 23],
                "best-individual-distance": 36754.18575573159,
                "worst-individual-sequence": [14, 26, 25, 27, 24, 28, 23, 20, 17, 21, 29, 16, 15, 22, 18, 13, 9, 12, 11, 10, 7, 3, 4, 8, 6, 1, 2, 5, 19],
                "worst-individual-distance": 45275.24868918945,
                "average-distance": 43332.386669926884,
                "individual-distances": []
            }, {
                "best-individual-sequence": [24, 20, 28, 29, 23, 17, 22, 18, 21, 19, 14, 13, 12, 9, 7, 3, 4, 8, 1, 2, 6, 5, 10, 11, 15, 26, 25, 16, 27],
                "best-individual-distance": 36732.84234539506,
                "worst-individual-sequence": [29, 28, 23, 26, 17, 16, 27, 25, 20, 24, 21, 19, 14, 18, 13, 9, 3, 4, 12, 6, 1, 2, 8, 7, 5, 10, 11, 15, 22],
                "worst-individual-distance": 45110.09549950103,
                "average-distance": 43145.21945999509,
                "individual-distances": []
            }
        ],
        [
            [{
                "time_cost": 0
            }], {
                "best-individual-sequence": [24, 26, 2, 1, 9, 3, 4, 5, 28, 25, 22, 18, 7, 11, 13, 17, 12, 14, 27, 20, 16, 23, 21, 29, 15, 19, 8, 10, 6],
                "best-individual-distance": 76736.40003092439,
                "worst-individual-sequence": [14, 29, 26, 5, 13, 23, 18, 21, 6, 11, 3, 12, 15, 27, 4, 16, 2, 22, 28, 10, 17, 20, 19, 9, 7, 24, 1, 25, 8],
                "worst-individual-distance": 120135.99674824667,
                "average-distance": 106199.73193564852,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 17, 26, 25, 9, 5, 2, 6, 1, 27, 29, 19, 18, 3, 7, 8, 10, 13, 4, 11, 14, 28, 23, 15, 12, 24, 16, 21, 22],
                "best-individual-distance": 69499.94391225257,
                "worst-individual-sequence": [4, 11, 21, 28, 18, 23, 27, 24, 7, 10, 2, 25, 3, 26, 5, 19, 13, 1, 14, 6, 16, 22, 17, 15, 9, 20, 8, 12, 29],
                "worst-individual-distance": 115618.03820816337,
                "average-distance": 103409.72808426192,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 17, 26, 25, 9, 5, 2, 6, 1, 27, 29, 19, 18, 3, 7, 8, 10, 13, 4, 11, 14, 28, 23, 15, 12, 24, 16, 21, 22],
                "best-individual-distance": 69499.94391225257,
                "worst-individual-sequence": [22, 16, 27, 15, 3, 11, 13, 18, 8, 9, 28, 24, 23, 14, 29, 1, 6, 20, 5, 10, 7, 19, 4, 25, 17, 12, 26, 21, 2],
                "worst-individual-distance": 112003.82670465932,
                "average-distance": 100917.41683640995,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 17, 26, 25, 9, 5, 2, 6, 1, 27, 29, 19, 18, 3, 7, 8, 10, 13, 4, 11, 14, 28, 23, 15, 12, 24, 16, 21, 22],
                "best-individual-distance": 69499.94391225257,
                "worst-individual-sequence": [18, 26, 1, 27, 25, 21, 23, 11, 8, 19, 3, 22, 7, 10, 16, 6, 2, 14, 5, 9, 20, 17, 24, 28, 12, 4, 29, 15, 13],
                "worst-individual-distance": 109401.16399390523,
                "average-distance": 98732.40149878684,
                "individual-distances": []
            }, {
                "best-individual-sequence": [18, 19, 14, 2, 1, 13, 9, 4, 5, 7, 11, 10, 6, 8, 12, 16, 3, 17, 26, 25, 21, 29, 23, 20, 24, 28, 27, 15, 22],
                "best-individual-distance": 65593.7500463203,
                "worst-individual-sequence": [6, 3, 7, 26, 5, 25, 4, 1, 17, 23, 27, 12, 21, 20, 15, 8, 22, 18, 11, 2, 10, 14, 28, 16, 24, 9, 29, 13, 19],
                "worst-individual-distance": 106569.55710649854,
                "average-distance": 96734.84886120186,
                "individual-distances": []
            }, {
                "best-individual-sequence": [18, 19, 14, 2, 1, 13, 9, 4, 5, 7, 11, 10, 6, 8, 12, 16, 3, 17, 26, 25, 21, 29, 23, 20, 24, 28, 27, 15, 22],
                "best-individual-distance": 65593.7500463203,
                "worst-individual-sequence": [20, 9, 13, 21, 14, 12, 27, 22, 25, 28, 4, 24, 17, 29, 8, 15, 18, 19, 10, 26, 5, 16, 7, 3, 1, 6, 2, 23, 11],
                "worst-individual-distance": 104407.22769094682,
                "average-distance": 94847.49301981225,
                "individual-distances": []
            }, {
                "best-individual-sequence": [18, 19, 14, 2, 1, 13, 9, 4, 5, 7, 11, 10, 6, 8, 12, 16, 3, 17, 26, 25, 21, 29, 23, 20, 24, 28, 27, 15, 22],
                "best-individual-distance": 65593.7500463203,
                "worst-individual-sequence": [11, 12, 2, 6, 20, 10, 22, 14, 5, 4, 28, 24, 23, 8, 21, 18, 16, 1, 26, 29, 17, 9, 3, 15, 13, 25, 27, 19, 7],
                "worst-individual-distance": 102090.67371771255,
                "average-distance": 92998.87408764783,
                "individual-distances": []
            }, {
                "best-individual-sequence": [18, 19, 14, 2, 1, 13, 9, 4, 5, 7, 11, 10, 6, 8, 12, 16, 3, 17, 26, 25, 21, 29, 23, 20, 24, 28, 27, 15, 22],
                "best-individual-distance": 65593.7500463203,
                "worst-individual-sequence": [17, 27, 10, 13, 2, 19, 29, 28, 15, 11, 21, 22, 3, 1, 26, 18, 9, 5, 14, 23, 20, 6, 12, 4, 7, 24, 25, 16, 8],
                "worst-individual-distance": 100218.89568877383,
                "average-distance": 91249.57234707118,
                "individual-distances": []
            }, {
                "best-individual-sequence": [15, 22, 26, 20, 24, 16, 25, 27, 4, 23, 29, 9, 5, 6, 13, 2, 1, 11, 18, 28, 19, 21, 14, 12, 8, 3, 7, 10, 17],
                "best-individual-distance": 63798.54390988589,
                "worst-individual-sequence": [7, 5, 21, 24, 18, 23, 19, 22, 14, 9, 17, 26, 8, 13, 28, 16, 10, 20, 6, 12, 11, 2, 3, 1, 15, 4, 25, 27, 29],
                "worst-individual-distance": 98329.34610229466,
                "average-distance": 89677.40809526198,
                "individual-distances": []
            }, {
                "best-individual-sequence": [15, 22, 26, 20, 24, 16, 25, 27, 4, 23, 29, 9, 5, 6, 13, 2, 1, 11, 18, 28, 19, 21, 14, 12, 8, 3, 7, 10, 17],
                "best-individual-distance": 63798.54390988589,
                "worst-individual-sequence": [8, 6, 13, 19, 10, 11, 18, 29, 15, 3, 2, 12, 20, 26, 24, 23, 14, 9, 28, 17, 4, 5, 21, 1, 27, 25, 16, 7, 22],
                "worst-individual-distance": 96609.41817997751,
                "average-distance": 88049.92153291161,
                "individual-distances": []
            }, {
                "best-individual-sequence": [16, 24, 27, 25, 23, 22, 19, 15, 18, 3, 10, 6, 4, 28, 12, 11, 13, 7, 1, 8, 14, 17, 21, 20, 2, 5, 9, 29, 26],
                "best-individual-distance": 62552.35228707347,
                "worst-individual-sequence": [26, 27, 15, 9, 1, 13, 22, 29, 19, 16, 10, 24, 21, 14, 2, 3, 11, 4, 5, 12, 7, 8, 17, 6, 25, 18, 28, 23, 20],
                "worst-individual-distance": 94729.9392787827,
                "average-distance": 86388.21610361844,
                "individual-distances": []
            }, {
                "best-individual-sequence": [13, 2, 1, 4, 21, 15, 19, 18, 23, 11, 6, 3, 12, 24, 20, 29, 22, 17, 26, 16, 27, 25, 28, 14, 9, 8, 7, 5, 10],
                "best-individual-distance": 61719.288934902754,
                "worst-individual-sequence": [17, 26, 7, 27, 16, 14, 22, 15, 25, 24, 12, 8, 29, 23, 6, 1, 9, 3, 18, 20, 28, 5, 10, 4, 13, 2, 19, 21, 11],
                "worst-individual-distance": 92959.32441030248,
                "average-distance": 84902.16674883741,
                "individual-distances": []
            }, {
                "best-individual-sequence": [13, 2, 1, 4, 21, 15, 19, 18, 23, 11, 6, 3, 12, 24, 20, 29, 22, 17, 26, 16, 27, 25, 28, 14, 9, 8, 7, 5, 10],
                "best-individual-distance": 61719.288934902754,
                "worst-individual-sequence": [5, 4, 15, 22, 20, 3, 9, 28, 26, 17, 18, 19, 23, 6, 13, 24, 25, 29, 2, 10, 1, 27, 16, 12, 21, 11, 7, 8, 14],
                "worst-individual-distance": 91347.04672035085,
                "average-distance": 83540.64840948679,
                "individual-distances": []
            }, {
                "best-individual-sequence": [13, 2, 1, 4, 21, 15, 19, 18, 23, 11, 6, 3, 12, 24, 20, 29, 22, 17, 26, 16, 27, 25, 28, 14, 9, 8, 7, 5, 10],
                "best-individual-distance": 61719.288934902754,
                "worst-individual-sequence": [1, 6, 10, 14, 15, 22, 26, 20, 24, 16, 3, 28, 13, 25, 27, 9, 8, 7, 23, 29, 4, 5, 19, 11, 12, 17, 21, 2, 18],
                "worst-individual-distance": 89739.45596597869,
                "average-distance": 82361.17626257704,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 21, 14, 8, 7, 22, 1, 4, 13, 11, 6, 3, 12, 24, 20, 29, 2, 17, 26, 25, 27, 10, 28, 18, 15, 5, 9, 16, 19],
                "best-individual-distance": 61500.26653940661,
                "worst-individual-sequence": [6, 20, 25, 1, 5, 10, 13, 23, 4, 2, 9, 11, 28, 22, 21, 29, 27, 18, 3, 12, 7, 14, 19, 15, 24, 17, 16, 26, 8],
                "worst-individual-distance": 88242.11378951276,
                "average-distance": 81118.67018959546,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 21, 14, 8, 7, 22, 1, 4, 13, 11, 6, 3, 12, 24, 20, 29, 2, 17, 26, 25, 27, 10, 28, 18, 15, 5, 9, 16, 19],
                "best-individual-distance": 61500.26653940661,
                "worst-individual-sequence": [12, 10, 13, 2, 6, 29, 28, 15, 11, 18, 27, 9, 5, 14, 26, 21, 17, 22, 23, 1, 20, 19, 4, 7, 24, 25, 16, 3, 8],
                "worst-individual-distance": 87090.49297025312,
                "average-distance": 80058.45999705173,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 21, 14, 8, 7, 22, 1, 4, 13, 11, 6, 3, 12, 24, 20, 29, 2, 17, 26, 25, 27, 10, 28, 18, 15, 5, 9, 16, 19],
                "best-individual-distance": 61500.26653940661,
                "worst-individual-sequence": [26, 17, 1, 5, 2, 7, 3, 8, 20, 18, 15, 23, 11, 9, 6, 12, 14, 28, 27, 22, 19, 16, 4, 13, 29, 24, 25, 10, 21],
                "worst-individual-distance": 85535.74203487956,
                "average-distance": 78865.45896923984,
                "individual-distances": []
            }, {
                "best-individual-sequence": [28, 11, 21, 29, 18, 12, 15, 22, 26, 14, 20, 23, 19, 25, 16, 24, 17, 13, 7, 8, 5, 9, 3, 4, 10, 1, 2, 6, 27],
                "best-individual-distance": 56428.12919158049,
                "worst-individual-sequence": [2, 10, 11, 1, 3, 9, 7, 23, 5, 26, 4, 12, 6, 22, 21, 19, 14, 13, 16, 20, 28, 8, 15, 27, 24, 25, 18, 29, 17],
                "worst-individual-distance": 84158.99210221003,
                "average-distance": 77720.32442274595,
                "individual-distances": []
            }, {
                "best-individual-sequence": [28, 11, 21, 29, 18, 12, 15, 22, 26, 14, 20, 23, 19, 25, 16, 24, 17, 13, 7, 8, 5, 9, 3, 4, 10, 1, 2, 6, 27],
                "best-individual-distance": 56428.12919158049,
                "worst-individual-sequence": [10, 2, 28, 18, 20, 15, 5, 4, 9, 16, 19, 7, 22, 23, 24, 21, 14, 8, 13, 26, 17, 25, 27, 29, 11, 6, 1, 12, 3],
                "worst-individual-distance": 82882.92469341267,
                "average-distance": 76839.48308327804,
                "individual-distances": []
            }, {
                "best-individual-sequence": [28, 11, 21, 29, 18, 12, 15, 22, 26, 14, 20, 23, 19, 25, 16, 24, 17, 13, 7, 8, 5, 9, 3, 4, 10, 1, 2, 6, 27],
                "best-individual-distance": 56428.12919158049,
                "worst-individual-sequence": [10, 12, 17, 14, 19, 29, 28, 15, 11, 21, 22, 3, 1, 18, 23, 16, 24, 27, 4, 6, 26, 25, 20, 5, 9, 7, 8, 2, 13],
                "worst-individual-distance": 82079.97384136933,
                "average-distance": 75954.74597130506,
                "individual-distances": []
            }, {
                "best-individual-sequence": [28, 11, 21, 29, 18, 12, 15, 22, 26, 14, 20, 23, 19, 25, 16, 24, 17, 13, 7, 8, 5, 9, 3, 4, 10, 1, 2, 6, 27],
                "best-individual-distance": 56428.12919158049,
                "worst-individual-sequence": [13, 23, 6, 1, 12, 29, 26, 17, 14, 2, 18, 22, 15, 24, 25, 28, 20, 5, 7, 8, 9, 4, 3, 11, 19, 27, 16, 21, 10],
                "worst-individual-distance": 81062.84187191227,
                "average-distance": 75087.56649660884,
                "individual-distances": []
            }, {
                "best-individual-sequence": [28, 11, 21, 29, 18, 12, 15, 22, 26, 14, 20, 23, 19, 25, 16, 24, 17, 13, 7, 8, 5, 9, 3, 4, 10, 1, 2, 6, 27],
                "best-individual-distance": 56428.12919158049,
                "worst-individual-sequence": [1, 27, 28, 26, 17, 16, 23, 6, 2, 9, 12, 3, 4, 15, 18, 22, 25, 20, 14, 8, 7, 5, 19, 13, 29, 24, 21, 11, 10],
                "worst-individual-distance": 80299.8915255648,
                "average-distance": 74294.328608518,
                "individual-distances": []
            }, {
                "best-individual-sequence": [28, 11, 21, 29, 18, 12, 15, 22, 26, 14, 20, 23, 19, 25, 16, 24, 17, 13, 7, 8, 5, 9, 3, 4, 10, 1, 2, 6, 27],
                "best-individual-distance": 56428.12919158049,
                "worst-individual-sequence": [27, 26, 16, 28, 17, 12, 15, 24, 7, 3, 8, 13, 29, 20, 18, 9, 14, 25, 23, 1, 4, 5, 19, 11, 6, 2, 10, 21, 22],
                "worst-individual-distance": 79335.91112455896,
                "average-distance": 73489.99093904781,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 29, 16, 13, 9, 12, 2, 1, 6, 5, 4, 3, 7, 8, 10, 11, 18, 15, 28, 21, 26, 22, 27, 24, 14, 20, 23, 19, 25],
                "best-individual-distance": 51635.93687393007,
                "worst-individual-sequence": [5, 9, 3, 4, 7, 12, 2, 16, 22, 23, 27, 1, 11, 18, 24, 28, 19, 21, 14, 8, 13, 26, 17, 29, 20, 25, 15, 10, 6],
                "worst-individual-distance": 78398.7890713103,
                "average-distance": 72756.26252698686,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 29, 16, 13, 9, 12, 2, 1, 6, 5, 4, 3, 7, 8, 10, 11, 18, 15, 28, 21, 26, 22, 27, 24, 14, 20, 23, 19, 25],
                "best-individual-distance": 51635.93687393007,
                "worst-individual-sequence": [25, 28, 9, 24, 15, 3, 5, 6, 2, 4, 7, 10, 12, 16, 18, 19, 29, 22, 20, 23, 21, 26, 27, 11, 14, 13, 1, 8, 17],
                "worst-individual-distance": 77540.7111107125,
                "average-distance": 71948.27137375821,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 29, 16, 13, 9, 12, 2, 1, 6, 5, 4, 3, 7, 8, 10, 11, 18, 15, 28, 21, 26, 22, 27, 24, 14, 20, 23, 19, 25],
                "best-individual-distance": 51635.93687393007,
                "worst-individual-sequence": [19, 18, 4, 11, 10, 6, 27, 26, 21, 23, 13, 17, 9, 8, 12, 28, 20, 7, 3, 14, 2, 1, 5, 16, 24, 15, 25, 29, 22],
                "worst-individual-distance": 76601.51557320727,
                "average-distance": 71243.7464845071,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 29, 16, 13, 9, 12, 2, 1, 6, 5, 4, 3, 7, 8, 10, 11, 18, 15, 28, 21, 26, 22, 27, 24, 14, 20, 23, 19, 25],
                "best-individual-distance": 51635.93687393007,
                "worst-individual-sequence": [29, 22, 23, 15, 10, 2, 1, 11, 18, 24, 25, 20, 14, 13, 28, 19, 21, 8, 27, 12, 6, 3, 5, 17, 7, 4, 9, 26, 16],
                "worst-individual-distance": 75687.33453826026,
                "average-distance": 70588.25888554683,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 29, 16, 13, 9, 12, 2, 1, 6, 5, 4, 3, 7, 8, 10, 11, 18, 15, 28, 21, 26, 22, 27, 24, 14, 20, 23, 19, 25],
                "best-individual-distance": 51635.93687393007,
                "worst-individual-sequence": [2, 6, 19, 24, 20, 29, 15, 23, 26, 17, 28, 22, 21, 12, 3, 18, 7, 16, 27, 25, 4, 14, 9, 8, 13, 11, 1, 5, 10],
                "worst-individual-distance": 74845.88821243634,
                "average-distance": 69927.75768071266,
                "individual-distances": []
            }, {
                "best-individual-sequence": [25, 23, 22, 19, 15, 18, 5, 4, 12, 11, 7, 8, 14, 17, 29, 21, 20, 28, 13, 10, 6, 2, 1, 3, 9, 26, 16, 24, 27],
                "best-individual-distance": 50870.59237017501,
                "worst-individual-sequence": [6, 10, 13, 12, 22, 26, 20, 24, 16, 3, 28, 25, 27, 8, 7, 9, 23, 29, 21, 19, 11, 2, 1, 5, 15, 4, 17, 14, 18],
                "worst-individual-distance": 74142.60513914298,
                "average-distance": 69308.25303803838,
                "individual-distances": []
            }, {
                "best-individual-sequence": [25, 23, 22, 19, 15, 18, 5, 4, 12, 11, 7, 8, 14, 17, 29, 21, 20, 28, 13, 10, 6, 2, 1, 3, 9, 26, 16, 24, 27],
                "best-individual-distance": 50870.59237017501,
                "worst-individual-sequence": [5, 20, 15, 22, 13, 9, 12, 2, 1, 6, 8, 7, 4, 11, 18, 28, 26, 27, 24, 10, 29, 19, 21, 14, 3, 17, 23, 25, 16],
                "worst-individual-distance": 73425.35269233906,
                "average-distance": 68762.75300890164,
                "individual-distances": []
            }, {
                "best-individual-sequence": [25, 23, 22, 19, 15, 18, 5, 4, 12, 11, 7, 8, 14, 17, 29, 21, 20, 28, 13, 10, 6, 2, 1, 3, 9, 26, 16, 24, 27],
                "best-individual-distance": 50870.59237017501,
                "worst-individual-sequence": [28, 20, 24, 13, 25, 7, 15, 16, 3, 12, 18, 21, 17, 14, 19, 29, 23, 27, 8, 9, 11, 10, 1, 6, 2, 5, 4, 22, 26],
                "worst-individual-distance": 72809.05262488854,
                "average-distance": 68098.13302986855,
                "individual-distances": []
            }, {
                "best-individual-sequence": [25, 23, 22, 19, 15, 18, 5, 4, 12, 11, 7, 8, 14, 17, 29, 21, 20, 28, 13, 10, 6, 2, 1, 3, 9, 26, 16, 24, 27],
                "best-individual-distance": 50870.59237017501,
                "worst-individual-sequence": [9, 7, 8, 1, 2, 13, 15, 16, 3, 12, 18, 21, 17, 14, 19, 29, 23, 27, 28, 11, 6, 4, 10, 26, 25, 20, 24, 22, 5],
                "worst-individual-distance": 72113.99173673657,
                "average-distance": 67493.34077784534,
                "individual-distances": []
            }, {
                "best-individual-sequence": [25, 23, 22, 19, 15, 18, 5, 4, 12, 11, 7, 8, 14, 17, 29, 21, 20, 28, 13, 10, 6, 2, 1, 3, 9, 26, 16, 24, 27],
                "best-individual-distance": 50870.59237017501,
                "worst-individual-sequence": [4, 7, 8, 10, 12, 9, 28, 18, 29, 26, 17, 14, 6, 3, 13, 24, 25, 22, 16, 1, 2, 5, 19, 23, 20, 27, 21, 15, 11],
                "worst-individual-distance": 71538.35554609001,
                "average-distance": 66888.06198901878,
                "individual-distances": []
            }, {
                "best-individual-sequence": [22, 23, 29, 15, 19, 17, 9, 3, 7, 8, 10, 13, 4, 11, 14, 28, 21, 26, 20, 16, 27, 25, 24, 5, 2, 1, 6, 12, 18],
                "best-individual-distance": 50742.83722125702,
                "worst-individual-sequence": [3, 5, 7, 4, 6, 23, 18, 22, 17, 25, 20, 27, 29, 15, 24, 28, 19, 21, 14, 8, 13, 26, 16, 1, 12, 10, 2, 11, 9],
                "worst-individual-distance": 70977.56103971454,
                "average-distance": 66375.43864592859,
                "individual-distances": []
            }, {
                "best-individual-sequence": [22, 23, 29, 15, 19, 17, 9, 3, 7, 8, 10, 13, 4, 11, 14, 28, 21, 26, 20, 16, 27, 25, 24, 5, 2, 1, 6, 12, 18],
                "best-individual-distance": 50742.83722125702,
                "worst-individual-sequence": [9, 7, 8, 1, 2, 13, 15, 16, 3, 12, 18, 21, 17, 14, 19, 29, 23, 27, 28, 11, 6, 4, 10, 26, 25, 20, 24, 22, 5],
                "worst-individual-distance": 70365.2188838351,
                "average-distance": 65758.89693660555,
                "individual-distances": []
            }, {
                "best-individual-sequence": [22, 23, 29, 15, 19, 17, 9, 3, 7, 8, 10, 13, 4, 11, 14, 28, 21, 26, 20, 16, 27, 25, 24, 5, 2, 1, 6, 12, 18],
                "best-individual-distance": 50742.83722125702,
                "worst-individual-sequence": [18, 19, 14, 3, 1, 13, 9, 4, 5, 7, 11, 10, 6, 8, 12, 16, 17, 2, 21, 29, 23, 20, 24, 26, 25, 28, 27, 15, 22],
                "worst-individual-distance": 69789.5110625706,
                "average-distance": 65146.915185289094,
                "individual-distances": []
            }, {
                "best-individual-sequence": [28, 19, 15, 29, 22, 14, 26, 16, 20, 24, 27, 25, 21, 23, 18, 17, 13, 8, 11, 12, 3, 9, 10, 2, 1, 6, 4, 5, 7],
                "best-individual-distance": 48681.00838949393,
                "worst-individual-sequence": [26, 10, 17, 21, 18, 5, 11, 6, 8, 12, 3, 1, 2, 25, 16, 20, 24, 22, 29, 15, 19, 23, 14, 7, 4, 9, 13, 28, 27],
                "worst-individual-distance": 69324.90380163754,
                "average-distance": 64610.07251105118,
                "individual-distances": []
            }, {
                "best-individual-sequence": [28, 19, 15, 29, 22, 14, 26, 16, 20, 24, 27, 25, 21, 23, 18, 17, 13, 8, 11, 12, 3, 9, 10, 2, 1, 6, 4, 5, 7],
                "best-individual-distance": 48681.00838949393,
                "worst-individual-sequence": [14, 1, 4, 11, 15, 19, 18, 23, 21, 3, 12, 20, 29, 22, 17, 26, 16, 27, 25, 24, 9, 28, 5, 6, 2, 10, 13, 7, 8],
                "worst-individual-distance": 68850.7244982794,
                "average-distance": 64116.73300989785,
                "individual-distances": []
            }, {
                "best-individual-sequence": [28, 19, 15, 29, 22, 14, 26, 16, 20, 24, 27, 25, 21, 23, 18, 17, 13, 8, 11, 12, 3, 9, 10, 2, 1, 6, 4, 5, 7],
                "best-individual-distance": 48681.00838949393,
                "worst-individual-sequence": [8, 3, 1, 7, 22, 25, 17, 28, 27, 20, 15, 10, 12, 16, 24, 26, 13, 9, 23, 29, 21, 19, 18, 14, 11, 2, 4, 5, 6],
                "worst-individual-distance": 68335.79198140325,
                "average-distance": 63486.85745887638,
                "individual-distances": []
            }, {
                "best-individual-sequence": [28, 19, 15, 29, 22, 14, 26, 16, 20, 24, 27, 25, 21, 23, 18, 17, 13, 8, 11, 12, 3, 9, 10, 2, 1, 6, 4, 5, 7],
                "best-individual-distance": 48681.00838949393,
                "worst-individual-sequence": [21, 10, 1, 16, 5, 6, 2, 3, 9, 14, 12, 7, 4, 11, 17, 20, 28, 25, 27, 24, 29, 26, 23, 22, 15, 19, 18, 13, 8],
                "worst-individual-distance": 67636.4540277576,
                "average-distance": 62926.80711593444,
                "individual-distances": []
            }, {
                "best-individual-sequence": [28, 19, 15, 29, 22, 14, 26, 16, 20, 24, 27, 25, 21, 23, 18, 17, 13, 8, 11, 12, 3, 9, 10, 2, 1, 6, 4, 5, 7],
                "best-individual-distance": 48681.00838949393,
                "worst-individual-sequence": [24, 17, 22, 12, 9, 5, 2, 6, 1, 3, 29, 19, 18, 27, 7, 8, 10, 13, 4, 11, 14, 28, 21, 15, 20, 26, 23, 25, 16],
                "worst-individual-distance": 66928.27875628875,
                "average-distance": 62341.37839958535,
                "individual-distances": []
            }, {
                "best-individual-sequence": [28, 19, 15, 29, 22, 14, 26, 16, 20, 24, 27, 25, 21, 23, 18, 17, 13, 8, 11, 12, 3, 9, 10, 2, 1, 6, 4, 5, 7],
                "best-individual-distance": 48681.00838949393,
                "worst-individual-sequence": [3, 5, 7, 4, 28, 14, 17, 27, 29, 20, 26, 23, 19, 25, 16, 24, 21, 13, 12, 6, 10, 11, 9, 2, 1, 22, 15, 18, 8],
                "worst-individual-distance": 66326.71510091228,
                "average-distance": 61828.780194118146,
                "individual-distances": []
            }, {
                "best-individual-sequence": [28, 19, 15, 29, 22, 14, 26, 16, 20, 24, 27, 25, 21, 23, 18, 17, 13, 8, 11, 12, 3, 9, 10, 2, 1, 6, 4, 5, 7],
                "best-individual-distance": 48681.00838949393,
                "worst-individual-sequence": [7, 8, 1, 2, 13, 15, 10, 12, 18, 21, 14, 16, 24, 17, 19, 29, 23, 27, 28, 25, 6, 4, 3, 5, 11, 20, 22, 26, 9],
                "worst-individual-distance": 65827.40508838586,
                "average-distance": 61291.56634908057,
                "individual-distances": []
            }, {
                "best-individual-sequence": [28, 19, 15, 29, 22, 14, 26, 16, 20, 24, 27, 25, 21, 23, 18, 17, 13, 8, 11, 12, 3, 9, 10, 2, 1, 6, 4, 5, 7],
                "best-individual-distance": 48681.00838949393,
                "worst-individual-sequence": [28, 11, 21, 29, 18, 12, 15, 22, 26, 14, 20, 23, 19, 25, 16, 24, 17, 13, 7, 8, 5, 9, 3, 4, 10, 1, 2, 6, 27],
                "worst-individual-distance": 65272.94693912508,
                "average-distance": 60701.849336620784,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 17, 14, 19, 9, 1, 6, 5, 4, 3, 7, 8, 10, 11, 18, 15, 28, 21, 23, 22, 2, 13, 12, 29, 26, 16, 24, 25, 27],
                "best-individual-distance": 45536.4234215424,
                "worst-individual-sequence": [7, 5, 1, 2, 13, 15, 10, 12, 18, 21, 14, 16, 24, 17, 19, 29, 23, 27, 28, 26, 6, 4, 3, 11, 25, 20, 22, 9, 8],
                "worst-individual-distance": 64634.630137695196,
                "average-distance": 60177.69285575673,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 17, 14, 19, 9, 1, 6, 5, 4, 3, 7, 8, 10, 11, 18, 15, 28, 21, 23, 22, 2, 13, 12, 29, 26, 16, 24, 25, 27],
                "best-individual-distance": 45536.4234215424,
                "worst-individual-sequence": [15, 18, 8, 11, 1, 9, 5, 6, 10, 4, 2, 12, 13, 7, 14, 17, 21, 20, 28, 16, 3, 27, 24, 26, 25, 29, 23, 22, 19],
                "worst-individual-distance": 64030.95529634433,
                "average-distance": 59666.05971353886,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 17, 14, 19, 9, 1, 6, 5, 4, 3, 7, 8, 10, 11, 18, 15, 28, 21, 23, 22, 2, 13, 12, 29, 26, 16, 24, 25, 27],
                "best-individual-distance": 45536.4234215424,
                "worst-individual-sequence": [19, 25, 24, 20, 14, 17, 28, 3, 2, 4, 7, 10, 12, 16, 18, 15, 29, 22, 23, 21, 26, 27, 11, 9, 13, 8, 6, 1, 5],
                "worst-individual-distance": 63302.3397396211,
                "average-distance": 59135.13830654738,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 17, 14, 19, 9, 1, 6, 5, 4, 3, 7, 8, 10, 11, 18, 15, 28, 21, 23, 22, 2, 13, 12, 29, 26, 16, 24, 25, 27],
                "best-individual-distance": 45536.4234215424,
                "worst-individual-sequence": [1, 29, 14, 13, 9, 4, 5, 7, 11, 10, 6, 8, 12, 16, 3, 2, 17, 26, 25, 27, 24, 28, 18, 15, 20, 19, 23, 21, 22],
                "worst-individual-distance": 62603.41069898917,
                "average-distance": 58685.07031575435,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 17, 14, 19, 9, 1, 6, 5, 4, 3, 7, 8, 10, 11, 18, 15, 28, 21, 23, 22, 2, 13, 12, 29, 26, 16, 24, 25, 27],
                "best-individual-distance": 45536.4234215424,
                "worst-individual-sequence": [11, 3, 9, 10, 2, 1, 6, 8, 21, 29, 23, 13, 12, 16, 18, 19, 22, 17, 26, 27, 25, 24, 20, 7, 15, 28, 14, 4, 5],
                "worst-individual-distance": 62112.62292550532,
                "average-distance": 58206.953372086,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 17, 14, 19, 9, 1, 6, 5, 4, 3, 7, 8, 10, 11, 18, 15, 28, 21, 23, 22, 2, 13, 12, 29, 26, 16, 24, 25, 27],
                "best-individual-distance": 45536.4234215424,
                "worst-individual-sequence": [23, 13, 3, 12, 22, 26, 17, 21, 20, 16, 25, 27, 24, 28, 18, 14, 11, 10, 19, 15, 9, 5, 4, 6, 1, 29, 8, 2, 7],
                "worst-individual-distance": 61716.73646263805,
                "average-distance": 57777.16464158606,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 17, 14, 19, 9, 1, 6, 5, 4, 3, 7, 8, 10, 11, 18, 15, 28, 21, 23, 22, 2, 13, 12, 29, 26, 16, 24, 25, 27],
                "best-individual-distance": 45536.4234215424,
                "worst-individual-sequence": [8, 1, 2, 13, 12, 15, 10, 18, 21, 14, 17, 29, 23, 28, 16, 6, 4, 3, 5, 11, 26, 27, 25, 24, 19, 22, 20, 9, 7],
                "worst-individual-distance": 61179.385829280734,
                "average-distance": 57279.456129279555,
                "individual-distances": []
            }, {
                "best-individual-sequence": [13, 9, 3, 6, 4, 8, 21, 16, 24, 25, 27, 20, 17, 14, 28, 18, 26, 29, 23, 22, 19, 15, 11, 10, 1, 2, 5, 7, 12],
                "best-individual-distance": 45372.45919333912,
                "worst-individual-sequence": [4, 7, 10, 11, 2, 15, 28, 20, 27, 16, 24, 9, 3, 8, 13, 12, 29, 21, 26, 22, 14, 23, 25, 17, 19, 18, 1, 6, 5],
                "worst-individual-distance": 60708.645507826164,
                "average-distance": 56817.11226324043,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 6, 11, 12, 8, 4, 5, 3, 2, 9, 17, 26, 21, 29, 23, 18, 19, 15, 14, 16, 27, 25, 24, 20, 28, 22, 13, 7, 10],
                "best-individual-distance": 45004.806691163736,
                "worst-individual-sequence": [26, 27, 25, 22, 21, 20, 28, 10, 6, 4, 12, 13, 7, 8, 14, 17, 16, 23, 29, 19, 11, 2, 1, 5, 3, 9, 24, 15, 18],
                "worst-individual-distance": 60118.13606303769,
                "average-distance": 56378.48984590063,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 6, 11, 12, 8, 4, 5, 3, 2, 9, 17, 26, 21, 29, 23, 18, 19, 15, 14, 16, 27, 25, 24, 20, 28, 22, 13, 7, 10],
                "best-individual-distance": 45004.806691163736,
                "worst-individual-sequence": [18, 21, 2, 11, 13, 7, 1, 8, 4, 5, 3, 10, 9, 6, 12, 14, 17, 20, 28, 25, 16, 27, 24, 29, 26, 23, 22, 19, 15],
                "worst-individual-distance": 59667.75093263477,
                "average-distance": 55919.81096306296,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 6, 11, 12, 8, 4, 5, 3, 2, 9, 17, 26, 21, 29, 23, 18, 19, 15, 14, 16, 27, 25, 24, 20, 28, 22, 13, 7, 10],
                "best-individual-distance": 45004.806691163736,
                "worst-individual-sequence": [14, 26, 17, 3, 7, 9, 15, 13, 12, 22, 18, 21, 27, 25, 16, 20, 8, 5, 10, 1, 2, 6, 4, 11, 23, 29, 24, 28, 19],
                "worst-individual-distance": 59172.351868354635,
                "average-distance": 55537.73459213537,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 6, 11, 12, 8, 4, 5, 3, 2, 9, 17, 26, 21, 29, 23, 18, 19, 15, 14, 16, 27, 25, 24, 20, 28, 22, 13, 7, 10],
                "best-individual-distance": 45004.806691163736,
                "worst-individual-sequence": [5, 1, 6, 2, 21, 12, 7, 22, 17, 26, 16, 27, 25, 24, 20, 28, 14, 3, 4, 11, 10, 13, 9, 19, 15, 18, 23, 29, 8],
                "worst-individual-distance": 58589.45410445786,
                "average-distance": 55130.52849036684,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 6, 11, 12, 8, 4, 5, 3, 2, 9, 17, 26, 21, 29, 23, 18, 19, 15, 14, 16, 27, 25, 24, 20, 28, 22, 13, 7, 10],
                "best-individual-distance": 45004.806691163736,
                "worst-individual-sequence": [29, 21, 3, 10, 13, 9, 12, 2, 1, 6, 8, 7, 19, 23, 22, 17, 26, 16, 27, 25, 24, 20, 28, 14, 4, 5, 11, 18, 15],
                "worst-individual-distance": 58212.93811535632,
                "average-distance": 54765.11844831,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 6, 11, 12, 8, 4, 5, 3, 2, 9, 17, 26, 21, 29, 23, 18, 19, 15, 14, 16, 27, 25, 24, 20, 28, 22, 13, 7, 10],
                "best-individual-distance": 45004.806691163736,
                "worst-individual-sequence": [12, 18, 16, 22, 17, 26, 23, 28, 29, 20, 24, 25, 27, 21, 19, 15, 5, 1, 11, 14, 13, 8, 9, 3, 6, 4, 7, 2, 10],
                "worst-individual-distance": 57918.34955274257,
                "average-distance": 54457.71767719014,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 11, 18, 22, 16, 26, 23, 28, 29, 20, 24, 25, 27, 21, 19, 15, 14, 13, 9, 17, 12, 2, 1, 6, 5, 4, 3, 7, 8],
                "best-individual-distance": 44787.28950556887,
                "worst-individual-sequence": [19, 14, 18, 22, 17, 26, 23, 28, 29, 20, 24, 16, 7, 8, 13, 25, 27, 21, 3, 9, 10, 2, 1, 4, 5, 6, 11, 15, 12],
                "worst-individual-distance": 57576.31066094997,
                "average-distance": 54040.63025900949,
                "individual-distances": []
            }, {
                "best-individual-sequence": [8, 5, 3, 9, 17, 26, 21, 29, 23, 18, 19, 14, 16, 27, 25, 24, 20, 28, 22, 4, 11, 10, 1, 2, 6, 15, 13, 7, 12],
                "best-individual-distance": 41723.150653027675,
                "worst-individual-sequence": [25, 23, 22, 19, 20, 27, 16, 24, 3, 8, 7, 4, 12, 15, 13, 29, 9, 5, 11, 6, 1, 2, 10, 18, 21, 17, 14, 28, 26],
                "worst-individual-distance": 57202.45635367373,
                "average-distance": 53677.3401729074,
                "individual-distances": []
            }, {
                "best-individual-sequence": [8, 5, 3, 9, 17, 26, 21, 29, 23, 18, 19, 14, 16, 27, 25, 24, 20, 28, 22, 4, 11, 10, 1, 2, 6, 15, 13, 7, 12],
                "best-individual-distance": 41723.150653027675,
                "worst-individual-sequence": [26, 21, 29, 23, 18, 19, 6, 5, 4, 3, 7, 8, 10, 11, 2, 15, 28, 14, 16, 27, 25, 24, 20, 22, 12, 1, 13, 9, 17],
                "worst-individual-distance": 56729.11293796559,
                "average-distance": 53329.22609076096,
                "individual-distances": []
            }, {
                "best-individual-sequence": [8, 5, 3, 9, 17, 26, 21, 29, 23, 18, 19, 14, 16, 27, 25, 24, 20, 28, 22, 4, 11, 10, 1, 2, 6, 15, 13, 7, 12],
                "best-individual-distance": 41723.150653027675,
                "worst-individual-sequence": [15, 18, 28, 13, 3, 9, 4, 5, 7, 11, 10, 6, 8, 12, 14, 17, 20, 16, 23, 29, 21, 19, 2, 1, 27, 25, 24, 26, 22],
                "worst-individual-distance": 56237.924453959575,
                "average-distance": 52963.387907202385,
                "individual-distances": []
            }, {
                "best-individual-sequence": [8, 5, 3, 9, 17, 26, 21, 29, 23, 18, 19, 14, 16, 27, 25, 24, 20, 28, 22, 4, 11, 10, 1, 2, 6, 15, 13, 7, 12],
                "best-individual-distance": 41723.150653027675,
                "worst-individual-sequence": [26, 16, 28, 29, 20, 24, 25, 27, 21, 19, 14, 6, 4, 7, 8, 13, 3, 9, 2, 1, 10, 5, 11, 15, 18, 12, 23, 22, 17],
                "worst-individual-distance": 55832.12019350047,
                "average-distance": 52636.04529322308,
                "individual-distances": []
            }, {
                "best-individual-sequence": [8, 5, 3, 9, 17, 26, 21, 29, 23, 18, 19, 14, 16, 27, 25, 24, 20, 28, 22, 4, 11, 10, 1, 2, 6, 15, 13, 7, 12],
                "best-individual-distance": 41723.150653027675,
                "worst-individual-sequence": [23, 22, 19, 15, 20, 16, 9, 3, 8, 13, 12, 18, 28, 26, 27, 24, 29, 7, 5, 4, 11, 6, 1, 2, 10, 21, 17, 14, 25],
                "worst-individual-distance": 55547.97039318018,
                "average-distance": 52318.12022554799,
                "individual-distances": []
            }, {
                "best-individual-sequence": [8, 5, 3, 9, 17, 26, 21, 29, 23, 18, 19, 14, 16, 27, 25, 24, 20, 28, 22, 4, 11, 10, 1, 2, 6, 15, 13, 7, 12],
                "best-individual-distance": 41723.150653027675,
                "worst-individual-sequence": [4, 9, 12, 1, 6, 5, 3, 7, 8, 10, 11, 18, 16, 27, 24, 14, 25, 29, 23, 22, 19, 15, 13, 17, 21, 20, 28, 26, 2],
                "worst-individual-distance": 55116.62456366067,
                "average-distance": 52002.7306484545,
                "individual-distances": []
            }, {
                "best-individual-sequence": [8, 5, 3, 9, 17, 26, 21, 29, 23, 18, 19, 14, 16, 27, 25, 24, 20, 28, 22, 4, 11, 10, 1, 2, 6, 15, 13, 7, 12],
                "best-individual-distance": 41723.150653027675,
                "worst-individual-sequence": [5, 6, 11, 13, 14, 9, 23, 22, 17, 26, 16, 27, 25, 24, 20, 18, 19, 15, 28, 10, 2, 1, 4, 12, 29, 21, 7, 3, 8],
                "worst-individual-distance": 54822.8364267098,
                "average-distance": 51722.911403151644,
                "individual-distances": []
            }, {
                "best-individual-sequence": [29, 21, 19, 14, 13, 8, 3, 7, 9, 4, 10, 1, 2, 5, 6, 11, 12, 17, 26, 16, 27, 25, 24, 20, 28, 15, 18, 23, 22],
                "best-individual-distance": 41061.67477593799,
                "worst-individual-sequence": [3, 15, 18, 10, 13, 9, 12, 2, 1, 6, 8, 7, 21, 29, 19, 23, 22, 17, 26, 16, 27, 25, 24, 20, 28, 14, 4, 5, 11],
                "worst-individual-distance": 54496.65796310566,
                "average-distance": 51424.65372596031,
                "individual-distances": []
            }, {
                "best-individual-sequence": [29, 21, 19, 14, 13, 8, 3, 7, 9, 4, 10, 1, 2, 5, 6, 11, 12, 17, 26, 16, 27, 25, 24, 20, 28, 15, 18, 23, 22],
                "best-individual-distance": 41061.67477593799,
                "worst-individual-sequence": [25, 23, 18, 22, 19, 15, 1, 10, 4, 2, 12, 11, 13, 7, 8, 9, 5, 6, 3, 14, 17, 21, 20, 28, 29, 26, 16, 24, 27],
                "worst-individual-distance": 54267.83271166945,
                "average-distance": 51103.57246831202,
                "individual-distances": []
            }, {
                "best-individual-sequence": [13, 8, 7, 9, 1, 26, 21, 29, 23, 18, 19, 14, 16, 27, 25, 24, 20, 28, 22, 15, 11, 10, 17, 2, 6, 4, 5, 3, 12],
                "best-individual-distance": 39800.54008757446,
                "worst-individual-sequence": [7, 8, 6, 3, 12, 22, 18, 17, 14, 13, 5, 2, 1, 4, 21, 29, 23, 20, 28, 16, 26, 27, 25, 24, 15, 19, 11, 10, 9],
                "worst-individual-distance": 53874.34153744412,
                "average-distance": 50796.692927332,
                "individual-distances": []
            }, {
                "best-individual-sequence": [13, 8, 7, 9, 1, 26, 21, 29, 23, 18, 19, 14, 16, 27, 25, 24, 20, 28, 22, 15, 11, 10, 17, 2, 6, 4, 5, 3, 12],
                "best-individual-distance": 39800.54008757446,
                "worst-individual-sequence": [18, 22, 29, 20, 24, 16, 2, 8, 3, 10, 6, 11, 12, 21, 23, 17, 26, 25, 27, 28, 14, 9, 13, 7, 1, 4, 5, 15, 19],
                "worst-individual-distance": 53542.03331444403,
                "average-distance": 50457.39753091794,
                "individual-distances": []
            }, {
                "best-individual-sequence": [13, 8, 7, 9, 1, 26, 21, 29, 23, 18, 19, 14, 16, 27, 25, 24, 20, 28, 22, 15, 11, 10, 17, 2, 6, 4, 5, 3, 12],
                "best-individual-distance": 39800.54008757446,
                "worst-individual-sequence": [16, 13, 12, 3, 9, 21, 15, 22, 28, 19, 17, 14, 8, 7, 1, 4, 5, 2, 6, 10, 11, 29, 20, 23, 18, 26, 27, 25, 24],
                "worst-individual-distance": 53284.956032576076,
                "average-distance": 50213.495833160545,
                "individual-distances": []
            }, {
                "best-individual-sequence": [13, 8, 7, 9, 1, 26, 21, 29, 23, 18, 19, 14, 16, 27, 25, 24, 20, 28, 22, 15, 11, 10, 17, 2, 6, 4, 5, 3, 12],
                "best-individual-distance": 39800.54008757446,
                "worst-individual-sequence": [1, 13, 3, 9, 4, 5, 7, 11, 10, 6, 8, 12, 16, 21, 29, 17, 26, 25, 27, 28, 23, 20, 24, 15, 22, 18, 19, 14, 2],
                "worst-individual-distance": 53014.29471543359,
                "average-distance": 49975.96173834606,
                "individual-distances": []
            }, {
                "best-individual-sequence": [13, 8, 7, 9, 1, 26, 21, 29, 23, 18, 19, 14, 16, 27, 25, 24, 20, 28, 22, 15, 11, 10, 17, 2, 6, 4, 5, 3, 12],
                "best-individual-distance": 39800.54008757446,
                "worst-individual-sequence": [7, 24, 28, 17, 15, 19, 29, 20, 18, 23, 21, 27, 25, 22, 16, 26, 14, 9, 8, 13, 10, 6, 2, 1, 11, 5, 4, 3, 12],
                "worst-individual-distance": 52743.036612706244,
                "average-distance": 49662.48531473682,
                "individual-distances": []
            }, {
                "best-individual-sequence": [13, 8, 7, 9, 1, 26, 21, 29, 23, 18, 19, 14, 16, 27, 25, 24, 20, 28, 22, 15, 11, 10, 17, 2, 6, 4, 5, 3, 12],
                "best-individual-distance": 39800.54008757446,
                "worst-individual-sequence": [22, 25, 13, 10, 11, 5, 1, 6, 2, 9, 17, 21, 20, 28, 26, 16, 27, 24, 14, 12, 7, 4, 3, 8, 19, 15, 18, 23, 29],
                "worst-individual-distance": 52527.74158135264,
                "average-distance": 49389.19534560552,
                "individual-distances": []
            }, {
                "best-individual-sequence": [13, 8, 7, 9, 1, 26, 21, 29, 23, 18, 19, 14, 16, 27, 25, 24, 20, 28, 22, 15, 11, 10, 17, 2, 6, 4, 5, 3, 12],
                "best-individual-distance": 39800.54008757446,
                "worst-individual-sequence": [4, 7, 12, 15, 26, 21, 22, 17, 14, 19, 29, 23, 27, 24, 25, 20, 16, 18, 13, 3, 9, 8, 28, 11, 10, 1, 6, 2, 5],
                "worst-individual-distance": 52183.094328281106,
                "average-distance": 49125.28764179859,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 2, 7, 9, 13, 21, 23, 22, 17, 26, 16, 27, 25, 24, 20, 28, 14, 29, 18, 19, 15, 11, 10, 8, 3, 1, 6, 5, 4],
                "best-individual-distance": 38937.93558401695,
                "worst-individual-sequence": [2, 1, 6, 8, 7, 29, 10, 11, 15, 19, 23, 22, 17, 26, 16, 27, 25, 24, 20, 28, 14, 13, 4, 5, 3, 9, 12, 21, 18],
                "worst-individual-distance": 51863.217153515405,
                "average-distance": 48797.943739605944,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 2, 7, 9, 13, 21, 23, 22, 17, 26, 16, 27, 25, 24, 20, 28, 14, 29, 18, 19, 15, 11, 10, 8, 3, 1, 6, 5, 4],
                "best-individual-distance": 38937.93558401695,
                "worst-individual-sequence": [2, 1, 5, 11, 6, 4, 3, 7, 8, 10, 28, 21, 26, 29, 23, 18, 19, 15, 14, 22, 25, 17, 20, 16, 27, 24, 13, 9, 12],
                "worst-individual-distance": 51512.438161869875,
                "average-distance": 48492.115749844306,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 2, 7, 9, 13, 21, 23, 22, 17, 26, 16, 27, 25, 24, 20, 28, 14, 29, 18, 19, 15, 11, 10, 8, 3, 1, 6, 5, 4],
                "best-individual-distance": 38937.93558401695,
                "worst-individual-sequence": [26, 16, 20, 19, 28, 29, 24, 25, 27, 21, 14, 9, 7, 8, 13, 3, 4, 2, 1, 10, 5, 6, 11, 15, 18, 12, 23, 22, 17],
                "worst-individual-distance": 51152.50708728554,
                "average-distance": 48198.08553201709,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 2, 7, 9, 13, 21, 23, 22, 17, 26, 16, 27, 25, 24, 20, 28, 14, 29, 18, 19, 15, 11, 10, 8, 3, 1, 6, 5, 4],
                "best-individual-distance": 38937.93558401695,
                "worst-individual-sequence": [15, 19, 29, 18, 23, 22, 8, 13, 26, 16, 27, 25, 24, 20, 28, 14, 3, 7, 10, 2, 1, 4, 5, 6, 11, 12, 9, 17, 21],
                "worst-individual-distance": 50854.93238027038,
                "average-distance": 47892.32794407673,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 2, 7, 9, 13, 21, 23, 22, 17, 26, 16, 27, 25, 24, 20, 28, 14, 29, 18, 19, 15, 11, 10, 8, 3, 1, 6, 5, 4],
                "best-individual-distance": 38937.93558401695,
                "worst-individual-sequence": [7, 9, 8, 4, 3, 6, 22, 17, 26, 21, 29, 23, 18, 19, 15, 14, 16, 27, 25, 24, 20, 28, 12, 10, 2, 5, 1, 11, 13],
                "worst-individual-distance": 50577.789528056644,
                "average-distance": 47612.19702901209,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 7, 9, 2, 1, 4, 5, 6, 11, 10, 15, 29, 23, 18, 19, 22, 17, 26, 16, 27, 25, 24, 20, 28, 21, 14, 13, 12, 8],
                "best-individual-distance": 38445.51081939639,
                "worst-individual-sequence": [29, 18, 19, 8, 21, 23, 22, 17, 26, 16, 27, 25, 24, 20, 28, 14, 3, 7, 9, 10, 2, 1, 4, 5, 6, 11, 12, 15, 13],
                "worst-individual-distance": 50283.46434031178,
                "average-distance": 47330.99252705271,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 13, 17, 21, 29, 23, 22, 26, 16, 27, 25, 24, 20, 28, 14, 18, 19, 15, 11, 10, 1, 3, 8, 6, 5, 4, 12, 2, 7],
                "best-individual-distance": 37039.48116984876,
                "worst-individual-sequence": [14, 2, 1, 3, 13, 9, 4, 5, 7, 11, 10, 8, 12, 17, 21, 29, 23, 20, 28, 16, 26, 27, 25, 24, 19, 15, 22, 18, 6],
                "worst-individual-distance": 50057.98202143515,
                "average-distance": 47017.380775786485,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 13, 17, 21, 29, 23, 22, 26, 16, 27, 25, 24, 20, 28, 14, 18, 19, 15, 11, 10, 1, 3, 8, 6, 5, 4, 12, 2, 7],
                "best-individual-distance": 37039.48116984876,
                "worst-individual-sequence": [11, 10, 1, 2, 6, 17, 26, 21, 5, 7, 3, 9, 19, 29, 23, 18, 15, 14, 16, 27, 25, 24, 20, 28, 22, 13, 12, 8, 4],
                "worst-individual-distance": 49811.12069771584,
                "average-distance": 46742.536906755435,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 13, 17, 21, 29, 23, 22, 26, 16, 27, 25, 24, 20, 28, 14, 18, 19, 15, 11, 10, 1, 3, 8, 6, 5, 4, 12, 2, 7],
                "best-individual-distance": 37039.48116984876,
                "worst-individual-sequence": [17, 14, 28, 12, 2, 1, 6, 5, 4, 3, 7, 8, 10, 11, 18, 26, 29, 23, 22, 19, 15, 20, 24, 25, 27, 13, 9, 21, 16],
                "worst-individual-distance": 49554.08099424822,
                "average-distance": 46507.5274330903,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 13, 17, 21, 29, 23, 22, 26, 16, 27, 25, 24, 20, 28, 14, 18, 19, 15, 11, 10, 1, 3, 8, 6, 5, 4, 12, 2, 7],
                "best-individual-distance": 37039.48116984876,
                "worst-individual-sequence": [22, 19, 8, 13, 18, 17, 16, 27, 25, 26, 21, 29, 24, 20, 28, 14, 3, 7, 9, 10, 2, 1, 4, 5, 6, 11, 12, 15, 23],
                "worst-individual-distance": 49270.34794910768,
                "average-distance": 46231.891510643676,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 13, 17, 21, 29, 23, 22, 26, 16, 27, 25, 24, 20, 28, 14, 18, 19, 15, 11, 10, 1, 3, 8, 6, 5, 4, 12, 2, 7],
                "best-individual-distance": 37039.48116984876,
                "worst-individual-sequence": [18, 1, 6, 2, 5, 4, 7, 12, 14, 28, 27, 24, 26, 21, 23, 22, 17, 20, 16, 25, 10, 13, 3, 9, 8, 19, 15, 29, 11],
                "worst-individual-distance": 49037.61727363191,
                "average-distance": 45982.297799690714,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 13, 17, 21, 29, 23, 22, 26, 16, 27, 25, 24, 20, 28, 14, 18, 19, 15, 11, 10, 1, 3, 8, 6, 5, 4, 12, 2, 7],
                "best-individual-distance": 37039.48116984876,
                "worst-individual-sequence": [12, 14, 28, 20, 24, 25, 27, 17, 13, 9, 3, 6, 4, 8, 21, 16, 26, 29, 23, 18, 22, 19, 15, 11, 10, 1, 2, 5, 7],
                "worst-individual-distance": 48763.358433065885,
                "average-distance": 45679.87798841752,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 13, 17, 21, 29, 23, 22, 26, 16, 27, 25, 24, 20, 28, 14, 18, 19, 15, 11, 10, 1, 3, 8, 6, 5, 4, 12, 2, 7],
                "best-individual-distance": 37039.48116984876,
                "worst-individual-sequence": [22, 26, 24, 25, 27, 28, 9, 23, 4, 7, 8, 17, 3, 29, 21, 5, 10, 12, 11, 1, 6, 2, 15, 13, 14, 16, 20, 19, 18],
                "worst-individual-distance": 48527.09356425038,
                "average-distance": 45415.43499169274,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 13, 17, 21, 29, 23, 22, 26, 16, 27, 25, 24, 20, 28, 14, 18, 19, 15, 11, 10, 1, 3, 8, 6, 5, 4, 12, 2, 7],
                "best-individual-distance": 37039.48116984876,
                "worst-individual-sequence": [18, 22, 29, 14, 15, 23, 21, 28, 17, 26, 16, 27, 25, 24, 20, 19, 4, 12, 3, 7, 9, 13, 10, 8, 6, 2, 1, 5, 11],
                "worst-individual-distance": 48175.453040221204,
                "average-distance": 45139.72431873671,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 13, 17, 21, 29, 23, 22, 26, 16, 27, 25, 24, 20, 28, 14, 18, 19, 15, 11, 10, 1, 3, 8, 6, 5, 4, 12, 2, 7],
                "best-individual-distance": 37039.48116984876,
                "worst-individual-sequence": [14, 5, 3, 7, 9, 8, 13, 10, 6, 2, 1, 4, 12, 15, 19, 23, 22, 17, 26, 16, 27, 25, 24, 20, 11, 18, 28, 29, 21],
                "worst-individual-distance": 47822.77458864524,
                "average-distance": 44885.483021854,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 13, 17, 21, 29, 23, 22, 26, 16, 27, 25, 24, 20, 28, 14, 18, 19, 15, 11, 10, 1, 3, 8, 6, 5, 4, 12, 2, 7],
                "best-individual-distance": 37039.48116984876,
                "worst-individual-sequence": [10, 11, 2, 19, 17, 16, 27, 24, 20, 28, 26, 25, 21, 29, 23, 18, 14, 22, 15, 13, 9, 12, 1, 6, 5, 4, 3, 7, 8],
                "worst-individual-distance": 47616.65119579433,
                "average-distance": 44663.089257075706,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 13, 17, 21, 29, 23, 22, 26, 16, 27, 25, 24, 20, 28, 14, 18, 19, 15, 11, 10, 1, 3, 8, 6, 5, 4, 12, 2, 7],
                "best-individual-distance": 37039.48116984876,
                "worst-individual-sequence": [20, 28, 2, 12, 9, 1, 6, 5, 4, 3, 7, 8, 10, 11, 18, 16, 27, 24, 14, 25, 29, 23, 22, 19, 15, 13, 21, 17, 26],
                "worst-individual-distance": 47375.9427412167,
                "average-distance": 44387.54809694546,
                "individual-distances": []
            }, {
                "best-individual-sequence": [6, 5, 4, 3, 7, 8, 10, 11, 12, 17, 18, 19, 15, 14, 16, 27, 25, 24, 20, 26, 21, 29, 23, 28, 22, 13, 9, 2, 1],
                "best-individual-distance": 36848.583757096414,
                "worst-individual-sequence": [9, 3, 7, 8, 14, 17, 12, 1, 4, 5, 2, 6, 10, 11, 20, 25, 27, 24, 28, 21, 29, 23, 18, 19, 15, 22, 26, 16, 13],
                "worst-individual-distance": 47088.3795828943,
                "average-distance": 44090.5997432125,
                "individual-distances": []
            }, {
                "best-individual-sequence": [6, 5, 4, 3, 7, 8, 10, 11, 12, 17, 18, 19, 15, 14, 16, 27, 25, 24, 20, 26, 21, 29, 23, 28, 22, 13, 9, 2, 1],
                "best-individual-distance": 36848.583757096414,
                "worst-individual-sequence": [7, 3, 9, 12, 13, 21, 23, 22, 17, 26, 28, 14, 29, 18, 19, 15, 11, 10, 16, 27, 25, 24, 20, 2, 1, 6, 8, 4, 5],
                "worst-individual-distance": 46818.60272719009,
                "average-distance": 43846.619747250785,
                "individual-distances": []
            }, {
                "best-individual-sequence": [6, 5, 4, 3, 7, 8, 10, 11, 12, 17, 18, 19, 15, 14, 16, 27, 25, 24, 20, 26, 21, 29, 23, 28, 22, 13, 9, 2, 1],
                "best-individual-distance": 36848.583757096414,
                "worst-individual-sequence": [5, 4, 3, 7, 10, 11, 22, 17, 21, 23, 18, 19, 15, 14, 28, 12, 26, 16, 27, 25, 24, 20, 29, 13, 9, 8, 2, 1, 6],
                "worst-individual-distance": 46558.07029102772,
                "average-distance": 43622.97801373825,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 6, 5, 4, 3, 7, 12, 10, 11, 21, 18, 15, 19, 29, 23, 22, 17, 26, 16, 27, 25, 24, 20, 28, 14, 13, 9, 8, 2],
                "best-individual-distance": 36744.69955810225,
                "worst-individual-sequence": [1, 6, 8, 4, 5, 7, 11, 10, 21, 18, 19, 29, 23, 28, 12, 15, 22, 17, 26, 16, 27, 25, 24, 20, 14, 13, 3, 9, 2],
                "worst-individual-distance": 46174.646324303525,
                "average-distance": 43352.48147368288,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 6, 5, 4, 3, 7, 12, 10, 11, 21, 18, 15, 19, 29, 23, 22, 17, 26, 16, 27, 25, 24, 20, 28, 14, 13, 9, 8, 2],
                "best-individual-distance": 36744.69955810225,
                "worst-individual-sequence": [4, 3, 8, 28, 21, 22, 17, 29, 20, 26, 16, 27, 25, 24, 14, 23, 18, 19, 15, 11, 10, 1, 2, 5, 7, 12, 13, 9, 6],
                "worst-individual-distance": 45986.25569747096,
                "average-distance": 43172.31586146925,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 6, 5, 4, 3, 7, 12, 10, 11, 21, 18, 15, 19, 29, 23, 22, 17, 26, 16, 27, 25, 24, 20, 28, 14, 13, 9, 8, 2],
                "best-individual-distance": 36744.69955810225,
                "worst-individual-sequence": [1, 2, 6, 10, 9, 12, 18, 26, 16, 27, 25, 24, 21, 29, 19, 23, 15, 14, 20, 28, 22, 17, 13, 5, 4, 3, 7, 8, 11],
                "worst-individual-distance": 45710.152830783925,
                "average-distance": 42929.5418512005,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 6, 5, 4, 3, 7, 12, 10, 11, 21, 18, 15, 19, 29, 23, 22, 17, 26, 16, 27, 25, 24, 20, 28, 14, 13, 9, 8, 2],
                "best-individual-distance": 36744.69955810225,
                "worst-individual-sequence": [17, 21, 19, 15, 20, 16, 9, 3, 8, 13, 12, 18, 28, 26, 27, 24, 25, 29, 23, 22, 11, 10, 1, 6, 2, 5, 4, 7, 14],
                "worst-individual-distance": 45495.50667064707,
                "average-distance": 42670.26456265027,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 6, 5, 4, 3, 7, 12, 10, 11, 21, 18, 15, 19, 29, 23, 22, 17, 26, 16, 27, 25, 24, 20, 28, 14, 13, 9, 8, 2],
                "best-individual-distance": 36744.69955810225,
                "worst-individual-sequence": [1, 6, 5, 4, 3, 7, 8, 10, 11, 2, 17, 26, 21, 29, 23, 18, 19, 15, 14, 16, 27, 25, 24, 20, 28, 22, 12, 13, 9],
                "worst-individual-distance": 45211.89351035134,
                "average-distance": 42444.20319599451,
                "individual-distances": []
            }
        ],
        [
            [{
                "time_cost": 0
            }], {
                "best-individual-sequence": [21, 16, 24, 27, 20, 17, 12, 6, 19, 23, 14, 29, 22, 7, 9, 13, 28, 15, 26, 25, 3, 4, 10, 11, 1, 5, 2, 18, 8],
                "best-individual-distance": 75059.95074127964,
                "worst-individual-sequence": [27, 9, 20, 8, 11, 10, 24, 3, 16, 19, 14, 5, 6, 17, 18, 15, 28, 2, 25, 4, 21, 7, 26, 13, 23, 22, 12, 1, 29],
                "worst-individual-distance": 120923.55815402346,
                "average-distance": 106797.14068280406,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 16, 24, 27, 20, 17, 12, 6, 19, 23, 14, 29, 22, 7, 9, 13, 28, 15, 26, 25, 3, 4, 10, 11, 1, 5, 2, 18, 8],
                "best-individual-distance": 75059.95074127964,
                "worst-individual-sequence": [21, 29, 3, 8, 17, 16, 10, 14, 9, 19, 4, 2, 28, 23, 25, 1, 6, 27, 12, 13, 15, 18, 20, 26, 7, 22, 11, 24, 5],
                "worst-individual-distance": 116118.93441689468,
                "average-distance": 104147.82296113034,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 16, 24, 27, 20, 17, 12, 6, 19, 23, 14, 29, 22, 7, 9, 13, 28, 15, 26, 25, 3, 4, 10, 11, 1, 5, 2, 18, 8],
                "best-individual-distance": 75059.95074127964,
                "worst-individual-sequence": [23, 25, 6, 8, 18, 27, 11, 16, 26, 12, 17, 10, 4, 28, 2, 20, 5, 1, 3, 14, 19, 9, 7, 24, 29, 15, 22, 13, 21],
                "worst-individual-distance": 112504.1717767041,
                "average-distance": 101958.05217201906,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 13, 29, 17, 26, 16, 11, 8, 10, 6, 1, 2, 28, 15, 23, 20, 14, 24, 25, 27, 7, 3, 4, 5, 19, 22, 21, 18, 9],
                "best-individual-distance": 62646.68286753109,
                "worst-individual-sequence": [18, 12, 27, 17, 15, 7, 16, 10, 13, 21, 22, 25, 5, 8, 6, 4, 23, 29, 9, 24, 26, 20, 3, 1, 28, 11, 14, 19, 2],
                "worst-individual-distance": 109846.49910118384,
                "average-distance": 99766.82633510244,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 13, 29, 17, 26, 16, 11, 8, 10, 6, 1, 2, 28, 15, 23, 20, 14, 24, 25, 27, 7, 3, 4, 5, 19, 22, 21, 18, 9],
                "best-individual-distance": 62646.68286753109,
                "worst-individual-sequence": [13, 5, 18, 3, 28, 14, 4, 1, 17, 23, 24, 12, 9, 25, 6, 2, 11, 15, 8, 29, 10, 19, 7, 21, 27, 26, 22, 16, 20],
                "worst-individual-distance": 107344.46020628528,
                "average-distance": 97648.12852390202,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 13, 29, 17, 26, 16, 11, 8, 10, 6, 1, 2, 28, 15, 23, 20, 14, 24, 25, 27, 7, 3, 4, 5, 19, 22, 21, 18, 9],
                "best-individual-distance": 62646.68286753109,
                "worst-individual-sequence": [19, 6, 9, 3, 17, 24, 29, 8, 21, 15, 10, 14, 27, 16, 12, 13, 1, 4, 7, 11, 22, 5, 20, 23, 26, 2, 25, 18, 28],
                "worst-individual-distance": 105330.61542342015,
                "average-distance": 95596.87709407513,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 13, 29, 17, 26, 16, 11, 8, 10, 6, 1, 2, 28, 15, 23, 20, 14, 24, 25, 27, 7, 3, 4, 5, 19, 22, 21, 18, 9],
                "best-individual-distance": 62646.68286753109,
                "worst-individual-sequence": [5, 14, 19, 21, 13, 7, 11, 8, 2, 6, 22, 23, 24, 4, 20, 15, 12, 28, 9, 18, 25, 16, 1, 10, 17, 3, 26, 27, 29],
                "worst-individual-distance": 103006.37837976166,
                "average-distance": 93702.5470472836,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 13, 29, 17, 26, 16, 11, 8, 10, 6, 1, 2, 28, 15, 23, 20, 14, 24, 25, 27, 7, 3, 4, 5, 19, 22, 21, 18, 9],
                "best-individual-distance": 62646.68286753109,
                "worst-individual-sequence": [3, 18, 5, 8, 11, 17, 13, 20, 14, 26, 21, 28, 19, 29, 23, 22, 16, 7, 24, 4, 12, 15, 9, 25, 2, 27, 6, 1, 10],
                "worst-individual-distance": 100863.92186005837,
                "average-distance": 91778.79944308463,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 13, 29, 17, 26, 16, 11, 8, 10, 6, 1, 2, 28, 15, 23, 20, 14, 24, 25, 27, 7, 3, 4, 5, 19, 22, 21, 18, 9],
                "best-individual-distance": 62646.68286753109,
                "worst-individual-sequence": [18, 19, 21, 7, 10, 11, 25, 23, 22, 24, 1, 9, 27, 2, 14, 15, 13, 29, 20, 16, 26, 12, 8, 6, 17, 5, 4, 3, 28],
                "worst-individual-distance": 98807.1146051646,
                "average-distance": 90056.64190107028,
                "individual-distances": []
            }, {
                "best-individual-sequence": [13, 11, 6, 3, 4, 8, 2, 1, 5, 7, 9, 21, 22, 16, 27, 18, 24, 19, 25, 26, 23, 20, 28, 17, 14, 15, 29, 10, 12],
                "best-individual-distance": 61537.29278192201,
                "worst-individual-sequence": [18, 13, 14, 10, 24, 21, 15, 26, 29, 19, 9, 27, 16, 25, 1, 22, 23, 3, 2, 5, 8, 20, 17, 11, 28, 12, 7, 4, 6],
                "worst-individual-distance": 97083.47647146945,
                "average-distance": 88357.39971459442,
                "individual-distances": []
            }, {
                "best-individual-sequence": [13, 11, 6, 3, 4, 8, 2, 1, 5, 7, 9, 21, 22, 16, 27, 18, 24, 19, 25, 26, 23, 20, 28, 17, 14, 15, 29, 10, 12],
                "best-individual-distance": 61537.29278192201,
                "worst-individual-sequence": [20, 14, 26, 17, 28, 12, 3, 8, 1, 5, 9, 10, 13, 23, 21, 6, 25, 29, 22, 7, 27, 18, 16, 15, 11, 4, 2, 24, 19],
                "worst-individual-distance": 95530.81822985895,
                "average-distance": 86835.35924991587,
                "individual-distances": []
            }, {
                "best-individual-sequence": [13, 11, 6, 3, 4, 8, 2, 1, 5, 7, 9, 21, 22, 16, 27, 18, 24, 19, 25, 26, 23, 20, 28, 17, 14, 15, 29, 10, 12],
                "best-individual-distance": 61537.29278192201,
                "worst-individual-sequence": [24, 7, 4, 8, 5, 2, 28, 10, 9, 3, 23, 13, 20, 26, 22, 25, 29, 19, 1, 6, 21, 11, 16, 15, 12, 14, 17, 27, 18],
                "worst-individual-distance": 93824.97759500914,
                "average-distance": 85308.5434146151,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 17, 16, 23, 24, 20, 18, 13, 14, 19, 11, 4, 8, 2, 1, 5, 7, 9, 15, 21, 22, 26, 29, 28, 25, 27, 3, 10, 6],
                "best-individual-distance": 59640.4511011526,
                "worst-individual-sequence": [7, 18, 29, 17, 3, 5, 4, 15, 9, 19, 23, 25, 12, 13, 8, 10, 22, 21, 16, 27, 20, 24, 14, 6, 1, 28, 2, 11, 26],
                "worst-individual-distance": 92032.94996519768,
                "average-distance": 83823.19249526925,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 17, 16, 23, 24, 20, 18, 13, 14, 19, 11, 4, 8, 2, 1, 5, 7, 9, 15, 21, 22, 26, 29, 28, 25, 27, 3, 10, 6],
                "best-individual-distance": 59640.4511011526,
                "worst-individual-sequence": [4, 10, 6, 17, 26, 24, 11, 21, 9, 7, 1, 3, 19, 29, 16, 5, 2, 12, 15, 8, 27, 18, 28, 23, 22, 14, 25, 20, 13],
                "worst-individual-distance": 90284.82797172357,
                "average-distance": 82330.37379786401,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 17, 16, 23, 24, 20, 18, 13, 14, 19, 11, 4, 8, 2, 1, 5, 7, 9, 15, 21, 22, 26, 29, 28, 25, 27, 3, 10, 6],
                "best-individual-distance": 59640.4511011526,
                "worst-individual-sequence": [3, 5, 24, 27, 16, 18, 19, 23, 13, 9, 12, 6, 15, 1, 17, 14, 29, 2, 25, 28, 7, 8, 21, 22, 20, 26, 11, 10, 4],
                "worst-individual-distance": 88644.13030491042,
                "average-distance": 81039.6815212471,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 17, 16, 23, 24, 20, 18, 13, 14, 19, 11, 4, 8, 2, 1, 5, 7, 9, 15, 21, 22, 26, 29, 28, 25, 27, 3, 10, 6],
                "best-individual-distance": 59640.4511011526,
                "worst-individual-sequence": [17, 4, 8, 2, 15, 22, 14, 9, 11, 1, 3, 10, 6, 12, 23, 5, 18, 7, 25, 26, 27, 19, 21, 28, 29, 20, 16, 13, 24],
                "worst-individual-distance": 87181.73628415314,
                "average-distance": 79777.62821942242,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 17, 16, 23, 24, 20, 18, 13, 14, 19, 11, 4, 8, 2, 1, 5, 7, 9, 15, 21, 22, 26, 29, 28, 25, 27, 3, 10, 6],
                "best-individual-distance": 59640.4511011526,
                "worst-individual-sequence": [15, 7, 18, 25, 12, 8, 11, 4, 13, 23, 10, 9, 26, 21, 19, 3, 17, 27, 24, 28, 29, 22, 14, 6, 2, 5, 1, 16, 20],
                "worst-individual-distance": 85868.01034300927,
                "average-distance": 78603.14723946768,
                "individual-distances": []
            }, {
                "best-individual-sequence": [12, 17, 16, 23, 24, 20, 18, 13, 14, 19, 11, 4, 8, 2, 1, 5, 7, 9, 15, 21, 22, 26, 29, 28, 25, 27, 3, 10, 6],
                "best-individual-distance": 59640.4511011526,
                "worst-individual-sequence": [16, 12, 13, 6, 19, 9, 27, 28, 18, 20, 17, 22, 8, 7, 4, 15, 21, 26, 29, 5, 3, 23, 24, 25, 14, 2, 1, 10, 11],
                "worst-individual-distance": 84357.63835392208,
                "average-distance": 77316.24957137379,
                "individual-distances": []
            }, {
                "best-individual-sequence": [19, 5, 7, 9, 8, 6, 13, 11, 4, 10, 12, 1, 2, 3, 15, 18, 21, 23, 26, 20, 24, 27, 25, 28, 22, 14, 16, 29, 17],
                "best-individual-distance": 57341.163759224604,
                "worst-individual-sequence": [22, 19, 27, 8, 17, 28, 25, 24, 23, 29, 26, 3, 13, 1, 2, 12, 18, 5, 6, 11, 10, 4, 14, 7, 16, 15, 20, 9, 21],
                "worst-individual-distance": 82944.23234380267,
                "average-distance": 76027.12535094132,
                "individual-distances": []
            }, {
                "best-individual-sequence": [19, 9, 13, 11, 10, 29, 18, 15, 21, 12, 1, 2, 6, 8, 5, 3, 4, 7, 23, 26, 14, 20, 24, 28, 17, 16, 27, 25, 22],
                "best-individual-distance": 56561.85955791493,
                "worst-individual-sequence": [7, 13, 9, 28, 25, 24, 27, 2, 4, 11, 1, 5, 10, 6, 12, 23, 18, 15, 21, 3, 19, 29, 26, 14, 22, 16, 20, 8, 17],
                "worst-individual-distance": 81462.36968403285,
                "average-distance": 74724.74472285704,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 1, 17, 23, 18, 15, 21, 19, 29, 12, 11, 2, 6, 8, 5, 3, 4, 9, 7, 10, 13, 14, 20, 24, 28, 16, 27, 25, 22],
                "best-individual-distance": 55657.68927231978,
                "worst-individual-sequence": [7, 23, 14, 10, 27, 12, 4, 5, 6, 3, 24, 16, 8, 2, 1, 18, 15, 25, 20, 26, 21, 11, 17, 22, 19, 29, 28, 13, 9],
                "worst-individual-distance": 80272.26242623714,
                "average-distance": 73595.36691870163,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 1, 17, 23, 18, 15, 21, 19, 29, 12, 11, 2, 6, 8, 5, 3, 4, 9, 7, 10, 13, 14, 20, 24, 28, 16, 27, 25, 22],
                "best-individual-distance": 55657.68927231978,
                "worst-individual-sequence": [6, 15, 28, 24, 27, 19, 20, 22, 23, 17, 4, 8, 2, 1, 5, 7, 9, 16, 13, 21, 10, 18, 25, 29, 3, 12, 14, 26, 11],
                "worst-individual-distance": 78822.28362213702,
                "average-distance": 72595.95331827867,
                "individual-distances": []
            }, {
                "best-individual-sequence": [15, 1, 2, 5, 4, 3, 8, 7, 9, 21, 22, 16, 14, 29, 11, 10, 6, 12, 13, 18, 19, 26, 28, 23, 17, 20, 24, 25, 27],
                "best-individual-distance": 52811.63605651203,
                "worst-individual-sequence": [10, 4, 5, 25, 14, 27, 16, 19, 23, 9, 12, 6, 15, 1, 2, 24, 28, 29, 7, 8, 3, 13, 18, 21, 22, 17, 20, 26, 11],
                "worst-individual-distance": 77681.58817244717,
                "average-distance": 71617.2570499138,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 14, 3, 20, 25, 16, 24, 23, 21, 15, 4, 27, 8, 2, 1, 5, 7, 9, 13, 18, 19, 26, 28, 29, 22, 17, 12, 11, 6],
                "best-individual-distance": 50730.2412508571,
                "worst-individual-sequence": [13, 7, 10, 6, 11, 14, 21, 28, 23, 12, 3, 4, 8, 2, 1, 5, 15, 20, 27, 18, 25, 19, 24, 26, 16, 17, 29, 22, 9],
                "worst-individual-distance": 76558.98473263788,
                "average-distance": 70588.54866873403,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 14, 3, 20, 25, 16, 24, 23, 21, 15, 4, 27, 8, 2, 1, 5, 7, 9, 13, 18, 19, 26, 28, 29, 22, 17, 12, 11, 6],
                "best-individual-distance": 50730.2412508571,
                "worst-individual-sequence": [3, 19, 22, 24, 4, 8, 2, 1, 11, 18, 16, 9, 10, 6, 12, 5, 7, 13, 21, 29, 15, 20, 27, 14, 26, 28, 25, 23, 17],
                "worst-individual-distance": 75373.2816219955,
                "average-distance": 69670.24085923382,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 14, 3, 20, 25, 16, 24, 23, 21, 15, 4, 27, 8, 2, 1, 5, 7, 9, 13, 18, 19, 26, 28, 29, 22, 17, 12, 11, 6],
                "best-individual-distance": 50730.2412508571,
                "worst-individual-sequence": [13, 24, 14, 19, 22, 23, 25, 29, 26, 1, 2, 10, 12, 17, 21, 27, 15, 7, 5, 3, 6, 8, 4, 11, 20, 28, 18, 9, 16],
                "worst-individual-distance": 74343.54249157578,
                "average-distance": 68837.04763556378,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 14, 3, 20, 25, 16, 24, 23, 21, 15, 4, 27, 8, 2, 1, 5, 7, 9, 13, 18, 19, 26, 28, 29, 22, 17, 12, 11, 6],
                "best-individual-distance": 50730.2412508571,
                "worst-individual-sequence": [10, 21, 19, 29, 27, 22, 14, 23, 18, 15, 20, 17, 16, 6, 1, 5, 4, 7, 9, 12, 13, 26, 24, 28, 25, 2, 8, 11, 3],
                "worst-individual-distance": 73357.91502467035,
                "average-distance": 68013.33306614621,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 14, 3, 20, 25, 16, 24, 23, 21, 15, 4, 27, 8, 2, 1, 5, 7, 9, 13, 18, 19, 26, 28, 29, 22, 17, 12, 11, 6],
                "best-individual-distance": 50730.2412508571,
                "worst-individual-sequence": [19, 23, 24, 4, 8, 2, 1, 11, 18, 16, 9, 10, 6, 12, 5, 7, 13, 21, 29, 3, 14, 27, 20, 26, 25, 15, 17, 28, 22],
                "worst-individual-distance": 72472.31101339667,
                "average-distance": 67164.78295102139,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 14, 3, 20, 25, 16, 24, 23, 21, 15, 4, 27, 8, 2, 1, 5, 7, 9, 13, 18, 19, 26, 28, 29, 22, 17, 12, 11, 6],
                "best-individual-distance": 50730.2412508571,
                "worst-individual-sequence": [21, 18, 25, 20, 17, 22, 9, 15, 23, 29, 27, 16, 14, 11, 10, 6, 1, 2, 8, 26, 28, 12, 3, 4, 13, 24, 19, 7, 5],
                "worst-individual-distance": 71568.42466124592,
                "average-distance": 66296.3882455818,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 19, 28, 10, 11, 12, 3, 2, 6, 1, 8, 5, 7, 4, 9, 13, 14, 17, 20, 27, 22, 29, 16, 25, 24, 23, 18, 15, 21],
                "best-individual-distance": 49880.66449025057,
                "worst-individual-sequence": [3, 11, 12, 4, 8, 2, 5, 7, 1, 9, 13, 18, 19, 23, 21, 15, 29, 14, 20, 24, 27, 25, 28, 22, 16, 6, 17, 26, 10],
                "worst-individual-distance": 70577.8335134386,
                "average-distance": 65539.6169077243,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 19, 28, 10, 11, 12, 3, 2, 6, 1, 8, 5, 7, 4, 9, 13, 14, 17, 20, 27, 22, 29, 16, 25, 24, 23, 18, 15, 21],
                "best-individual-distance": 49880.66449025057,
                "worst-individual-sequence": [12, 16, 23, 24, 20, 18, 14, 19, 3, 4, 7, 13, 8, 2, 1, 5, 9, 15, 21, 22, 29, 28, 26, 27, 10, 6, 11, 17, 25],
                "worst-individual-distance": 69705.64567992695,
                "average-distance": 64824.04315414112,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 19, 28, 10, 11, 12, 3, 2, 6, 1, 8, 5, 7, 4, 9, 13, 14, 17, 20, 27, 22, 29, 16, 25, 24, 23, 18, 15, 21],
                "best-individual-distance": 49880.66449025057,
                "worst-individual-sequence": [18, 13, 10, 6, 29, 17, 11, 15, 27, 12, 3, 4, 8, 2, 1, 5, 7, 9, 24, 19, 22, 14, 21, 26, 28, 23, 25, 16, 20],
                "worst-individual-distance": 68925.78836481147,
                "average-distance": 64156.39545963204,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 10, 2, 6, 8, 5, 3, 7, 13, 9, 4, 12, 15, 14, 23, 18, 21, 26, 19, 29, 20, 24, 27, 25, 28, 17, 22, 16, 1],
                "best-individual-distance": 48383.21837056219,
                "worst-individual-sequence": [2, 1, 3, 12, 23, 18, 15, 19, 11, 4, 5, 7, 6, 20, 21, 26, 25, 24, 16, 28, 10, 9, 13, 29, 22, 27, 17, 14, 8],
                "worst-individual-distance": 68116.52108410641,
                "average-distance": 63479.40888513111,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 10, 2, 6, 8, 5, 3, 7, 13, 9, 4, 12, 15, 14, 23, 18, 21, 26, 19, 29, 20, 24, 27, 25, 28, 17, 22, 16, 1],
                "best-individual-distance": 48383.21837056219,
                "worst-individual-sequence": [4, 3, 1, 5, 15, 12, 23, 18, 19, 22, 21, 24, 16, 17, 14, 29, 26, 9, 6, 11, 13, 20, 27, 25, 28, 10, 7, 8, 2],
                "worst-individual-distance": 67299.8615295102,
                "average-distance": 62807.980387752796,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 10, 2, 6, 8, 5, 3, 7, 13, 9, 4, 12, 15, 14, 23, 18, 21, 26, 19, 29, 20, 24, 27, 25, 28, 17, 22, 16, 1],
                "best-individual-distance": 48383.21837056219,
                "worst-individual-sequence": [2, 7, 3, 4, 9, 18, 15, 19, 29, 14, 13, 11, 17, 16, 26, 21, 25, 24, 27, 22, 5, 8, 6, 1, 20, 23, 28, 12, 10],
                "worst-individual-distance": 66641.40104459185,
                "average-distance": 62241.16485604069,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 10, 2, 6, 8, 5, 3, 7, 13, 9, 4, 12, 15, 14, 23, 18, 21, 26, 19, 29, 20, 24, 27, 25, 28, 17, 22, 16, 1],
                "best-individual-distance": 48383.21837056219,
                "worst-individual-sequence": [11, 6, 10, 20, 4, 3, 8, 2, 1, 5, 18, 29, 21, 25, 26, 23, 28, 24, 27, 17, 14, 7, 9, 12, 13, 22, 15, 16, 19],
                "worst-individual-distance": 65930.35647827173,
                "average-distance": 61616.53186142201,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 10, 2, 6, 8, 5, 3, 7, 13, 9, 4, 12, 15, 14, 23, 18, 21, 26, 19, 29, 20, 24, 27, 25, 28, 17, 22, 16, 1],
                "best-individual-distance": 48383.21837056219,
                "worst-individual-sequence": [2, 3, 7, 22, 23, 21, 29, 6, 11, 10, 12, 18, 19, 8, 14, 26, 15, 5, 13, 17, 20, 24, 27, 25, 28, 16, 9, 4, 1],
                "worst-individual-distance": 65208.91348371873,
                "average-distance": 60886.4951006585,
                "individual-distances": []
            }, {
                "best-individual-sequence": [8, 12, 1, 5, 4, 3, 7, 9, 13, 14, 28, 22, 25, 23, 18, 15, 21, 19, 29, 26, 17, 20, 24, 27, 16, 2, 11, 10, 6],
                "best-individual-distance": 44818.35975496637,
                "worst-individual-sequence": [1, 5, 7, 9, 21, 22, 16, 17, 27, 29, 25, 18, 12, 13, 11, 10, 24, 20, 14, 19, 26, 28, 23, 15, 6, 3, 4, 8, 2],
                "worst-individual-distance": 64486.95666960092,
                "average-distance": 60277.97040816532,
                "individual-distances": []
            }, {
                "best-individual-sequence": [8, 12, 1, 5, 4, 3, 7, 9, 13, 14, 28, 22, 25, 23, 18, 15, 21, 19, 29, 26, 17, 20, 24, 27, 16, 2, 11, 10, 6],
                "best-individual-distance": 44818.35975496637,
                "worst-individual-sequence": [12, 18, 21, 26, 19, 4, 7, 13, 8, 2, 1, 5, 9, 15, 23, 20, 14, 29, 17, 24, 27, 25, 28, 22, 16, 11, 6, 3, 10],
                "worst-individual-distance": 63835.954359426934,
                "average-distance": 59695.74104922186,
                "individual-distances": []
            }, {
                "best-individual-sequence": [8, 12, 1, 5, 4, 3, 7, 9, 13, 14, 28, 22, 25, 23, 18, 15, 21, 19, 29, 26, 17, 20, 24, 27, 16, 2, 11, 10, 6],
                "best-individual-distance": 44818.35975496637,
                "worst-individual-sequence": [15, 6, 21, 24, 8, 2, 1, 5, 7, 9, 3, 4, 16, 17, 14, 12, 11, 10, 26, 13, 25, 28, 18, 19, 27, 29, 20, 22, 23],
                "worst-individual-distance": 63178.75725837348,
                "average-distance": 59101.90638191729,
                "individual-distances": []
            }, {
                "best-individual-sequence": [8, 12, 1, 5, 4, 3, 7, 9, 13, 14, 28, 22, 25, 23, 18, 15, 21, 19, 29, 26, 17, 20, 24, 27, 16, 2, 11, 10, 6],
                "best-individual-distance": 44818.35975496637,
                "worst-individual-sequence": [17, 14, 26, 23, 29, 13, 6, 1, 2, 7, 9, 5, 21, 18, 11, 10, 19, 20, 24, 27, 25, 28, 22, 16, 3, 12, 4, 8, 15],
                "worst-individual-distance": 62572.45369865685,
                "average-distance": 58520.66145424283,
                "individual-distances": []
            }, {
                "best-individual-sequence": [18, 15, 21, 19, 29, 1, 11, 10, 12, 2, 6, 8, 5, 3, 4, 9, 7, 13, 14, 20, 24, 28, 16, 27, 25, 22, 26, 17, 23],
                "best-individual-distance": 44289.96814240435,
                "worst-individual-sequence": [10, 11, 15, 19, 26, 28, 17, 24, 27, 25, 23, 3, 8, 2, 1, 5, 7, 9, 16, 13, 21, 18, 12, 22, 29, 14, 20, 4, 6],
                "worst-individual-distance": 62041.407052883966,
                "average-distance": 57985.61162217285,
                "individual-distances": []
            }, {
                "best-individual-sequence": [2, 6, 8, 5, 3, 4, 7, 9, 13, 14, 27, 25, 28, 23, 18, 15, 21, 19, 29, 26, 17, 20, 24, 16, 22, 1, 11, 12, 10],
                "best-individual-distance": 43665.94510863224,
                "worst-individual-sequence": [16, 17, 14, 8, 2, 1, 3, 12, 23, 18, 15, 21, 26, 19, 10, 11, 6, 4, 5, 7, 28, 25, 24, 9, 13, 29, 22, 20, 27],
                "worst-individual-distance": 61503.761580032726,
                "average-distance": 57391.60014216588,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 11, 10, 1, 2, 6, 8, 7, 9, 17, 15, 18, 21, 23, 26, 24, 19, 20, 27, 25, 16, 22, 29, 28, 14, 13, 12, 3, 4],
                "best-individual-distance": 41797.853951361474,
                "worst-individual-sequence": [3, 7, 5, 8, 2, 4, 1, 6, 12, 15, 14, 27, 21, 9, 13, 18, 19, 26, 28, 29, 20, 24, 25, 22, 16, 17, 23, 11, 10],
                "worst-individual-distance": 60895.0340400785,
                "average-distance": 56886.03641342229,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 11, 10, 1, 2, 6, 8, 7, 9, 17, 15, 18, 21, 23, 26, 24, 19, 20, 27, 25, 16, 22, 29, 28, 14, 13, 12, 3, 4],
                "best-individual-distance": 41797.853951361474,
                "worst-individual-sequence": [9, 5, 7, 13, 29, 16, 28, 10, 11, 12, 1, 2, 6, 4, 3, 25, 24, 21, 18, 19, 14, 27, 20, 26, 15, 17, 22, 23, 8],
                "worst-individual-distance": 60414.757995642794,
                "average-distance": 56346.86558734249,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 11, 10, 1, 2, 6, 8, 7, 9, 17, 15, 18, 21, 23, 26, 24, 19, 20, 27, 25, 16, 22, 29, 28, 14, 13, 12, 3, 4],
                "best-individual-distance": 41797.853951361474,
                "worst-individual-sequence": [18, 22, 15, 21, 12, 1, 2, 6, 8, 5, 3, 9, 14, 10, 11, 4, 29, 17, 20, 24, 27, 25, 28, 23, 16, 19, 13, 7, 26],
                "worst-individual-distance": 59770.455242299126,
                "average-distance": 55870.90221826612,
                "individual-distances": []
            }, {
                "best-individual-sequence": [8, 2, 1, 5, 4, 3, 7, 9, 13, 23, 18, 15, 21, 19, 26, 20, 24, 16, 27, 25, 28, 22, 29, 14, 17, 12, 11, 10, 6],
                "best-individual-distance": 41415.734121341506,
                "worst-individual-sequence": [14, 26, 28, 18, 24, 25, 23, 17, 19, 10, 11, 6, 1, 4, 3, 12, 8, 15, 21, 29, 22, 20, 27, 16, 5, 7, 9, 2, 13],
                "worst-individual-distance": 59264.46954316879,
                "average-distance": 55391.89683175742,
                "individual-distances": []
            }, {
                "best-individual-sequence": [8, 2, 1, 5, 4, 3, 7, 9, 13, 23, 18, 15, 21, 19, 26, 20, 24, 16, 27, 25, 28, 22, 29, 14, 17, 12, 11, 10, 6],
                "best-individual-distance": 41415.734121341506,
                "worst-individual-sequence": [11, 10, 12, 4, 3, 8, 2, 1, 5, 6, 7, 15, 14, 20, 24, 27, 21, 9, 13, 18, 19, 26, 28, 29, 25, 22, 16, 17, 23],
                "worst-individual-distance": 58814.17403671759,
                "average-distance": 54935.74122714241,
                "individual-distances": []
            }, {
                "best-individual-sequence": [8, 2, 1, 5, 4, 3, 7, 9, 13, 23, 18, 15, 21, 19, 26, 20, 24, 16, 27, 25, 28, 22, 29, 14, 17, 12, 11, 10, 6],
                "best-individual-distance": 41415.734121341506,
                "worst-individual-sequence": [13, 9, 12, 10, 11, 6, 7, 8, 1, 2, 5, 25, 4, 3, 14, 24, 19, 28, 21, 15, 26, 29, 22, 20, 27, 16, 17, 18, 23],
                "worst-individual-distance": 58169.606229777826,
                "average-distance": 54456.4203288961,
                "individual-distances": []
            }, {
                "best-individual-sequence": [8, 2, 1, 5, 4, 3, 7, 9, 13, 23, 18, 15, 21, 19, 26, 20, 24, 16, 27, 25, 28, 22, 29, 14, 17, 12, 11, 10, 6],
                "best-individual-distance": 41415.734121341506,
                "worst-individual-sequence": [10, 12, 23, 18, 15, 21, 19, 3, 11, 6, 8, 2, 1, 5, 7, 4, 9, 13, 28, 14, 17, 20, 29, 27, 25, 22, 26, 16, 24],
                "worst-individual-distance": 57713.18251142011,
                "average-distance": 54021.32507172419,
                "individual-distances": []
            }, {
                "best-individual-sequence": [8, 2, 1, 5, 4, 3, 7, 9, 13, 23, 18, 15, 21, 19, 26, 20, 24, 16, 27, 25, 28, 22, 29, 14, 17, 12, 11, 10, 6],
                "best-individual-distance": 41415.734121341506,
                "worst-individual-sequence": [1, 5, 9, 7, 15, 21, 19, 29, 3, 4, 20, 22, 16, 25, 26, 23, 28, 24, 27, 14, 18, 17, 13, 12, 10, 11, 6, 8, 2],
                "worst-individual-distance": 57233.11571182517,
                "average-distance": 53568.28287005797,
                "individual-distances": []
            }, {
                "best-individual-sequence": [8, 2, 1, 5, 4, 3, 7, 9, 13, 23, 18, 15, 21, 19, 26, 20, 24, 16, 27, 25, 28, 22, 29, 14, 17, 12, 11, 10, 6],
                "best-individual-distance": 41415.734121341506,
                "worst-individual-sequence": [10, 4, 27, 20, 25, 16, 24, 23, 14, 3, 8, 2, 1, 5, 7, 9, 13, 18, 19, 28, 21, 15, 26, 29, 22, 17, 12, 11, 6],
                "worst-individual-distance": 56829.67346479137,
                "average-distance": 53215.109011509034,
                "individual-distances": []
            }, {
                "best-individual-sequence": [8, 2, 1, 5, 4, 3, 7, 9, 13, 23, 18, 15, 21, 19, 26, 20, 24, 16, 27, 25, 28, 22, 29, 14, 17, 12, 11, 10, 6],
                "best-individual-distance": 41415.734121341506,
                "worst-individual-sequence": [1, 6, 12, 15, 21, 19, 17, 3, 4, 7, 9, 14, 29, 26, 13, 20, 24, 27, 25, 22, 16, 28, 23, 18, 10, 5, 11, 8, 2],
                "worst-individual-distance": 56405.3772156188,
                "average-distance": 52863.41439692214,
                "individual-distances": []
            }, {
                "best-individual-sequence": [8, 2, 1, 5, 4, 3, 7, 9, 13, 23, 18, 15, 21, 19, 26, 20, 24, 16, 27, 25, 28, 22, 29, 14, 17, 12, 11, 10, 6],
                "best-individual-distance": 41415.734121341506,
                "worst-individual-sequence": [19, 9, 13, 11, 10, 29, 18, 15, 21, 12, 1, 2, 6, 8, 5, 3, 4, 7, 23, 26, 14, 20, 24, 28, 17, 16, 27, 25, 22],
                "worst-individual-distance": 55958.84153718087,
                "average-distance": 52426.454500994245,
                "individual-distances": []
            }, {
                "best-individual-sequence": [8, 2, 1, 5, 4, 3, 7, 9, 13, 23, 18, 15, 21, 19, 26, 20, 24, 16, 27, 25, 28, 22, 29, 14, 17, 12, 11, 10, 6],
                "best-individual-distance": 41415.734121341506,
                "worst-individual-sequence": [10, 11, 6, 8, 2, 1, 5, 7, 4, 3, 13, 25, 28, 18, 15, 21, 26, 24, 19, 14, 29, 22, 20, 27, 16, 17, 23, 9, 12],
                "worst-individual-distance": 55606.28729684997,
                "average-distance": 52085.73980418105,
                "individual-distances": []
            }, {
                "best-individual-sequence": [8, 2, 1, 5, 4, 3, 7, 9, 13, 23, 18, 15, 21, 19, 26, 20, 24, 16, 27, 25, 28, 22, 29, 14, 17, 12, 11, 10, 6],
                "best-individual-distance": 41415.734121341506,
                "worst-individual-sequence": [23, 11, 15, 18, 26, 22, 21, 19, 29, 12, 1, 2, 6, 8, 5, 3, 4, 9, 7, 10, 13, 14, 20, 24, 28, 16, 27, 25, 17],
                "worst-individual-distance": 55158.37320516747,
                "average-distance": 51678.978884166136,
                "individual-distances": []
            }, {
                "best-individual-sequence": [8, 2, 1, 5, 4, 3, 7, 9, 13, 23, 18, 15, 21, 19, 26, 20, 24, 16, 27, 25, 28, 22, 29, 14, 17, 12, 11, 10, 6],
                "best-individual-distance": 41415.734121341506,
                "worst-individual-sequence": [13, 18, 22, 21, 19, 29, 12, 1, 2, 6, 8, 5, 3, 4, 9, 7, 11, 28, 17, 20, 24, 27, 25, 16, 26, 10, 23, 15, 14],
                "worst-individual-distance": 54710.205710420305,
                "average-distance": 51260.10940838551,
                "individual-distances": []
            }, {
                "best-individual-sequence": [8, 2, 1, 5, 4, 3, 7, 9, 13, 23, 18, 15, 21, 19, 26, 20, 24, 16, 27, 25, 28, 22, 29, 14, 17, 12, 11, 10, 6],
                "best-individual-distance": 41415.734121341506,
                "worst-individual-sequence": [4, 3, 8, 2, 1, 5, 7, 9, 10, 6, 21, 15, 19, 23, 29, 26, 13, 20, 24, 27, 25, 28, 22, 16, 14, 17, 18, 11, 12],
                "worst-individual-distance": 54312.13135835289,
                "average-distance": 50924.57283564876,
                "individual-distances": []
            }, {
                "best-individual-sequence": [8, 2, 1, 5, 4, 3, 7, 9, 13, 23, 18, 15, 21, 19, 26, 20, 24, 16, 27, 25, 28, 22, 29, 14, 17, 12, 11, 10, 6],
                "best-individual-distance": 41415.734121341506,
                "worst-individual-sequence": [19, 29, 28, 23, 21, 15, 22, 17, 26, 6, 8, 5, 3, 4, 9, 7, 10, 13, 14, 20, 16, 24, 27, 25, 12, 11, 2, 1, 18],
                "worst-individual-distance": 53864.3883644482,
                "average-distance": 50587.14649978214,
                "individual-distances": []
            }, {
                "best-individual-sequence": [8, 2, 1, 5, 4, 3, 7, 9, 13, 23, 18, 15, 21, 19, 26, 20, 24, 16, 27, 25, 28, 22, 29, 14, 17, 12, 11, 10, 6],
                "best-individual-distance": 41415.734121341506,
                "worst-individual-sequence": [8, 2, 1, 5, 9, 4, 6, 12, 3, 11, 10, 14, 19, 24, 29, 28, 23, 21, 15, 22, 17, 26, 27, 25, 16, 20, 18, 13, 7],
                "worst-individual-distance": 53523.09469643773,
                "average-distance": 50219.432336678154,
                "individual-distances": []
            }, {
                "best-individual-sequence": [6, 8, 5, 4, 7, 3, 9, 23, 21, 29, 19, 15, 13, 14, 20, 24, 27, 25, 28, 22, 17, 26, 16, 18, 12, 11, 10, 1, 2],
                "best-individual-distance": 41255.362666062916,
                "worst-individual-sequence": [9, 7, 5, 8, 2, 4, 1, 6, 12, 23, 18, 15, 21, 26, 20, 24, 27, 25, 28, 22, 14, 16, 29, 17, 19, 3, 13, 11, 10],
                "worst-individual-distance": 53214.191609669964,
                "average-distance": 49916.843024737165,
                "individual-distances": []
            }, {
                "best-individual-sequence": [6, 8, 5, 4, 7, 3, 9, 23, 21, 29, 19, 15, 13, 14, 20, 24, 27, 25, 28, 22, 17, 26, 16, 18, 12, 11, 10, 1, 2],
                "best-individual-distance": 41255.362666062916,
                "worst-individual-sequence": [3, 7, 4, 8, 2, 1, 5, 9, 6, 12, 21, 17, 26, 25, 24, 27, 20, 28, 23, 16, 14, 13, 10, 11, 18, 15, 22, 19, 29],
                "worst-individual-distance": 52878.823351423845,
                "average-distance": 49532.19764142557,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 4, 5, 7, 9, 13, 12, 11, 10, 23, 21, 18, 15, 19, 22, 29, 26, 20, 24, 27, 25, 28, 14, 16, 17, 1, 2, 6, 8],
                "best-individual-distance": 39992.53671806655,
                "worst-individual-sequence": [27, 25, 18, 15, 19, 1, 2, 6, 8, 5, 3, 4, 7, 14, 21, 29, 28, 22, 17, 26, 20, 24, 16, 11, 10, 13, 9, 12, 23],
                "worst-individual-distance": 52538.07177314003,
                "average-distance": 49192.63782118686,
                "individual-distances": []
            }, {
                "best-individual-sequence": [7, 4, 5, 10, 12, 13, 14, 28, 23, 21, 17, 18, 15, 19, 22, 29, 26, 20, 24, 16, 27, 25, 9, 11, 1, 2, 6, 8, 3],
                "best-individual-distance": 39873.27707003278,
                "worst-individual-sequence": [19, 29, 20, 14, 16, 27, 22, 11, 10, 12, 1, 2, 6, 8, 5, 3, 4, 9, 7, 15, 13, 21, 28, 24, 25, 17, 23, 18, 26],
                "worst-individual-distance": 52151.10732722921,
                "average-distance": 48857.85923059956,
                "individual-distances": []
            }, {
                "best-individual-sequence": [7, 4, 5, 10, 12, 13, 14, 28, 23, 21, 17, 18, 15, 19, 22, 29, 26, 20, 24, 16, 27, 25, 9, 11, 1, 2, 6, 8, 3],
                "best-individual-distance": 39873.27707003278,
                "worst-individual-sequence": [3, 10, 6, 12, 14, 20, 24, 27, 25, 26, 19, 16, 23, 18, 15, 21, 29, 22, 28, 17, 13, 8, 11, 7, 4, 2, 1, 5, 9],
                "worst-individual-distance": 51742.673400079366,
                "average-distance": 48540.67846093049,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 3, 4, 7, 9, 13, 14, 16, 17, 23, 21, 18, 15, 19, 22, 29, 26, 20, 24, 27, 28, 25, 12, 11, 10, 1, 2, 6, 8],
                "best-individual-distance": 39775.582514504946,
                "worst-individual-sequence": [10, 12, 1, 2, 6, 8, 5, 3, 23, 18, 19, 4, 7, 14, 21, 29, 28, 22, 17, 26, 20, 24, 16, 27, 25, 9, 13, 15, 11],
                "worst-individual-distance": 51419.81330078769,
                "average-distance": 48258.966392991744,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 3, 4, 9, 7, 13, 14, 17, 16, 23, 21, 18, 15, 19, 22, 29, 26, 20, 24, 27, 25, 28, 1, 11, 10, 12, 2, 6, 8],
                "best-individual-distance": 38714.24392760393,
                "worst-individual-sequence": [3, 4, 9, 7, 18, 15, 12, 13, 14, 23, 28, 17, 29, 26, 21, 20, 24, 27, 25, 22, 19, 16, 10, 11, 1, 2, 6, 8, 5],
                "worst-individual-distance": 51148.370705538306,
                "average-distance": 47933.69358985536,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 3, 4, 9, 7, 13, 14, 17, 16, 23, 21, 18, 15, 19, 22, 29, 26, 20, 24, 27, 25, 28, 1, 11, 10, 12, 2, 6, 8],
                "best-individual-distance": 38714.24392760393,
                "worst-individual-sequence": [8, 3, 4, 5, 7, 9, 13, 12, 11, 28, 25, 21, 15, 29, 26, 17, 22, 23, 19, 18, 20, 24, 27, 14, 16, 10, 1, 2, 6],
                "worst-individual-distance": 50805.68213810522,
                "average-distance": 47617.32903959668,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 4, 9, 7, 13, 14, 16, 17, 23, 21, 18, 15, 19, 22, 29, 26, 20, 24, 27, 25, 28, 12, 11, 10, 1, 2, 6, 8, 5],
                "best-individual-distance": 37721.60155265096,
                "worst-individual-sequence": [7, 4, 8, 2, 1, 3, 5, 9, 11, 10, 6, 12, 13, 14, 20, 24, 27, 25, 28, 22, 29, 17, 16, 15, 18, 21, 23, 26, 19],
                "worst-individual-distance": 50558.85760938076,
                "average-distance": 47374.464334736665,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 4, 9, 7, 13, 14, 16, 17, 23, 21, 18, 15, 19, 22, 29, 26, 20, 24, 27, 25, 28, 12, 11, 10, 1, 2, 6, 8, 5],
                "best-individual-distance": 37721.60155265096,
                "worst-individual-sequence": [12, 3, 4, 8, 2, 1, 5, 7, 9, 10, 11, 19, 15, 18, 21, 23, 26, 24, 17, 20, 27, 25, 16, 22, 29, 28, 6, 14, 13],
                "worst-individual-distance": 50183.72286718029,
                "average-distance": 47061.96283239136,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 4, 9, 7, 13, 14, 16, 17, 23, 21, 18, 15, 19, 22, 29, 26, 20, 24, 27, 25, 28, 12, 11, 10, 1, 2, 6, 8, 5],
                "best-individual-distance": 37721.60155265096,
                "worst-individual-sequence": [19, 28, 21, 26, 12, 3, 2, 6, 1, 8, 5, 7, 4, 9, 13, 14, 17, 29, 22, 20, 27, 16, 25, 24, 23, 18, 11, 10, 15],
                "worst-individual-distance": 49855.26896684884,
                "average-distance": 46710.51093591409,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 4, 9, 7, 13, 14, 16, 17, 23, 21, 18, 15, 19, 22, 29, 26, 20, 24, 27, 25, 28, 12, 11, 10, 1, 2, 6, 8, 5],
                "best-individual-distance": 37721.60155265096,
                "worst-individual-sequence": [3, 4, 9, 7, 6, 8, 13, 16, 17, 23, 21, 18, 15, 19, 22, 29, 26, 20, 24, 27, 25, 28, 12, 11, 10, 1, 2, 14, 5],
                "worst-individual-distance": 49574.49404526025,
                "average-distance": 46471.57082462469,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 3, 4, 7, 9, 13, 14, 28, 23, 18, 15, 21, 19, 17, 22, 29, 26, 20, 24, 27, 25, 16, 12, 11, 10, 2, 1, 6, 8],
                "best-individual-distance": 37291.36714061114,
                "worst-individual-sequence": [6, 8, 5, 3, 4, 7, 9, 13, 18, 19, 28, 23, 15, 14, 21, 29, 20, 24, 12, 17, 26, 27, 25, 16, 22, 11, 10, 1, 2],
                "worst-individual-distance": 49250.15684762028,
                "average-distance": 46167.27824127636,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 4, 9, 7, 13, 14, 16, 17, 23, 21, 18, 15, 19, 22, 29, 28, 26, 20, 24, 27, 25, 1, 11, 10, 12, 2, 6, 8, 5],
                "best-individual-distance": 36912.16690983766,
                "worst-individual-sequence": [5, 3, 4, 11, 9, 7, 10, 13, 16, 14, 26, 19, 29, 17, 22, 20, 27, 24, 25, 28, 21, 23, 18, 15, 12, 1, 2, 6, 8],
                "worst-individual-distance": 48897.25955439795,
                "average-distance": 45904.445539222776,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 4, 9, 7, 13, 14, 16, 17, 23, 21, 18, 15, 19, 22, 29, 28, 26, 20, 24, 27, 25, 1, 11, 10, 12, 2, 6, 8, 5],
                "best-individual-distance": 36912.16690983766,
                "worst-individual-sequence": [6, 8, 5, 3, 4, 7, 9, 14, 28, 22, 23, 18, 19, 17, 20, 24, 27, 21, 29, 25, 12, 15, 26, 16, 13, 11, 10, 1, 2],
                "worst-individual-distance": 48545.102526241906,
                "average-distance": 45635.759896074174,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 3, 4, 7, 9, 13, 14, 28, 22, 23, 18, 15, 19, 29, 21, 17, 26, 20, 24, 27, 25, 16, 12, 11, 10, 2, 1, 6, 8],
                "best-individual-distance": 35782.26790359679,
                "worst-individual-sequence": [3, 7, 4, 8, 2, 1, 5, 9, 11, 10, 6, 12, 13, 14, 24, 28, 23, 21, 15, 22, 17, 26, 27, 25, 16, 20, 18, 19, 29],
                "worst-individual-distance": 48264.74779443263,
                "average-distance": 45386.0172716904,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 3, 4, 7, 9, 13, 14, 28, 22, 23, 18, 15, 19, 29, 21, 17, 26, 20, 24, 27, 25, 16, 12, 11, 10, 2, 1, 6, 8],
                "best-individual-distance": 35782.26790359679,
                "worst-individual-sequence": [12, 8, 6, 2, 1, 5, 7, 4, 3, 10, 19, 23, 18, 15, 21, 26, 24, 25, 28, 29, 22, 20, 27, 16, 17, 13, 9, 14, 11],
                "worst-individual-distance": 47919.07307636234,
                "average-distance": 45100.206788272706,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 3, 4, 7, 9, 13, 14, 28, 22, 23, 18, 15, 19, 29, 21, 17, 26, 20, 24, 27, 25, 16, 12, 11, 10, 2, 1, 6, 8],
                "best-individual-distance": 35782.26790359679,
                "worst-individual-sequence": [4, 7, 9, 13, 14, 11, 10, 19, 22, 28, 16, 23, 18, 15, 21, 29, 17, 20, 24, 27, 26, 25, 12, 1, 2, 6, 8, 5, 3],
                "worst-individual-distance": 47652.79727299358,
                "average-distance": 44849.11394640049,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 3, 4, 7, 9, 13, 14, 28, 22, 23, 18, 15, 19, 29, 21, 17, 26, 20, 24, 27, 25, 16, 12, 11, 10, 2, 1, 6, 8],
                "best-individual-distance": 35782.26790359679,
                "worst-individual-sequence": [8, 5, 3, 4, 7, 9, 14, 17, 16, 23, 21, 18, 15, 19, 22, 29, 26, 20, 24, 27, 25, 28, 12, 11, 10, 1, 13, 2, 6],
                "worst-individual-distance": 47313.555644487285,
                "average-distance": 44579.269876557926,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 3, 4, 7, 9, 13, 14, 17, 23, 18, 15, 19, 22, 26, 21, 29, 28, 20, 24, 27, 25, 16, 12, 10, 11, 6, 2, 1, 8],
                "best-individual-distance": 35647.033847177176,
                "worst-individual-sequence": [5, 3, 4, 7, 9, 11, 10, 1, 29, 23, 19, 15, 13, 14, 20, 24, 27, 25, 28, 22, 17, 26, 18, 21, 12, 16, 2, 6, 8],
                "worst-individual-distance": 47062.144028670744,
                "average-distance": 44336.29145816284,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 3, 4, 7, 9, 13, 14, 17, 23, 18, 15, 19, 22, 26, 21, 29, 28, 20, 24, 27, 25, 16, 12, 10, 11, 6, 2, 1, 8],
                "best-individual-distance": 35647.033847177176,
                "worst-individual-sequence": [21, 29, 19, 11, 10, 12, 1, 2, 6, 8, 5, 3, 4, 9, 7, 15, 13, 14, 20, 24, 28, 16, 27, 25, 22, 26, 17, 23, 18],
                "worst-individual-distance": 46743.19765461266,
                "average-distance": 44089.29836703439,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 3, 4, 7, 9, 13, 14, 17, 23, 18, 15, 19, 22, 26, 21, 29, 28, 20, 24, 27, 25, 16, 12, 10, 11, 6, 2, 1, 8],
                "best-individual-distance": 35647.033847177176,
                "worst-individual-sequence": [5, 4, 3, 7, 9, 14, 20, 22, 16, 21, 26, 17, 23, 18, 15, 12, 19, 29, 24, 27, 25, 28, 13, 11, 10, 1, 2, 6, 8],
                "worst-individual-distance": 46520.973985734454,
                "average-distance": 43855.17538097919,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 3, 4, 7, 9, 13, 14, 17, 23, 18, 15, 19, 22, 26, 21, 29, 28, 20, 24, 27, 25, 16, 12, 10, 11, 6, 2, 1, 8],
                "best-individual-distance": 35647.033847177176,
                "worst-individual-sequence": [9, 11, 10, 12, 13, 7, 14, 28, 17, 23, 21, 18, 15, 19, 22, 29, 26, 20, 24, 27, 25, 16, 1, 2, 6, 8, 5, 4, 3],
                "worst-individual-distance": 46232.279625362586,
                "average-distance": 43687.660208028305,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 3, 4, 7, 9, 13, 14, 17, 23, 18, 15, 19, 22, 26, 21, 29, 28, 20, 24, 27, 25, 16, 12, 10, 11, 6, 2, 1, 8],
                "best-individual-distance": 35647.033847177176,
                "worst-individual-sequence": [4, 2, 1, 11, 10, 6, 12, 8, 5, 3, 7, 9, 13, 14, 24, 28, 23, 21, 15, 22, 17, 26, 27, 25, 16, 20, 18, 19, 29],
                "worst-individual-distance": 46024.04447542677,
                "average-distance": 43481.099708050715,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 3, 4, 7, 9, 13, 14, 17, 23, 18, 15, 19, 22, 26, 21, 29, 28, 20, 24, 27, 25, 16, 12, 10, 11, 6, 2, 1, 8],
                "best-individual-distance": 35647.033847177176,
                "worst-individual-sequence": [7, 9, 13, 14, 11, 21, 18, 15, 19, 22, 29, 17, 26, 23, 16, 20, 27, 24, 25, 28, 12, 10, 1, 2, 6, 8, 5, 3, 4],
                "worst-individual-distance": 45725.189060284116,
                "average-distance": 43194.593320923836,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 3, 4, 7, 9, 13, 14, 17, 23, 18, 15, 19, 22, 26, 21, 29, 28, 20, 24, 27, 25, 16, 12, 10, 11, 6, 2, 1, 8],
                "best-individual-distance": 35647.033847177176,
                "worst-individual-sequence": [4, 7, 9, 11, 3, 13, 14, 17, 16, 23, 21, 18, 15, 19, 22, 29, 26, 20, 24, 27, 25, 28, 12, 2, 10, 8, 6, 1, 5],
                "worst-individual-distance": 45414.2820109351,
                "average-distance": 42960.12186000966,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 3, 4, 7, 9, 13, 14, 17, 23, 18, 15, 19, 22, 26, 21, 29, 28, 20, 24, 27, 25, 16, 12, 10, 11, 6, 2, 1, 8],
                "best-individual-distance": 35647.033847177176,
                "worst-individual-sequence": [9, 7, 4, 14, 28, 22, 21, 29, 17, 20, 16, 25, 26, 23, 18, 15, 19, 24, 27, 12, 13, 11, 10, 1, 2, 6, 8, 5, 3],
                "worst-individual-distance": 45216.58136740972,
                "average-distance": 42723.232215591976,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 4, 3, 7, 9, 13, 14, 17, 28, 23, 21, 18, 15, 19, 22, 29, 26, 20, 24, 27, 25, 16, 12, 11, 10, 6, 8, 2, 1],
                "best-individual-distance": 35297.38329849992,
                "worst-individual-sequence": [4, 7, 9, 14, 12, 18, 19, 23, 15, 22, 17, 29, 16, 21, 26, 20, 24, 27, 25, 28, 13, 11, 10, 1, 2, 6, 8, 5, 3],
                "worst-individual-distance": 44939.796658403706,
                "average-distance": 42479.552258001815,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 4, 3, 7, 9, 13, 14, 17, 28, 23, 21, 18, 15, 19, 22, 29, 26, 20, 24, 27, 25, 16, 12, 11, 10, 6, 8, 2, 1],
                "best-individual-distance": 35297.38329849992,
                "worst-individual-sequence": [7, 9, 12, 11, 10, 15, 21, 13, 14, 19, 29, 16, 26, 25, 24, 27, 20, 28, 17, 22, 23, 18, 1, 2, 6, 8, 3, 4, 5],
                "worst-individual-distance": 44756.53456366425,
                "average-distance": 42240.73008248292,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 7, 9, 13, 14, 28, 23, 21, 17, 18, 15, 19, 22, 29, 26, 20, 24, 27, 25, 16, 8, 12, 10, 11, 6, 2, 1, 5],
                "best-individual-distance": 33120.41350192242,
                "worst-individual-sequence": [6, 8, 3, 7, 9, 1, 15, 23, 13, 14, 25, 26, 19, 22, 21, 29, 28, 20, 24, 27, 16, 17, 12, 4, 5, 11, 10, 18, 2],
                "worst-individual-distance": 44454.755471892735,
                "average-distance": 42018.20923195497,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 7, 9, 13, 14, 28, 23, 21, 17, 18, 15, 19, 22, 29, 26, 20, 24, 27, 25, 16, 8, 12, 10, 11, 6, 2, 1, 5],
                "best-individual-distance": 33120.41350192242,
                "worst-individual-sequence": [5, 11, 10, 1, 2, 6, 8, 7, 9, 17, 15, 18, 21, 23, 26, 24, 19, 20, 27, 25, 16, 22, 29, 28, 14, 13, 12, 3, 4],
                "worst-individual-distance": 44338.20410077841,
                "average-distance": 41773.6397504997,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 7, 9, 13, 14, 28, 23, 21, 17, 18, 15, 19, 22, 29, 26, 20, 24, 27, 25, 16, 8, 12, 10, 11, 6, 2, 1, 5],
                "best-individual-distance": 33120.41350192242,
                "worst-individual-sequence": [5, 3, 4, 9, 7, 13, 14, 24, 27, 16, 20, 25, 22, 18, 15, 21, 19, 29, 28, 17, 26, 23, 11, 10, 12, 1, 2, 6, 8],
                "worst-individual-distance": 44073.10610216168,
                "average-distance": 41522.283044605836,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 7, 9, 13, 14, 28, 23, 21, 17, 18, 15, 19, 22, 29, 26, 20, 24, 27, 25, 16, 8, 12, 10, 11, 6, 2, 1, 5],
                "best-individual-distance": 33120.41350192242,
                "worst-individual-sequence": [3, 4, 9, 7, 6, 8, 13, 16, 17, 23, 21, 18, 15, 19, 22, 29, 26, 20, 24, 27, 25, 28, 12, 11, 10, 1, 2, 14, 5],
                "worst-individual-distance": 43827.05605977095,
                "average-distance": 41276.06538085392,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 7, 9, 13, 14, 28, 23, 21, 17, 18, 15, 19, 22, 29, 26, 20, 24, 27, 25, 16, 8, 12, 10, 11, 6, 2, 1, 5],
                "best-individual-distance": 33120.41350192242,
                "worst-individual-sequence": [2, 6, 8, 7, 9, 19, 15, 18, 21, 23, 17, 28, 14, 20, 24, 16, 27, 25, 22, 26, 29, 13, 12, 3, 4, 5, 11, 10, 1],
                "worst-individual-distance": 43524.33444424446,
                "average-distance": 41037.3385017114,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 7, 9, 13, 14, 28, 23, 21, 17, 18, 15, 19, 22, 29, 26, 20, 24, 27, 25, 16, 8, 12, 10, 11, 6, 2, 1, 5],
                "best-individual-distance": 33120.41350192242,
                "worst-individual-sequence": [15, 2, 6, 8, 3, 4, 5, 7, 9, 13, 12, 11, 10, 1, 21, 19, 29, 16, 20, 17, 28, 26, 24, 27, 25, 14, 22, 23, 18],
                "worst-individual-distance": 43292.569716582366,
                "average-distance": 40814.09660016399,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 7, 9, 13, 14, 28, 23, 21, 17, 18, 15, 19, 22, 29, 26, 20, 24, 27, 25, 16, 8, 12, 10, 11, 6, 2, 1, 5],
                "best-individual-distance": 33120.41350192242,
                "worst-individual-sequence": [7, 9, 13, 12, 11, 15, 18, 28, 23, 21, 17, 19, 29, 20, 24, 16, 27, 25, 22, 26, 14, 1, 10, 2, 6, 8, 3, 4, 5],
                "worst-individual-distance": 43131.544955692385,
                "average-distance": 40583.15054166848,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 4, 3, 7, 9, 13, 14, 17, 28, 23, 21, 18, 15, 19, 22, 29, 26, 20, 24, 27, 25, 16, 12, 11, 10, 1, 2, 6, 8],
                "best-individual-distance": 32811.15137890692,
                "worst-individual-sequence": [8, 5, 4, 3, 7, 9, 18, 15, 23, 13, 14, 20, 24, 27, 25, 26, 19, 22, 21, 29, 28, 16, 17, 1, 10, 12, 11, 2, 6],
                "worst-individual-distance": 42870.6464741711,
                "average-distance": 40323.27081384769,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 4, 3, 7, 9, 13, 14, 17, 28, 23, 21, 18, 15, 19, 22, 29, 26, 20, 24, 27, 25, 16, 12, 11, 10, 1, 2, 6, 8],
                "best-individual-distance": 32811.15137890692,
                "worst-individual-sequence": [5, 4, 3, 7, 9, 13, 14, 17, 28, 23, 21, 18, 15, 19, 22, 29, 26, 20, 24, 27, 25, 16, 12, 11, 10, 6, 8, 2, 1],
                "worst-individual-distance": 42685.34172430126,
                "average-distance": 40092.4492217396,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 4, 3, 7, 9, 13, 14, 17, 28, 23, 21, 18, 15, 19, 22, 29, 26, 20, 24, 27, 25, 16, 12, 11, 10, 1, 2, 6, 8],
                "best-individual-distance": 32811.15137890692,
                "worst-individual-sequence": [1, 2, 5, 3, 4, 9, 7, 8, 13, 21, 28, 18, 15, 19, 22, 29, 26, 20, 24, 27, 25, 14, 16, 23, 17, 12, 11, 10, 6],
                "worst-individual-distance": 42425.012270654035,
                "average-distance": 39821.95492298811,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 4, 3, 7, 9, 13, 14, 17, 28, 23, 21, 18, 15, 19, 22, 29, 26, 20, 24, 27, 25, 16, 12, 11, 10, 1, 2, 6, 8],
                "best-individual-distance": 32811.15137890692,
                "worst-individual-sequence": [1, 5, 4, 3, 7, 9, 13, 2, 18, 15, 21, 19, 20, 24, 16, 27, 25, 17, 28, 26, 22, 29, 14, 12, 11, 10, 6, 8, 23],
                "worst-individual-distance": 42197.45621840705,
                "average-distance": 39586.271714823044,
                "individual-distances": []
            }
        ],
        [
            [{
                "time_cost": 0
            }], {
                "best-individual-sequence": [3, 1, 28, 13, 14, 16, 26, 23, 22, 19, 21, 17, 15, 18, 4, 7, 8, 12, 20, 27, 24, 5, 29, 25, 2, 11, 9, 6, 10],
                "best-individual-distance": 70661.70660715326,
                "worst-individual-sequence": [5, 25, 1, 24, 4, 2, 27, 7, 23, 9, 10, 21, 20, 16, 12, 28, 18, 26, 17, 22, 15, 3, 14, 13, 29, 8, 11, 6, 19],
                "worst-individual-distance": 120326.46505439148,
                "average-distance": 106214.9609598176,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 1, 28, 13, 14, 16, 26, 23, 22, 19, 21, 17, 15, 18, 4, 7, 8, 12, 20, 27, 24, 5, 29, 25, 2, 11, 9, 6, 10],
                "best-individual-distance": 70661.70660715326,
                "worst-individual-sequence": [9, 13, 25, 20, 22, 7, 27, 15, 18, 1, 14, 8, 17, 19, 10, 2, 28, 3, 5, 12, 26, 4, 23, 16, 29, 24, 6, 11, 21],
                "worst-individual-distance": 115838.42195852112,
                "average-distance": 103522.9868069506,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 1, 28, 13, 14, 16, 26, 23, 22, 19, 21, 17, 15, 18, 4, 7, 8, 12, 20, 27, 24, 5, 29, 25, 2, 11, 9, 6, 10],
                "best-individual-distance": 70661.70660715326,
                "worst-individual-sequence": [29, 24, 1, 4, 15, 27, 22, 14, 8, 20, 21, 11, 5, 6, 25, 16, 10, 12, 26, 2, 28, 13, 18, 23, 3, 9, 19, 7, 17],
                "worst-individual-distance": 112353.92987486205,
                "average-distance": 101167.25569006905,
                "individual-distances": []
            }, {
                "best-individual-sequence": [14, 15, 22, 25, 24, 17, 19, 10, 5, 13, 9, 4, 3, 7, 6, 8, 1, 2, 11, 29, 20, 16, 23, 18, 26, 28, 21, 12, 27],
                "best-individual-distance": 69313.57223684271,
                "worst-individual-sequence": [24, 4, 1, 17, 19, 8, 13, 11, 26, 14, 15, 28, 25, 2, 20, 21, 27, 22, 16, 7, 23, 29, 6, 18, 12, 10, 9, 5, 3],
                "worst-individual-distance": 109613.79595039696,
                "average-distance": 98879.86046602526,
                "individual-distances": []
            }, {
                "best-individual-sequence": [14, 15, 22, 25, 24, 17, 19, 10, 5, 13, 9, 4, 3, 7, 6, 8, 1, 2, 11, 29, 20, 16, 23, 18, 26, 28, 21, 12, 27],
                "best-individual-distance": 69313.57223684271,
                "worst-individual-sequence": [29, 6, 2, 12, 28, 10, 7, 4, 22, 27, 13, 26, 19, 1, 20, 24, 3, 9, 17, 16, 15, 25, 8, 18, 21, 14, 11, 5, 23],
                "worst-individual-distance": 107176.33204062055,
                "average-distance": 96909.86366779596,
                "individual-distances": []
            }, {
                "best-individual-sequence": [14, 15, 22, 25, 24, 17, 19, 10, 5, 13, 9, 4, 3, 7, 6, 8, 1, 2, 11, 29, 20, 16, 23, 18, 26, 28, 21, 12, 27],
                "best-individual-distance": 69313.57223684271,
                "worst-individual-sequence": [2, 13, 26, 10, 28, 29, 23, 12, 7, 16, 17, 25, 22, 3, 11, 4, 9, 19, 14, 21, 24, 1, 20, 27, 8, 6, 18, 15, 5],
                "worst-individual-distance": 104761.7309223946,
                "average-distance": 94869.29466056192,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 2, 13, 29, 23, 24, 25, 16, 21, 28, 10, 3, 9, 7, 20, 17, 26, 27, 12, 8, 6, 11, 4, 22, 19, 15, 18, 14, 5],
                "best-individual-distance": 67362.25966723014,
                "worst-individual-sequence": [7, 8, 9, 18, 29, 23, 21, 2, 12, 27, 16, 24, 15, 28, 6, 22, 3, 19, 13, 17, 11, 25, 20, 5, 10, 14, 26, 1, 4],
                "worst-individual-distance": 102499.98809442154,
                "average-distance": 92872.99424811837,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 2, 13, 29, 23, 24, 25, 16, 21, 28, 10, 3, 9, 7, 20, 17, 26, 27, 12, 8, 6, 11, 4, 22, 19, 15, 18, 14, 5],
                "best-individual-distance": 67362.25966723014,
                "worst-individual-sequence": [21, 13, 1, 7, 19, 22, 9, 10, 16, 23, 20, 4, 26, 14, 29, 15, 6, 5, 25, 17, 11, 12, 18, 2, 8, 3, 27, 24, 28],
                "worst-individual-distance": 100295.72862258524,
                "average-distance": 91135.07003101871,
                "individual-distances": []
            }, {
                "best-individual-sequence": [1, 2, 13, 29, 23, 24, 25, 16, 21, 28, 10, 3, 9, 7, 20, 17, 26, 27, 12, 8, 6, 11, 4, 22, 19, 15, 18, 14, 5],
                "best-individual-distance": 67362.25966723014,
                "worst-individual-sequence": [4, 24, 22, 11, 19, 5, 21, 23, 16, 8, 10, 17, 26, 12, 7, 3, 9, 14, 29, 6, 28, 13, 2, 1, 15, 18, 25, 27, 20],
                "worst-individual-distance": 98197.67246368871,
                "average-distance": 89324.74697711437,
                "individual-distances": []
            }, {
                "best-individual-sequence": [22, 21, 26, 25, 24, 17, 19, 10, 5, 13, 9, 4, 3, 7, 6, 8, 1, 2, 29, 12, 20, 16, 23, 18, 27, 28, 14, 11, 15],
                "best-individual-distance": 61396.14573843948,
                "worst-individual-sequence": [24, 5, 9, 29, 3, 2, 18, 13, 26, 25, 20, 15, 14, 22, 12, 6, 10, 8, 11, 4, 1, 21, 17, 27, 7, 23, 19, 16, 28],
                "worst-individual-distance": 96274.84728257846,
                "average-distance": 87595.54443841592,
                "individual-distances": []
            }, {
                "best-individual-sequence": [22, 21, 26, 25, 24, 17, 19, 10, 5, 13, 9, 4, 3, 7, 6, 8, 1, 2, 29, 12, 20, 16, 23, 18, 27, 28, 14, 11, 15],
                "best-individual-distance": 61396.14573843948,
                "worst-individual-sequence": [27, 16, 11, 1, 8, 23, 18, 26, 24, 10, 14, 19, 29, 17, 20, 21, 3, 28, 25, 5, 2, 4, 7, 22, 6, 15, 12, 9, 13],
                "worst-individual-distance": 94430.30486823243,
                "average-distance": 86052.33473733756,
                "individual-distances": []
            }, {
                "best-individual-sequence": [16, 25, 23, 22, 17, 19, 10, 11, 5, 13, 9, 4, 3, 7, 6, 8, 1, 2, 24, 15, 14, 27, 28, 12, 21, 29, 26, 20, 18],
                "best-individual-distance": 60442.57529485765,
                "worst-individual-sequence": [27, 9, 17, 4, 3, 28, 20, 16, 25, 5, 7, 14, 6, 8, 13, 24, 15, 19, 21, 10, 2, 11, 26, 29, 22, 18, 12, 1, 23],
                "worst-individual-distance": 92648.14493144798,
                "average-distance": 84521.30577268914,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 15, 29, 24, 25, 28, 27, 10, 6, 5, 9, 4, 3, 7, 8, 1, 2, 11, 13, 20, 16, 23, 18, 26, 14, 22, 19, 12, 17],
                "best-individual-distance": 57372.11465058996,
                "worst-individual-sequence": [15, 16, 21, 2, 4, 7, 11, 17, 14, 24, 26, 10, 27, 20, 13, 3, 8, 19, 25, 23, 9, 5, 6, 1, 18, 28, 22, 12, 29],
                "worst-individual-distance": 91130.77493630117,
                "average-distance": 83231.64296957669,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 15, 29, 24, 25, 28, 27, 10, 6, 5, 9, 4, 3, 7, 8, 1, 2, 11, 13, 20, 16, 23, 18, 26, 14, 22, 19, 12, 17],
                "best-individual-distance": 57372.11465058996,
                "worst-individual-sequence": [1, 3, 10, 23, 22, 9, 12, 26, 29, 20, 8, 2, 6, 4, 11, 19, 27, 14, 5, 7, 15, 28, 18, 17, 25, 16, 21, 24, 13],
                "worst-individual-distance": 89387.98162316569,
                "average-distance": 81987.12671906277,
                "individual-distances": []
            }, {
                "best-individual-sequence": [21, 15, 29, 24, 25, 28, 27, 10, 6, 5, 9, 4, 3, 7, 8, 1, 2, 11, 13, 20, 16, 23, 18, 26, 14, 22, 19, 12, 17],
                "best-individual-distance": 57372.11465058996,
                "worst-individual-sequence": [20, 18, 21, 4, 11, 3, 2, 8, 9, 24, 27, 12, 1, 6, 16, 10, 19, 25, 15, 14, 22, 7, 5, 13, 28, 23, 26, 29, 17],
                "worst-individual-distance": 87998.38162428165,
                "average-distance": 80891.83994536485,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 28, 20, 22, 17, 19, 10, 11, 5, 13, 9, 4, 3, 7, 6, 8, 1, 2, 24, 15, 14, 25, 21, 18, 27, 16, 12, 29, 26],
                "best-individual-distance": 56008.89883489557,
                "worst-individual-sequence": [12, 13, 21, 26, 17, 16, 18, 23, 19, 25, 15, 11, 24, 27, 28, 3, 2, 20, 22, 14, 8, 4, 7, 29, 10, 6, 9, 1, 5],
                "worst-individual-distance": 86693.60518876674,
                "average-distance": 79686.28889054255,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 28, 20, 22, 17, 19, 10, 11, 5, 13, 9, 4, 3, 7, 6, 8, 1, 2, 24, 15, 14, 25, 21, 18, 27, 16, 12, 29, 26],
                "best-individual-distance": 56008.89883489557,
                "worst-individual-sequence": [14, 23, 29, 19, 25, 10, 13, 12, 11, 2, 5, 21, 8, 15, 24, 3, 4, 17, 27, 20, 26, 18, 9, 6, 1, 7, 22, 28, 16],
                "worst-individual-distance": 85408.83689878012,
                "average-distance": 78543.61708480098,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 28, 20, 22, 17, 19, 10, 11, 5, 13, 9, 4, 3, 7, 6, 8, 1, 2, 24, 15, 14, 25, 21, 18, 27, 16, 12, 29, 26],
                "best-individual-distance": 56008.89883489557,
                "worst-individual-sequence": [22, 3, 7, 8, 13, 17, 4, 9, 1, 19, 25, 16, 20, 24, 27, 21, 28, 15, 18, 2, 10, 23, 26, 14, 29, 6, 12, 5, 11],
                "worst-individual-distance": 84043.15840577564,
                "average-distance": 77512.9623188693,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 28, 20, 22, 17, 19, 10, 11, 5, 13, 9, 4, 3, 7, 6, 8, 1, 2, 24, 15, 14, 25, 21, 18, 27, 16, 12, 29, 26],
                "best-individual-distance": 56008.89883489557,
                "worst-individual-sequence": [26, 23, 21, 11, 8, 19, 29, 27, 24, 25, 2, 5, 9, 7, 20, 17, 12, 15, 14, 6, 4, 13, 18, 22, 10, 3, 1, 28, 16],
                "worst-individual-distance": 82579.14776483021,
                "average-distance": 76528.1279682122,
                "individual-distances": []
            }, {
                "best-individual-sequence": [27, 16, 18, 13, 25, 28, 24, 10, 6, 5, 9, 4, 3, 7, 8, 1, 2, 11, 12, 17, 19, 22, 29, 15, 20, 21, 26, 14, 23],
                "best-individual-distance": 55463.80028843993,
                "worst-individual-sequence": [26, 13, 24, 29, 17, 21, 25, 16, 15, 19, 22, 18, 27, 14, 8, 7, 10, 11, 2, 1, 20, 5, 12, 4, 28, 23, 6, 3, 9],
                "worst-individual-distance": 81391.27391010585,
                "average-distance": 75494.97958335713,
                "individual-distances": []
            }, {
                "best-individual-sequence": [27, 16, 18, 13, 25, 28, 24, 10, 6, 5, 9, 4, 3, 7, 8, 1, 2, 11, 12, 17, 19, 22, 29, 15, 20, 21, 26, 14, 23],
                "best-individual-distance": 55463.80028843993,
                "worst-individual-sequence": [24, 26, 20, 28, 5, 29, 25, 13, 23, 18, 21, 27, 14, 2, 1, 17, 3, 12, 8, 6, 10, 11, 4, 22, 19, 15, 9, 7, 16],
                "worst-individual-distance": 80347.61077788947,
                "average-distance": 74419.12177510842,
                "individual-distances": []
            }, {
                "best-individual-sequence": [27, 16, 18, 13, 25, 28, 24, 10, 6, 5, 9, 4, 3, 7, 8, 1, 2, 11, 12, 17, 19, 22, 29, 15, 20, 21, 26, 14, 23],
                "best-individual-distance": 55463.80028843993,
                "worst-individual-sequence": [10, 6, 5, 22, 13, 9, 3, 25, 20, 11, 21, 26, 23, 24, 17, 12, 15, 16, 27, 14, 8, 4, 7, 28, 19, 29, 18, 2, 1],
                "worst-individual-distance": 79542.04518698198,
                "average-distance": 73710.96008882661,
                "individual-distances": []
            }, {
                "best-individual-sequence": [22, 17, 19, 29, 28, 23, 16, 11, 5, 13, 9, 4, 3, 7, 6, 8, 1, 2, 12, 15, 10, 25, 21, 18, 27, 24, 14, 26, 20],
                "best-individual-distance": 55344.92885740162,
                "worst-individual-sequence": [15, 14, 28, 3, 9, 18, 11, 13, 2, 8, 1, 12, 4, 6, 10, 7, 20, 24, 16, 21, 26, 27, 25, 19, 22, 23, 29, 17, 5],
                "worst-individual-distance": 78502.93676463839,
                "average-distance": 72813.88515431323,
                "individual-distances": []
            }, {
                "best-individual-sequence": [28, 20, 22, 17, 19, 10, 11, 5, 13, 9, 4, 3, 7, 6, 8, 1, 2, 16, 15, 12, 25, 21, 23, 18, 27, 24, 14, 29, 26],
                "best-individual-distance": 54633.47476927891,
                "worst-individual-sequence": [8, 16, 13, 20, 28, 29, 26, 23, 22, 19, 21, 17, 15, 18, 4, 7, 27, 5, 10, 25, 24, 3, 1, 11, 6, 2, 9, 14, 12],
                "worst-individual-distance": 77716.45837413683,
                "average-distance": 71796.6311206163,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 10, 14, 16, 28, 15, 21, 24, 11, 12, 19, 18, 17, 26, 20, 22, 23, 25, 27, 29, 13, 4, 3, 7, 6, 1, 2, 5, 8],
                "best-individual-distance": 53727.76936303281,
                "worst-individual-sequence": [9, 5, 11, 20, 6, 7, 13, 12, 17, 4, 21, 29, 26, 14, 23, 25, 24, 27, 16, 18, 10, 2, 1, 3, 8, 15, 28, 19, 22],
                "worst-individual-distance": 76734.72995083705,
                "average-distance": 70845.31887395881,
                "individual-distances": []
            }, {
                "best-individual-sequence": [9, 3, 4, 7, 5, 6, 12, 8, 1, 2, 10, 15, 18, 23, 29, 17, 20, 24, 16, 21, 26, 27, 25, 11, 22, 28, 14, 19, 13],
                "best-individual-distance": 51580.57267629272,
                "worst-individual-sequence": [18, 15, 27, 17, 7, 3, 24, 13, 1, 2, 4, 11, 10, 6, 19, 22, 25, 26, 16, 28, 21, 29, 9, 8, 5, 20, 23, 12, 14],
                "worst-individual-distance": 75986.55921811172,
                "average-distance": 69941.00016259341,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 19, 14, 12, 11, 5, 13, 9, 4, 3, 7, 24, 8, 1, 2, 10, 15, 18, 6, 27, 28, 21, 29, 26, 20, 16, 25, 23, 22],
                "best-individual-distance": 49979.31083600865,
                "worst-individual-sequence": [24, 27, 10, 6, 2, 5, 8, 15, 12, 14, 7, 1, 11, 19, 22, 18, 4, 3, 25, 26, 20, 17, 16, 28, 21, 9, 29, 23, 13],
                "worst-individual-distance": 74949.0918938914,
                "average-distance": 68973.60700101683,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 19, 14, 12, 11, 5, 13, 9, 4, 3, 7, 24, 8, 1, 2, 10, 15, 18, 6, 27, 28, 21, 29, 26, 20, 16, 25, 23, 22],
                "best-individual-distance": 49979.31083600865,
                "worst-individual-sequence": [16, 27, 11, 2, 6, 1, 3, 5, 10, 29, 26, 15, 23, 28, 18, 20, 22, 17, 21, 8, 19, 25, 24, 12, 9, 4, 14, 7, 13],
                "worst-individual-distance": 73970.16957725944,
                "average-distance": 68049.3205555717,
                "individual-distances": []
            }, {
                "best-individual-sequence": [17, 19, 14, 12, 11, 5, 13, 9, 4, 3, 7, 24, 8, 1, 2, 10, 15, 18, 6, 27, 28, 21, 29, 26, 20, 16, 25, 23, 22],
                "best-individual-distance": 49979.31083600865,
                "worst-individual-sequence": [27, 15, 5, 4, 21, 25, 26, 13, 12, 10, 9, 7, 6, 8, 1, 2, 11, 24, 16, 28, 29, 14, 23, 22, 19, 18, 20, 17, 3],
                "worst-individual-distance": 72840.87809107918,
                "average-distance": 67066.28102245765,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 8, 11, 5, 2, 1, 6, 10, 12, 18, 21, 9, 13, 17, 27, 20, 25, 26, 16, 24, 3, 15, 19, 22, 28, 29, 23, 14, 7],
                "best-individual-distance": 49481.563275697525,
                "worst-individual-sequence": [13, 17, 4, 24, 21, 29, 26, 25, 16, 15, 12, 19, 22, 18, 27, 14, 8, 7, 10, 11, 5, 28, 23, 20, 2, 1, 6, 3, 9],
                "worst-individual-distance": 72014.813677115,
                "average-distance": 66264.08395096828,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 8, 11, 5, 2, 1, 6, 10, 12, 18, 21, 9, 13, 17, 27, 20, 25, 26, 16, 24, 3, 15, 19, 22, 28, 29, 23, 14, 7],
                "best-individual-distance": 49481.563275697525,
                "worst-individual-sequence": [3, 4, 14, 15, 20, 21, 29, 25, 18, 2, 7, 12, 17, 22, 27, 26, 28, 23, 9, 8, 19, 24, 16, 13, 11, 10, 5, 6, 1],
                "worst-individual-distance": 71160.81858464205,
                "average-distance": 65378.333161537295,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 8, 11, 5, 2, 1, 6, 10, 12, 18, 21, 9, 13, 17, 27, 20, 25, 26, 16, 24, 3, 15, 19, 22, 28, 29, 23, 14, 7],
                "best-individual-distance": 49481.563275697525,
                "worst-individual-sequence": [22, 15, 25, 16, 14, 29, 19, 3, 2, 4, 18, 28, 21, 23, 24, 17, 26, 27, 20, 12, 8, 13, 7, 1, 6, 9, 5, 10, 11],
                "worst-individual-distance": 70115.67774401691,
                "average-distance": 64608.33132478457,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 8, 11, 5, 2, 1, 6, 10, 12, 18, 21, 9, 13, 17, 27, 20, 25, 26, 16, 24, 3, 15, 19, 22, 28, 29, 23, 14, 7],
                "best-individual-distance": 49481.563275697525,
                "worst-individual-sequence": [17, 21, 10, 5, 29, 25, 28, 13, 9, 4, 3, 7, 6, 8, 1, 2, 12, 15, 11, 24, 20, 16, 23, 18, 26, 27, 14, 22, 19],
                "worst-individual-distance": 69071.12653050639,
                "average-distance": 63768.86489696629,
                "individual-distances": []
            }, {
                "best-individual-sequence": [28, 17, 14, 12, 11, 5, 13, 9, 4, 3, 7, 29, 8, 1, 2, 10, 6, 23, 22, 19, 15, 18, 21, 26, 25, 24, 27, 20, 16],
                "best-individual-distance": 46748.53253604838,
                "worst-individual-sequence": [27, 28, 23, 18, 15, 12, 1, 2, 13, 21, 3, 10, 29, 26, 17, 20, 22, 14, 8, 4, 7, 6, 9, 5, 11, 19, 25, 16, 24],
                "worst-individual-distance": 68323.00358650634,
                "average-distance": 63052.665600051296,
                "individual-distances": []
            }, {
                "best-individual-sequence": [28, 17, 14, 12, 11, 5, 13, 9, 4, 3, 7, 29, 8, 1, 2, 10, 6, 23, 22, 19, 15, 18, 21, 26, 25, 24, 27, 20, 16],
                "best-individual-distance": 46748.53253604838,
                "worst-individual-sequence": [17, 21, 15, 25, 28, 24, 10, 11, 5, 13, 9, 4, 3, 7, 6, 8, 1, 2, 29, 20, 16, 23, 18, 26, 27, 14, 22, 19, 12],
                "worst-individual-distance": 67248.03066060935,
                "average-distance": 62344.03374505527,
                "individual-distances": []
            }, {
                "best-individual-sequence": [28, 17, 14, 12, 11, 5, 13, 9, 4, 3, 7, 29, 8, 1, 2, 10, 6, 23, 22, 19, 15, 18, 21, 26, 25, 24, 27, 20, 16],
                "best-individual-distance": 46748.53253604838,
                "worst-individual-sequence": [24, 16, 27, 21, 28, 17, 19, 18, 5, 13, 9, 4, 3, 7, 6, 8, 1, 2, 15, 10, 12, 14, 23, 25, 26, 11, 22, 20, 29],
                "worst-individual-distance": 66315.93563681838,
                "average-distance": 61664.85424664406,
                "individual-distances": []
            }, {
                "best-individual-sequence": [28, 17, 14, 12, 11, 5, 13, 9, 4, 3, 7, 29, 8, 1, 2, 10, 6, 23, 22, 19, 15, 18, 21, 26, 25, 24, 27, 20, 16],
                "best-individual-distance": 46748.53253604838,
                "worst-individual-sequence": [15, 24, 25, 9, 4, 3, 6, 1, 2, 11, 7, 8, 13, 17, 20, 19, 29, 16, 23, 18, 26, 27, 22, 28, 21, 14, 10, 5, 12],
                "worst-individual-distance": 65535.99956808816,
                "average-distance": 61025.4276490076,
                "individual-distances": []
            }, {
                "best-individual-sequence": [28, 17, 14, 12, 11, 5, 13, 9, 4, 3, 7, 29, 8, 1, 2, 10, 6, 23, 22, 19, 15, 18, 21, 26, 25, 24, 27, 20, 16],
                "best-individual-distance": 46748.53253604838,
                "worst-individual-sequence": [11, 5, 13, 9, 4, 3, 7, 6, 8, 1, 2, 10, 24, 28, 27, 14, 23, 18, 12, 20, 16, 25, 21, 26, 15, 29, 22, 17, 19],
                "worst-individual-distance": 64695.347903893475,
                "average-distance": 60513.34181505514,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 7, 13, 22, 23, 18, 25, 24, 27, 16, 17, 20, 26, 14, 29, 19, 21, 28, 15, 12, 8, 6, 1, 2, 10, 11, 5, 9],
                "best-individual-distance": 44631.63797076857,
                "worst-individual-sequence": [20, 27, 21, 28, 23, 17, 18, 29, 5, 13, 9, 4, 3, 7, 6, 8, 1, 2, 11, 10, 24, 25, 14, 22, 19, 12, 26, 15, 16],
                "worst-individual-distance": 64125.0212368458,
                "average-distance": 59950.99902390695,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 7, 13, 22, 23, 18, 25, 24, 27, 16, 17, 20, 26, 14, 29, 19, 21, 28, 15, 12, 8, 6, 1, 2, 10, 11, 5, 9],
                "best-individual-distance": 44631.63797076857,
                "worst-individual-sequence": [11, 5, 24, 29, 23, 18, 20, 25, 26, 13, 9, 4, 3, 7, 6, 8, 1, 2, 12, 15, 16, 14, 21, 19, 22, 17, 28, 27, 10],
                "worst-individual-distance": 63442.851891954735,
                "average-distance": 59420.510960883264,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 7, 13, 22, 23, 18, 25, 24, 27, 16, 17, 20, 26, 14, 29, 19, 21, 28, 15, 12, 8, 6, 1, 2, 10, 11, 5, 9],
                "best-individual-distance": 44631.63797076857,
                "worst-individual-sequence": [14, 15, 22, 25, 24, 17, 19, 10, 13, 9, 5, 4, 3, 7, 6, 8, 1, 2, 11, 29, 20, 16, 23, 18, 26, 28, 21, 12, 27],
                "worst-individual-distance": 62867.803039513085,
                "average-distance": 58917.17361781751,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 7, 13, 22, 23, 18, 25, 24, 27, 16, 17, 20, 26, 14, 29, 19, 21, 28, 15, 12, 8, 6, 1, 2, 10, 11, 5, 9],
                "best-individual-distance": 44631.63797076857,
                "worst-individual-sequence": [23, 21, 15, 16, 24, 25, 28, 13, 9, 10, 5, 4, 3, 7, 6, 8, 1, 2, 22, 11, 12, 19, 29, 14, 18, 27, 17, 26, 20],
                "worst-individual-distance": 62299.10277241908,
                "average-distance": 58435.34769784914,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 7, 13, 22, 23, 18, 25, 24, 27, 16, 17, 20, 26, 14, 29, 19, 21, 28, 15, 12, 8, 6, 1, 2, 10, 11, 5, 9],
                "best-individual-distance": 44631.63797076857,
                "worst-individual-sequence": [22, 17, 19, 10, 24, 5, 9, 4, 3, 7, 6, 1, 2, 14, 11, 27, 28, 25, 26, 13, 12, 8, 15, 21, 29, 20, 18, 16, 23],
                "worst-individual-distance": 61779.563760517325,
                "average-distance": 57972.44251531577,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 7, 13, 22, 23, 18, 25, 24, 27, 16, 17, 20, 26, 14, 29, 19, 21, 28, 15, 12, 8, 6, 1, 2, 10, 11, 5, 9],
                "best-individual-distance": 44631.63797076857,
                "worst-individual-sequence": [28, 17, 19, 10, 5, 13, 9, 4, 3, 7, 6, 8, 1, 2, 11, 18, 12, 14, 23, 15, 16, 25, 21, 26, 22, 20, 29, 24, 27],
                "worst-individual-distance": 61247.84160452186,
                "average-distance": 57521.0285304488,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 7, 13, 22, 23, 18, 25, 24, 27, 16, 17, 20, 26, 14, 29, 19, 21, 28, 15, 12, 8, 6, 1, 2, 10, 11, 5, 9],
                "best-individual-distance": 44631.63797076857,
                "worst-individual-sequence": [27, 29, 26, 9, 3, 7, 6, 1, 2, 11, 10, 28, 23, 22, 17, 14, 12, 8, 4, 19, 21, 15, 18, 25, 20, 16, 5, 13, 24],
                "worst-individual-distance": 60612.202474055106,
                "average-distance": 57104.875533151884,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 7, 13, 22, 23, 18, 25, 24, 27, 16, 17, 20, 26, 14, 29, 19, 21, 28, 15, 12, 8, 6, 1, 2, 10, 11, 5, 9],
                "best-individual-distance": 44631.63797076857,
                "worst-individual-sequence": [22, 17, 19, 10, 11, 5, 13, 15, 25, 27, 9, 4, 3, 7, 6, 8, 1, 2, 12, 14, 21, 18, 24, 26, 28, 16, 29, 23, 20],
                "worst-individual-distance": 60175.52677097127,
                "average-distance": 56619.13421064083,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 7, 13, 22, 23, 18, 25, 24, 27, 16, 17, 20, 26, 14, 29, 19, 21, 28, 15, 12, 8, 6, 1, 2, 10, 11, 5, 9],
                "best-individual-distance": 44631.63797076857,
                "worst-individual-sequence": [13, 9, 4, 3, 7, 6, 8, 1, 2, 10, 11, 16, 17, 20, 24, 27, 21, 25, 28, 23, 18, 14, 12, 15, 29, 22, 19, 26, 5],
                "worst-individual-distance": 59773.101338458124,
                "average-distance": 56183.021670186856,
                "individual-distances": []
            }, {
                "best-individual-sequence": [29, 26, 13, 9, 4, 3, 7, 6, 1, 2, 5, 8, 12, 15, 18, 25, 27, 24, 16, 20, 17, 14, 10, 19, 21, 28, 11, 23, 22],
                "best-individual-distance": 44403.91231643247,
                "worst-individual-sequence": [7, 13, 6, 8, 1, 2, 28, 23, 18, 15, 22, 25, 24, 27, 16, 17, 20, 26, 21, 19, 10, 12, 29, 14, 11, 5, 9, 4, 3],
                "worst-individual-distance": 59236.10906107521,
                "average-distance": 55728.815375045146,
                "individual-distances": []
            }, {
                "best-individual-sequence": [29, 26, 13, 9, 4, 3, 7, 6, 1, 2, 5, 8, 12, 15, 18, 25, 27, 24, 16, 20, 17, 14, 10, 19, 21, 28, 11, 23, 22],
                "best-individual-distance": 44403.91231643247,
                "worst-individual-sequence": [3, 9, 10, 18, 15, 14, 23, 21, 25, 26, 28, 7, 8, 13, 17, 22, 20, 19, 29, 27, 24, 16, 12, 4, 1, 2, 11, 6, 5],
                "worst-individual-distance": 58827.81420603919,
                "average-distance": 55405.73970953459,
                "individual-distances": []
            }, {
                "best-individual-sequence": [29, 26, 13, 9, 4, 3, 7, 6, 1, 2, 5, 8, 12, 15, 18, 25, 27, 24, 16, 20, 17, 14, 10, 19, 21, 28, 11, 23, 22],
                "best-individual-distance": 44403.91231643247,
                "worst-individual-sequence": [29, 19, 10, 11, 5, 13, 9, 4, 3, 7, 6, 8, 22, 16, 15, 1, 2, 12, 14, 21, 18, 27, 24, 25, 20, 17, 26, 28, 23],
                "worst-individual-distance": 58338.364371064315,
                "average-distance": 55005.68386080572,
                "individual-distances": []
            }, {
                "best-individual-sequence": [6, 2, 1, 5, 4, 3, 13, 12, 15, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 9, 11, 7, 14, 8, 10],
                "best-individual-distance": 39461.81263670152,
                "worst-individual-sequence": [28, 10, 11, 5, 13, 9, 4, 3, 7, 6, 8, 1, 2, 12, 15, 19, 27, 21, 29, 20, 16, 23, 18, 14, 22, 24, 25, 17, 26],
                "worst-individual-distance": 57868.48336614662,
                "average-distance": 54643.2001610271,
                "individual-distances": []
            }, {
                "best-individual-sequence": [6, 2, 1, 5, 4, 3, 13, 12, 15, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 9, 11, 7, 14, 8, 10],
                "best-individual-distance": 39461.81263670152,
                "worst-individual-sequence": [27, 16, 24, 25, 28, 14, 22, 11, 5, 13, 9, 4, 3, 7, 6, 8, 1, 2, 10, 12, 19, 29, 20, 15, 23, 17, 18, 21, 26],
                "worst-individual-distance": 57444.3358084609,
                "average-distance": 54297.14821663395,
                "individual-distances": []
            }, {
                "best-individual-sequence": [6, 2, 1, 5, 4, 3, 13, 12, 15, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 9, 11, 7, 14, 8, 10],
                "best-individual-distance": 39461.81263670152,
                "worst-individual-sequence": [5, 13, 9, 4, 3, 7, 12, 15, 18, 6, 8, 1, 2, 11, 10, 29, 17, 27, 20, 25, 26, 16, 24, 21, 22, 23, 28, 19, 14],
                "worst-individual-distance": 57059.16179080836,
                "average-distance": 53947.66994827104,
                "individual-distances": []
            }, {
                "best-individual-sequence": [6, 2, 1, 5, 4, 3, 13, 12, 15, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 9, 11, 7, 14, 8, 10],
                "best-individual-distance": 39461.81263670152,
                "worst-individual-sequence": [16, 28, 20, 22, 17, 19, 10, 11, 5, 13, 9, 4, 3, 7, 6, 8, 1, 2, 12, 15, 14, 25, 21, 18, 29, 27, 26, 23, 24],
                "worst-individual-distance": 56717.410319905925,
                "average-distance": 53571.804999561675,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 18, 11, 14, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 15, 13, 12, 8, 6, 1, 2, 7, 10, 5, 9],
                "best-individual-distance": 38619.27325545729,
                "worst-individual-sequence": [21, 24, 25, 26, 17, 19, 29, 13, 12, 9, 5, 4, 3, 7, 6, 8, 1, 2, 11, 10, 20, 16, 23, 18, 27, 28, 14, 22, 15],
                "worst-individual-distance": 56332.75209113432,
                "average-distance": 53218.020059639406,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 18, 11, 14, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 15, 13, 12, 8, 6, 1, 2, 7, 10, 5, 9],
                "best-individual-distance": 38619.27325545729,
                "worst-individual-sequence": [23, 28, 20, 22, 17, 19, 10, 11, 5, 13, 9, 4, 3, 7, 6, 8, 1, 2, 24, 15, 14, 25, 21, 18, 27, 16, 12, 29, 26],
                "worst-individual-distance": 56008.89883489557,
                "average-distance": 52902.104113908455,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 18, 11, 14, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 15, 13, 12, 8, 6, 1, 2, 7, 10, 5, 9],
                "best-individual-distance": 38619.27325545729,
                "worst-individual-sequence": [23, 22, 19, 1, 6, 8, 10, 11, 5, 13, 9, 4, 3, 7, 2, 12, 15, 16, 25, 21, 18, 24, 27, 20, 17, 26, 28, 29, 14],
                "worst-individual-distance": 55788.1919680952,
                "average-distance": 52598.31301644608,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 18, 11, 14, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 15, 13, 12, 8, 6, 1, 2, 7, 10, 5, 9],
                "best-individual-distance": 38619.27325545729,
                "worst-individual-sequence": [7, 6, 8, 1, 2, 11, 15, 10, 12, 3, 9, 13, 29, 17, 19, 14, 16, 25, 21, 18, 22, 28, 23, 26, 20, 27, 24, 5, 4],
                "worst-individual-distance": 55439.45498207907,
                "average-distance": 52226.46856763804,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 18, 11, 14, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 15, 13, 12, 8, 6, 1, 2, 7, 10, 5, 9],
                "best-individual-distance": 38619.27325545729,
                "worst-individual-sequence": [6, 4, 3, 7, 8, 1, 2, 5, 13, 9, 12, 15, 18, 23, 29, 17, 20, 24, 16, 10, 11, 14, 22, 27, 25, 21, 26, 28, 19],
                "worst-individual-distance": 55111.23659772935,
                "average-distance": 51898.16233133161,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 18, 11, 14, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 15, 13, 12, 8, 6, 1, 2, 7, 10, 5, 9],
                "best-individual-distance": 38619.27325545729,
                "worst-individual-sequence": [25, 23, 28, 17, 19, 18, 6, 13, 11, 8, 9, 4, 3, 7, 5, 1, 2, 10, 12, 14, 15, 29, 22, 26, 16, 20, 24, 27, 21],
                "worst-individual-distance": 54703.09391190334,
                "average-distance": 51526.985479948686,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 18, 11, 14, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 15, 13, 12, 8, 6, 1, 2, 7, 10, 5, 9],
                "best-individual-distance": 38619.27325545729,
                "worst-individual-sequence": [24, 16, 27, 21, 28, 17, 19, 18, 9, 1, 13, 4, 3, 7, 5, 8, 6, 2, 11, 10, 12, 14, 23, 25, 26, 15, 22, 20, 29],
                "worst-individual-distance": 54445.849824765355,
                "average-distance": 51236.08543651668,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 18, 11, 14, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 15, 13, 12, 8, 6, 1, 2, 7, 10, 5, 9],
                "best-individual-distance": 38619.27325545729,
                "worst-individual-sequence": [19, 18, 21, 17, 28, 6, 9, 4, 3, 7, 13, 8, 1, 2, 11, 10, 5, 12, 15, 26, 27, 25, 22, 29, 20, 23, 24, 14, 16],
                "worst-individual-distance": 54080.89476678091,
                "average-distance": 50942.15502442418,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 18, 11, 14, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 15, 13, 12, 8, 6, 1, 2, 7, 10, 5, 9],
                "best-individual-distance": 38619.27325545729,
                "worst-individual-sequence": [22, 29, 26, 20, 17, 16, 8, 9, 14, 15, 18, 23, 12, 7, 10, 11, 6, 2, 1, 5, 4, 3, 13, 24, 19, 28, 27, 25, 21],
                "worst-individual-distance": 53756.24234943501,
                "average-distance": 50564.05241053084,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 18, 11, 14, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 15, 13, 12, 8, 6, 1, 2, 7, 10, 5, 9],
                "best-individual-distance": 38619.27325545729,
                "worst-individual-sequence": [15, 18, 8, 10, 6, 2, 5, 4, 3, 13, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 12, 11, 7, 1, 9, 14],
                "worst-individual-distance": 53390.90581391663,
                "average-distance": 50244.66551510915,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 18, 11, 14, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 15, 13, 12, 8, 6, 1, 2, 7, 10, 5, 9],
                "best-individual-distance": 38619.27325545729,
                "worst-individual-sequence": [27, 24, 14, 26, 13, 9, 4, 3, 7, 6, 1, 2, 5, 8, 15, 11, 10, 28, 16, 25, 21, 23, 22, 19, 12, 29, 17, 18, 20],
                "worst-individual-distance": 53085.26968301499,
                "average-distance": 49929.32423108622,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 18, 11, 14, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 15, 13, 12, 8, 6, 1, 2, 7, 10, 5, 9],
                "best-individual-distance": 38619.27325545729,
                "worst-individual-sequence": [21, 26, 27, 16, 24, 25, 28, 13, 9, 10, 5, 4, 3, 7, 22, 8, 1, 2, 12, 6, 11, 19, 29, 14, 20, 15, 23, 17, 18],
                "worst-individual-distance": 52684.30378396111,
                "average-distance": 49619.40228191962,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 18, 11, 14, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 15, 13, 12, 8, 6, 1, 2, 7, 10, 5, 9],
                "best-individual-distance": 38619.27325545729,
                "worst-individual-sequence": [6, 1, 2, 15, 22, 23, 18, 10, 5, 8, 12, 26, 27, 24, 16, 25, 21, 14, 29, 28, 20, 17, 19, 11, 13, 9, 4, 3, 7],
                "worst-individual-distance": 52363.678593527315,
                "average-distance": 49300.72026796574,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 18, 11, 14, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 15, 13, 12, 8, 6, 1, 2, 7, 10, 5, 9],
                "best-individual-distance": 38619.27325545729,
                "worst-individual-sequence": [3, 7, 6, 1, 2, 15, 22, 25, 24, 27, 16, 5, 8, 10, 21, 18, 20, 26, 28, 23, 19, 29, 17, 14, 12, 11, 13, 9, 4],
                "worst-individual-distance": 51959.73242998061,
                "average-distance": 49024.63947341924,
                "individual-distances": []
            }, {
                "best-individual-sequence": [2, 5, 8, 11, 10, 12, 6, 19, 15, 18, 22, 25, 24, 27, 16, 17, 20, 26, 28, 21, 29, 14, 13, 9, 4, 3, 7, 23, 1],
                "best-individual-distance": 38462.814422400996,
                "worst-individual-sequence": [12, 4, 3, 7, 14, 18, 23, 21, 25, 26, 28, 9, 8, 13, 17, 22, 20, 19, 29, 27, 24, 16, 15, 10, 11, 5, 6, 1, 2],
                "worst-individual-distance": 51697.76530137247,
                "average-distance": 48721.92164691905,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 9, 10, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 15, 13, 12, 8, 7, 14, 11, 6, 2, 1, 5],
                "best-individual-distance": 36143.635326144955,
                "worst-individual-sequence": [29, 17, 14, 12, 11, 5, 13, 9, 4, 3, 7, 16, 8, 1, 2, 10, 24, 25, 21, 18, 6, 27, 20, 26, 28, 22, 23, 15, 19],
                "worst-individual-distance": 51387.91416465972,
                "average-distance": 48369.81607481576,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 9, 10, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 15, 13, 12, 8, 7, 14, 11, 6, 2, 1, 5],
                "best-individual-distance": 36143.635326144955,
                "worst-individual-sequence": [6, 8, 1, 2, 10, 11, 12, 5, 22, 19, 21, 17, 15, 18, 25, 24, 27, 16, 29, 20, 28, 26, 14, 23, 13, 9, 4, 3, 7],
                "worst-individual-distance": 51074.94952275525,
                "average-distance": 48005.287102196686,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 9, 10, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 15, 13, 12, 8, 7, 14, 11, 6, 2, 1, 5],
                "best-individual-distance": 36143.635326144955,
                "worst-individual-sequence": [2, 5, 9, 4, 3, 7, 8, 13, 12, 15, 11, 10, 19, 18, 16, 21, 26, 17, 22, 29, 20, 28, 23, 14, 25, 27, 24, 6, 1],
                "worst-individual-distance": 50713.686287583434,
                "average-distance": 47664.94750455777,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 9, 10, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 15, 13, 12, 8, 7, 14, 11, 6, 2, 1, 5],
                "best-individual-distance": 36143.635326144955,
                "worst-individual-sequence": [4, 3, 7, 13, 18, 15, 22, 25, 24, 27, 16, 17, 20, 26, 14, 29, 19, 21, 28, 12, 10, 8, 6, 1, 2, 23, 11, 5, 9],
                "worst-individual-distance": 50355.602384105485,
                "average-distance": 47331.68127478786,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 9, 10, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 15, 13, 12, 8, 7, 14, 11, 6, 2, 1, 5],
                "best-individual-distance": 36143.635326144955,
                "worst-individual-sequence": [4, 3, 7, 13, 18, 15, 22, 25, 24, 27, 16, 17, 20, 26, 14, 29, 19, 21, 28, 12, 10, 8, 6, 1, 2, 23, 11, 5, 9],
                "worst-individual-distance": 50030.07154082687,
                "average-distance": 46994.53447680041,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 9, 10, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 15, 13, 12, 8, 7, 14, 11, 6, 2, 1, 5],
                "best-individual-distance": 36143.635326144955,
                "worst-individual-sequence": [7, 24, 18, 27, 16, 20, 22, 19, 15, 28, 23, 25, 17, 26, 14, 29, 21, 13, 12, 8, 6, 1, 2, 10, 11, 5, 9, 4, 3],
                "worst-individual-distance": 49789.10127882414,
                "average-distance": 46732.207031353166,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 9, 10, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 15, 13, 12, 8, 7, 14, 11, 6, 2, 1, 5],
                "best-individual-distance": 36143.635326144955,
                "worst-individual-sequence": [2, 10, 5, 9, 4, 3, 13, 14, 15, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 12, 11, 7, 1, 8, 6],
                "worst-individual-distance": 49449.750255505896,
                "average-distance": 46429.36760551459,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 9, 10, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 15, 13, 12, 8, 7, 14, 11, 6, 2, 1, 5],
                "best-individual-distance": 36143.635326144955,
                "worst-individual-sequence": [6, 8, 1, 2, 10, 11, 12, 23, 22, 19, 21, 17, 15, 18, 25, 24, 27, 16, 29, 20, 28, 26, 14, 5, 13, 9, 4, 3, 7],
                "worst-individual-distance": 49118.92490389203,
                "average-distance": 46077.5449640109,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 9, 10, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 15, 13, 12, 8, 7, 14, 11, 6, 2, 1, 5],
                "best-individual-distance": 36143.635326144955,
                "worst-individual-sequence": [5, 8, 9, 4, 3, 7, 1, 15, 2, 12, 14, 21, 18, 25, 27, 24, 16, 20, 17, 13, 26, 28, 29, 23, 22, 19, 10, 11, 6],
                "worst-individual-distance": 48811.810591808884,
                "average-distance": 45802.62227119728,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 9, 10, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 15, 13, 12, 8, 7, 14, 11, 6, 2, 1, 5],
                "best-individual-distance": 36143.635326144955,
                "worst-individual-sequence": [12, 8, 1, 2, 6, 10, 18, 15, 22, 25, 24, 27, 16, 17, 29, 20, 26, 28, 21, 14, 19, 23, 11, 5, 13, 9, 4, 3, 7],
                "worst-individual-distance": 48479.93316718189,
                "average-distance": 45521.27058538109,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 9, 10, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 15, 13, 12, 8, 7, 14, 11, 6, 2, 1, 5],
                "best-individual-distance": 36143.635326144955,
                "worst-individual-sequence": [1, 2, 6, 10, 25, 24, 27, 16, 26, 23, 29, 20, 19, 12, 11, 5, 13, 14, 17, 28, 21, 22, 15, 18, 9, 4, 3, 7, 8],
                "worst-individual-distance": 48227.50420068605,
                "average-distance": 45276.397140133784,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 9, 10, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 15, 13, 12, 8, 7, 14, 11, 6, 2, 1, 5],
                "best-individual-distance": 36143.635326144955,
                "worst-individual-sequence": [16, 18, 29, 26, 17, 28, 21, 14, 13, 9, 6, 4, 3, 7, 5, 8, 1, 2, 12, 10, 11, 15, 20, 19, 23, 22, 25, 24, 27],
                "worst-individual-distance": 47964.650942342756,
                "average-distance": 44996.30475995489,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 9, 10, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 15, 13, 12, 8, 7, 14, 11, 6, 2, 1, 5],
                "best-individual-distance": 36143.635326144955,
                "worst-individual-sequence": [19, 16, 27, 24, 25, 28, 6, 9, 10, 5, 4, 3, 7, 13, 8, 1, 2, 11, 12, 14, 17, 21, 29, 18, 15, 26, 20, 23, 22],
                "worst-individual-distance": 47666.39492631532,
                "average-distance": 44738.72690218749,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 9, 10, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 15, 13, 12, 8, 7, 14, 11, 6, 2, 1, 5],
                "best-individual-distance": 36143.635326144955,
                "worst-individual-sequence": [29, 20, 24, 27, 12, 7, 8, 10, 11, 6, 2, 1, 5, 4, 3, 13, 9, 15, 25, 16, 28, 26, 14, 23, 22, 19, 21, 17, 18],
                "worst-individual-distance": 47439.88679412876,
                "average-distance": 44501.86669152961,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 9, 10, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 15, 13, 12, 8, 7, 14, 11, 6, 2, 1, 5],
                "best-individual-distance": 36143.635326144955,
                "worst-individual-sequence": [11, 9, 4, 3, 7, 12, 8, 6, 1, 2, 10, 15, 18, 23, 29, 17, 20, 24, 16, 21, 26, 27, 25, 28, 22, 19, 14, 13, 5],
                "worst-individual-distance": 47065.4688234971,
                "average-distance": 44223.61057494799,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 9, 10, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 15, 13, 12, 8, 7, 14, 11, 6, 2, 1, 5],
                "best-individual-distance": 36143.635326144955,
                "worst-individual-sequence": [6, 1, 2, 8, 12, 10, 11, 23, 22, 19, 21, 17, 15, 18, 25, 24, 27, 16, 29, 20, 28, 26, 14, 5, 13, 9, 4, 3, 7],
                "worst-individual-distance": 46789.926183803946,
                "average-distance": 43976.833234787715,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 3, 9, 10, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 15, 13, 12, 8, 7, 14, 11, 6, 2, 1, 5],
                "best-individual-distance": 36143.635326144955,
                "worst-individual-sequence": [1, 5, 4, 3, 8, 11, 2, 6, 10, 12, 14, 15, 23, 22, 19, 21, 18, 25, 27, 20, 24, 16, 26, 29, 28, 17, 13, 7, 9],
                "worst-individual-distance": 46457.180140257835,
                "average-distance": 43713.149078655355,
                "individual-distances": []
            }, {
                "best-individual-sequence": [2, 1, 5, 4, 3, 7, 9, 13, 15, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 14, 12, 10, 11, 8, 6],
                "best-individual-distance": 35190.85371811845,
                "worst-individual-sequence": [7, 19, 23, 21, 14, 17, 15, 18, 25, 24, 27, 16, 29, 20, 28, 26, 22, 13, 12, 6, 1, 2, 10, 11, 5, 9, 4, 8, 3],
                "worst-individual-distance": 46205.97988389606,
                "average-distance": 43473.43861782689,
                "individual-distances": []
            }, {
                "best-individual-sequence": [2, 1, 5, 4, 3, 7, 9, 13, 15, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 14, 12, 10, 11, 8, 6],
                "best-individual-distance": 35190.85371811845,
                "worst-individual-sequence": [3, 7, 14, 13, 12, 6, 5, 8, 1, 2, 4, 11, 10, 17, 28, 21, 22, 15, 18, 23, 29, 26, 20, 16, 25, 27, 24, 19, 9],
                "worst-individual-distance": 45931.791608101186,
                "average-distance": 43257.20587999238,
                "individual-distances": []
            }, {
                "best-individual-sequence": [6, 2, 1, 5, 4, 3, 9, 15, 14, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 13, 12, 7, 8, 10, 11],
                "best-individual-distance": 34828.65109877723,
                "worst-individual-sequence": [22, 29, 26, 13, 9, 4, 3, 7, 6, 1, 2, 5, 8, 11, 12, 16, 15, 10, 23, 24, 25, 27, 14, 17, 18, 19, 20, 28, 21],
                "worst-individual-distance": 45720.71949370188,
                "average-distance": 43045.449311260076,
                "individual-distances": []
            }, {
                "best-individual-sequence": [6, 2, 1, 5, 4, 3, 9, 15, 14, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 13, 12, 7, 8, 10, 11],
                "best-individual-distance": 34828.65109877723,
                "worst-individual-sequence": [1, 2, 5, 8, 12, 11, 10, 28, 18, 15, 22, 25, 24, 27, 16, 17, 20, 26, 21, 19, 23, 14, 29, 13, 9, 4, 3, 7, 6],
                "worst-individual-distance": 45449.52676411331,
                "average-distance": 42838.74861137708,
                "individual-distances": []
            }, {
                "best-individual-sequence": [6, 2, 1, 5, 4, 3, 9, 15, 14, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 13, 12, 7, 8, 10, 11],
                "best-individual-distance": 34828.65109877723,
                "worst-individual-sequence": [7, 10, 19, 28, 23, 15, 22, 25, 24, 27, 16, 17, 20, 26, 14, 29, 21, 13, 12, 8, 6, 1, 2, 18, 11, 5, 9, 4, 3],
                "worst-individual-distance": 45228.61189452932,
                "average-distance": 42658.10911247844,
                "individual-distances": []
            }, {
                "best-individual-sequence": [6, 2, 1, 5, 4, 3, 9, 15, 14, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 13, 12, 7, 8, 10, 11],
                "best-individual-distance": 34828.65109877723,
                "worst-individual-sequence": [6, 11, 10, 12, 18, 15, 22, 25, 24, 27, 16, 17, 20, 26, 14, 29, 19, 21, 28, 23, 13, 9, 4, 3, 7, 5, 8, 1, 2],
                "worst-individual-distance": 44996.73273290212,
                "average-distance": 42458.10908494975,
                "individual-distances": []
            }, {
                "best-individual-sequence": [6, 2, 1, 5, 4, 3, 9, 15, 14, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 13, 12, 7, 8, 10, 11],
                "best-individual-distance": 34828.65109877723,
                "worst-individual-sequence": [11, 6, 2, 1, 5, 10, 29, 23, 19, 21, 22, 17, 20, 26, 14, 25, 28, 16, 27, 24, 18, 15, 13, 9, 4, 3, 7, 8, 12],
                "worst-individual-distance": 44821.699329964795,
                "average-distance": 42273.060872421986,
                "individual-distances": []
            }, {
                "best-individual-sequence": [6, 2, 1, 5, 4, 3, 9, 15, 14, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 13, 12, 7, 8, 10, 11],
                "best-individual-distance": 34828.65109877723,
                "worst-individual-sequence": [5, 10, 9, 4, 3, 7, 12, 14, 15, 29, 22, 25, 24, 27, 16, 17, 20, 26, 28, 21, 23, 19, 18, 8, 6, 2, 13, 1, 11],
                "worst-individual-distance": 44575.9084720964,
                "average-distance": 42054.42038482833,
                "individual-distances": []
            }, {
                "best-individual-sequence": [6, 2, 1, 5, 4, 3, 9, 15, 14, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 13, 12, 7, 8, 10, 11],
                "best-individual-distance": 34828.65109877723,
                "worst-individual-sequence": [4, 3, 7, 13, 18, 15, 22, 25, 24, 27, 16, 17, 20, 26, 14, 29, 19, 21, 28, 12, 10, 8, 6, 1, 2, 23, 11, 5, 9],
                "worst-individual-distance": 44416.13986074757,
                "average-distance": 41880.93730658493,
                "individual-distances": []
            }, {
                "best-individual-sequence": [6, 2, 1, 5, 4, 3, 9, 15, 14, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 13, 12, 7, 8, 10, 11],
                "best-individual-distance": 34828.65109877723,
                "worst-individual-sequence": [2, 1, 5, 4, 3, 7, 12, 14, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 9, 13, 11, 15, 8, 10, 6],
                "worst-individual-distance": 44201.42489597336,
                "average-distance": 41685.02191454675,
                "individual-distances": []
            }, {
                "best-individual-sequence": [6, 2, 1, 5, 4, 3, 9, 15, 14, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 13, 12, 7, 8, 10, 11],
                "best-individual-distance": 34828.65109877723,
                "worst-individual-sequence": [4, 3, 7, 13, 22, 23, 18, 25, 24, 27, 16, 17, 20, 26, 14, 29, 19, 21, 28, 15, 12, 8, 6, 1, 2, 10, 11, 5, 9],
                "worst-individual-distance": 43953.22106774854,
                "average-distance": 41484.58477263256,
                "individual-distances": []
            }, {
                "best-individual-sequence": [6, 2, 1, 5, 4, 3, 9, 15, 14, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 13, 12, 7, 8, 10, 11],
                "best-individual-distance": 34828.65109877723,
                "worst-individual-sequence": [1, 5, 4, 3, 7, 12, 9, 14, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 11, 13, 15, 8, 10, 6, 2],
                "worst-individual-distance": 43790.07300320776,
                "average-distance": 41313.36103239434,
                "individual-distances": []
            }, {
                "best-individual-sequence": [6, 2, 1, 5, 4, 3, 9, 15, 14, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 13, 12, 7, 8, 10, 11],
                "best-individual-distance": 34828.65109877723,
                "worst-individual-sequence": [8, 10, 11, 6, 2, 1, 5, 4, 3, 13, 14, 15, 18, 23, 29, 17, 20, 24, 16, 9, 26, 27, 25, 28, 19, 22, 21, 12, 7],
                "worst-individual-distance": 43541.30362082048,
                "average-distance": 41123.3251072182,
                "individual-distances": []
            }, {
                "best-individual-sequence": [6, 2, 1, 5, 4, 3, 9, 15, 14, 18, 23, 29, 17, 21, 26, 20, 24, 16, 27, 25, 28, 22, 19, 13, 12, 7, 8, 10, 11],
                "best-individual-distance": 34828.65109877723,
                "worst-individual-sequence": [3, 13, 12, 15, 18, 23, 21, 26, 20, 29, 22, 25, 24, 27, 16, 17, 28, 19, 14, 11, 7, 9, 8, 10, 6, 2, 1, 5, 4],
                "worst-individual-distance": 43294.13212460131,
                "average-distance": 40923.14098368112,
                "individual-distances": []
            }
        ],
        [
            [{
                "time_cost": 0
            }], {
                "best-individual-sequence": [8, 10, 4, 18, 28, 25, 20, 29, 6, 7, 1, 2, 5, 15, 23, 22, 26, 19, 17, 3, 12, 11, 24, 16, 21, 14, 27, 9, 13],
                "best-individual-distance": 77550.10118826585,
                "worst-individual-sequence": [20, 18, 16, 2, 28, 9, 5, 29, 24, 14, 26, 27, 4, 22, 25, 7, 12, 10, 13, 23, 3, 15, 1, 19, 21, 6, 11, 17, 8],
                "worst-individual-distance": 120671.89151388241,
                "average-distance": 106794.84187877164,
                "individual-distances": []
            }, {
                "best-individual-sequence": [29, 14, 8, 13, 7, 2, 6, 12, 10, 18, 23, 25, 15, 26, 11, 9, 4, 5, 1, 3, 27, 28, 20, 21, 19, 24, 16, 17, 22],
                "best-individual-distance": 72086.93154956098,
                "worst-individual-sequence": [22, 15, 20, 10, 29, 11, 9, 7, 8, 26, 2, 5, 14, 13, 19, 25, 1, 24, 6, 18, 3, 28, 23, 21, 27, 17, 16, 4, 12],
                "worst-individual-distance": 116415.54595946571,
                "average-distance": 103922.49101793853,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 27, 15, 16, 13, 29, 11, 10, 1, 2, 6, 8, 14, 19, 17, 22, 20, 25, 7, 3, 9, 26, 24, 12, 5, 4, 28, 21, 18],
                "best-individual-distance": 71335.45584350328,
                "worst-individual-sequence": [16, 10, 9, 19, 12, 28, 18, 17, 6, 1, 21, 7, 25, 3, 14, 2, 24, 4, 11, 13, 20, 29, 27, 15, 8, 5, 26, 22, 23],
                "worst-individual-distance": 112862.64634962741,
                "average-distance": 101309.85621723904,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 27, 15, 16, 13, 29, 11, 10, 1, 2, 6, 8, 14, 19, 17, 22, 20, 25, 7, 3, 9, 26, 24, 12, 5, 4, 28, 21, 18],
                "best-individual-distance": 71335.45584350328,
                "worst-individual-sequence": [22, 3, 8, 9, 28, 2, 11, 16, 24, 4, 19, 27, 26, 13, 12, 20, 7, 23, 21, 14, 18, 15, 10, 29, 25, 1, 6, 17, 5],
                "worst-individual-distance": 109883.08385388769,
                "average-distance": 99091.14578474678,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 27, 15, 16, 13, 29, 11, 10, 1, 2, 6, 8, 14, 19, 17, 22, 20, 25, 7, 3, 9, 26, 24, 12, 5, 4, 28, 21, 18],
                "best-individual-distance": 71335.45584350328,
                "worst-individual-sequence": [21, 10, 11, 12, 7, 29, 4, 14, 13, 19, 6, 18, 27, 25, 22, 16, 26, 2, 28, 1, 9, 5, 8, 17, 20, 24, 15, 23, 3],
                "worst-individual-distance": 107267.1998117138,
                "average-distance": 96923.32239613147,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 27, 15, 16, 13, 29, 11, 10, 1, 2, 6, 8, 14, 19, 17, 22, 20, 25, 7, 3, 9, 26, 24, 12, 5, 4, 28, 21, 18],
                "best-individual-distance": 71335.45584350328,
                "worst-individual-sequence": [20, 9, 12, 7, 15, 4, 16, 13, 22, 27, 23, 17, 28, 2, 26, 29, 25, 6, 3, 1, 8, 10, 5, 24, 19, 21, 11, 18, 14],
                "worst-individual-distance": 104796.5450751335,
                "average-distance": 94921.55557965548,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 13, 20, 21, 17, 24, 25, 29, 19, 6, 8, 12, 1, 22, 28, 18, 23, 27, 26, 15, 7, 14, 10, 3, 9, 16, 2, 11, 5],
                "best-individual-distance": 69909.6496154977,
                "worst-individual-sequence": [11, 7, 23, 13, 17, 14, 21, 5, 25, 4, 6, 22, 26, 27, 8, 29, 28, 15, 20, 18, 19, 16, 24, 2, 3, 10, 9, 1, 12],
                "worst-individual-distance": 102549.85141084548,
                "average-distance": 93258.09618714372,
                "individual-distances": []
            }, {
                "best-individual-sequence": [25, 24, 13, 20, 29, 28, 23, 3, 17, 27, 21, 26, 19, 18, 6, 1, 2, 11, 5, 8, 15, 22, 7, 9, 12, 10, 16, 4, 14],
                "best-individual-distance": 64381.38140963536,
                "worst-individual-sequence": [26, 3, 15, 6, 29, 27, 18, 10, 7, 2, 21, 24, 16, 12, 13, 5, 1, 4, 25, 17, 22, 11, 19, 23, 9, 8, 28, 14, 20],
                "worst-individual-distance": 100454.20733657795,
                "average-distance": 91507.39619221851,
                "individual-distances": []
            }, {
                "best-individual-sequence": [13, 23, 16, 21, 26, 19, 18, 15, 12, 1, 2, 6, 4, 11, 5, 3, 8, 7, 29, 27, 20, 22, 17, 9, 14, 25, 24, 28, 10],
                "best-individual-distance": 64332.32733789416,
                "worst-individual-sequence": [29, 8, 5, 6, 20, 24, 17, 18, 25, 27, 22, 21, 2, 13, 9, 11, 12, 16, 26, 7, 15, 14, 19, 28, 4, 1, 23, 10, 3],
                "worst-individual-distance": 98286.58918327201,
                "average-distance": 89957.54813648072,
                "individual-distances": []
            }, {
                "best-individual-sequence": [13, 23, 16, 21, 26, 19, 18, 15, 12, 1, 2, 6, 4, 11, 5, 3, 8, 7, 29, 27, 20, 22, 17, 9, 14, 25, 24, 28, 10],
                "best-individual-distance": 64332.32733789416,
                "worst-individual-sequence": [2, 7, 29, 15, 23, 26, 19, 3, 17, 16, 20, 13, 5, 11, 1, 6, 12, 25, 4, 8, 22, 24, 14, 21, 27, 9, 10, 18, 28],
                "worst-individual-distance": 96697.80786080495,
                "average-distance": 88547.14965961452,
                "individual-distances": []
            }, {
                "best-individual-sequence": [13, 23, 16, 21, 26, 19, 18, 15, 12, 1, 2, 6, 4, 11, 5, 3, 8, 7, 29, 27, 20, 22, 17, 9, 14, 25, 24, 28, 10],
                "best-individual-distance": 64332.32733789416,
                "worst-individual-sequence": [28, 9, 7, 5, 11, 3, 2, 12, 26, 17, 21, 19, 25, 13, 29, 16, 15, 18, 23, 14, 20, 10, 4, 24, 6, 8, 1, 27, 22],
                "worst-individual-distance": 94959.18609472735,
                "average-distance": 87166.44988434913,
                "individual-distances": []
            }, {
                "best-individual-sequence": [19, 1, 10, 3, 6, 2, 16, 28, 24, 20, 15, 22, 27, 25, 26, 17, 21, 29, 23, 14, 7, 4, 5, 8, 13, 12, 11, 18, 9],
                "best-individual-distance": 62973.593003716785,
                "worst-individual-sequence": [7, 4, 6, 5, 11, 27, 22, 14, 16, 29, 19, 21, 25, 10, 12, 2, 1, 20, 3, 23, 18, 26, 8, 15, 9, 17, 13, 28, 24],
                "worst-individual-distance": 93194.1544454355,
                "average-distance": 85840.18144117086,
                "individual-distances": []
            }, {
                "best-individual-sequence": [19, 1, 10, 3, 6, 2, 16, 28, 24, 20, 15, 22, 27, 25, 26, 17, 21, 29, 23, 14, 7, 4, 5, 8, 13, 12, 11, 18, 9],
                "best-individual-distance": 62973.593003716785,
                "worst-individual-sequence": [28, 25, 15, 20, 26, 13, 11, 16, 23, 29, 21, 1, 8, 6, 12, 2, 14, 5, 17, 9, 4, 3, 18, 10, 7, 24, 27, 22, 19],
                "worst-individual-distance": 91681.18360904304,
                "average-distance": 84490.30023119612,
                "individual-distances": []
            }, {
                "best-individual-sequence": [19, 1, 10, 3, 6, 2, 16, 28, 24, 20, 15, 22, 27, 25, 26, 17, 21, 29, 23, 14, 7, 4, 5, 8, 13, 12, 11, 18, 9],
                "best-individual-distance": 62973.593003716785,
                "worst-individual-sequence": [22, 19, 16, 27, 24, 14, 26, 2, 9, 8, 5, 18, 29, 6, 17, 21, 11, 13, 25, 20, 28, 15, 1, 7, 4, 3, 10, 23, 12],
                "worst-individual-distance": 90192.18295475582,
                "average-distance": 83395.09262667036,
                "individual-distances": []
            }, {
                "best-individual-sequence": [19, 1, 10, 3, 6, 2, 16, 28, 24, 20, 15, 22, 27, 25, 26, 17, 21, 29, 23, 14, 7, 4, 5, 8, 13, 12, 11, 18, 9],
                "best-individual-distance": 62973.593003716785,
                "worst-individual-sequence": [2, 12, 19, 17, 14, 13, 20, 18, 28, 29, 23, 25, 15, 26, 11, 9, 4, 5, 1, 24, 7, 3, 6, 8, 21, 22, 10, 16, 27],
                "worst-individual-distance": 88984.2377450101,
                "average-distance": 82345.42608860777,
                "individual-distances": []
            }, {
                "best-individual-sequence": [19, 1, 10, 3, 6, 2, 16, 28, 24, 20, 15, 22, 27, 25, 26, 17, 21, 29, 23, 14, 7, 4, 5, 8, 13, 12, 11, 18, 9],
                "best-individual-distance": 62973.593003716785,
                "worst-individual-sequence": [25, 19, 13, 9, 22, 28, 29, 20, 16, 3, 26, 11, 15, 7, 2, 1, 8, 17, 27, 21, 23, 18, 24, 5, 10, 4, 12, 6, 14],
                "worst-individual-distance": 87803.669049855,
                "average-distance": 81418.3442578806,
                "individual-distances": []
            }, {
                "best-individual-sequence": [19, 1, 10, 3, 6, 2, 16, 28, 24, 20, 15, 22, 27, 25, 26, 17, 21, 29, 23, 14, 7, 4, 5, 8, 13, 12, 11, 18, 9],
                "best-individual-distance": 62973.593003716785,
                "worst-individual-sequence": [25, 21, 5, 7, 4, 27, 26, 14, 3, 9, 6, 11, 17, 13, 10, 29, 22, 28, 23, 15, 19, 2, 1, 24, 8, 12, 16, 18, 20],
                "worst-individual-distance": 86417.53757430242,
                "average-distance": 80409.6832597788,
                "individual-distances": []
            }, {
                "best-individual-sequence": [18, 12, 2, 1, 14, 6, 9, 4, 3, 20, 28, 22, 16, 24, 11, 15, 21, 27, 25, 26, 17, 23, 19, 29, 13, 5, 8, 10, 7],
                "best-individual-distance": 61547.438287640514,
                "worst-individual-sequence": [5, 10, 23, 18, 28, 9, 15, 14, 13, 19, 29, 26, 11, 1, 6, 17, 12, 22, 24, 7, 4, 3, 2, 8, 27, 16, 20, 25, 21],
                "worst-individual-distance": 85393.3436870049,
                "average-distance": 79451.46243299522,
                "individual-distances": []
            }, {
                "best-individual-sequence": [15, 19, 29, 24, 25, 17, 14, 18, 20, 23, 13, 16, 26, 27, 28, 22, 6, 11, 1, 2, 7, 4, 3, 8, 5, 10, 9, 12, 21],
                "best-individual-distance": 59967.63510459767,
                "worst-individual-sequence": [27, 2, 25, 26, 8, 4, 24, 18, 23, 17, 12, 28, 13, 3, 15, 7, 14, 19, 9, 11, 6, 10, 5, 1, 21, 22, 29, 16, 20],
                "worst-individual-distance": 84303.5017627089,
                "average-distance": 78566.78271290005,
                "individual-distances": []
            }, {
                "best-individual-sequence": [15, 19, 29, 24, 25, 17, 14, 18, 20, 23, 13, 16, 26, 27, 28, 22, 6, 11, 1, 2, 7, 4, 3, 8, 5, 10, 9, 12, 21],
                "best-individual-distance": 59967.63510459767,
                "worst-individual-sequence": [23, 3, 12, 13, 15, 11, 5, 10, 1, 2, 27, 24, 25, 17, 8, 9, 18, 4, 6, 29, 20, 22, 26, 16, 21, 28, 7, 19, 14],
                "worst-individual-distance": 83258.067566564,
                "average-distance": 77603.93104006335,
                "individual-distances": []
            }, {
                "best-individual-sequence": [15, 19, 29, 24, 25, 17, 14, 18, 20, 23, 13, 16, 26, 27, 28, 22, 6, 11, 1, 2, 7, 4, 3, 8, 5, 10, 9, 12, 21],
                "best-individual-distance": 59967.63510459767,
                "worst-individual-sequence": [25, 26, 11, 4, 1, 3, 6, 8, 19, 17, 27, 28, 22, 21, 20, 15, 5, 2, 7, 9, 23, 14, 29, 10, 24, 16, 13, 12, 18],
                "worst-individual-distance": 82233.15869127467,
                "average-distance": 76849.75537477442,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 29, 16, 19, 18, 15, 12, 1, 2, 6, 11, 8, 5, 3, 7, 4, 13, 10, 9, 28, 23, 24, 27, 14, 21, 20, 22, 17, 25],
                "best-individual-distance": 59437.565725728586,
                "worst-individual-sequence": [7, 12, 2, 6, 8, 11, 4, 1, 3, 22, 13, 5, 9, 29, 19, 23, 25, 21, 26, 24, 15, 17, 28, 14, 10, 18, 20, 16, 27],
                "worst-individual-distance": 81264.16045575382,
                "average-distance": 75958.4639075203,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 29, 16, 19, 18, 15, 12, 1, 2, 6, 11, 8, 5, 3, 7, 4, 13, 10, 9, 28, 23, 24, 27, 14, 21, 20, 22, 17, 25],
                "best-individual-distance": 59437.565725728586,
                "worst-individual-sequence": [10, 13, 22, 20, 25, 26, 16, 29, 23, 27, 21, 9, 8, 7, 3, 2, 12, 6, 5, 11, 19, 17, 15, 14, 28, 4, 1, 24, 18],
                "worst-individual-distance": 80434.81345561601,
                "average-distance": 75091.82652449215,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 25, 27, 28, 29, 24, 16, 14, 18, 15, 19, 11, 1, 6, 8, 4, 5, 3, 9, 23, 21, 17, 22, 13, 7, 2, 12, 10, 20],
                "best-individual-distance": 56869.59002027443,
                "worst-individual-sequence": [28, 17, 13, 19, 23, 24, 22, 8, 10, 6, 4, 9, 11, 21, 20, 14, 5, 2, 1, 12, 3, 27, 25, 16, 26, 7, 29, 18, 15],
                "worst-individual-distance": 79452.34667527898,
                "average-distance": 74222.09776768052,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 25, 27, 28, 29, 24, 16, 14, 18, 15, 19, 11, 1, 6, 8, 4, 5, 3, 9, 23, 21, 17, 22, 13, 7, 2, 12, 10, 20],
                "best-individual-distance": 56869.59002027443,
                "worst-individual-sequence": [7, 12, 2, 6, 8, 11, 4, 1, 3, 22, 13, 5, 9, 29, 19, 23, 25, 21, 26, 24, 15, 17, 28, 14, 10, 18, 20, 16, 27],
                "worst-individual-distance": 78685.80466404345,
                "average-distance": 73419.77812493317,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 25, 27, 28, 29, 24, 16, 14, 18, 15, 19, 11, 1, 6, 8, 4, 5, 3, 9, 23, 21, 17, 22, 13, 7, 2, 12, 10, 20],
                "best-individual-distance": 56869.59002027443,
                "worst-individual-sequence": [8, 10, 4, 18, 28, 25, 20, 29, 6, 7, 1, 2, 5, 15, 23, 22, 26, 19, 17, 3, 12, 11, 24, 16, 21, 14, 27, 9, 13],
                "worst-individual-distance": 77856.42615804814,
                "average-distance": 72630.02027372898,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 5, 7, 12, 11, 18, 28, 10, 1, 2, 6, 8, 14, 19, 15, 21, 27, 25, 26, 17, 23, 29, 20, 24, 16, 22, 13, 9, 4],
                "best-individual-distance": 56084.18243640573,
                "worst-individual-sequence": [7, 10, 12, 6, 8, 14, 19, 23, 28, 24, 15, 22, 20, 16, 18, 9, 3, 1, 2, 21, 27, 17, 4, 5, 13, 25, 26, 29, 11],
                "worst-individual-distance": 77074.8778019517,
                "average-distance": 71839.46382821142,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 5, 7, 12, 11, 18, 28, 10, 1, 2, 6, 8, 14, 19, 15, 21, 27, 25, 26, 17, 23, 29, 20, 24, 16, 22, 13, 9, 4],
                "best-individual-distance": 56084.18243640573,
                "worst-individual-sequence": [24, 29, 14, 13, 5, 8, 10, 7, 18, 22, 12, 2, 1, 3, 6, 15, 21, 11, 27, 25, 26, 28, 17, 23, 16, 20, 19, 4, 9],
                "worst-individual-distance": 76312.62396290741,
                "average-distance": 71050.6893876529,
                "individual-distances": []
            }, {
                "best-individual-sequence": [13, 14, 10, 9, 18, 15, 12, 1, 2, 6, 4, 11, 5, 3, 8, 7, 17, 27, 25, 20, 21, 22, 16, 24, 28, 26, 29, 23, 19],
                "best-individual-distance": 55311.86781173207,
                "worst-individual-sequence": [28, 17, 13, 19, 23, 24, 22, 8, 10, 6, 4, 9, 11, 21, 20, 14, 5, 2, 1, 12, 3, 27, 25, 16, 26, 7, 29, 18, 15],
                "worst-individual-distance": 75510.20868924995,
                "average-distance": 70371.76144787067,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 18, 15, 12, 1, 2, 6, 8, 7, 11, 10, 13, 19, 23, 24, 22, 20, 27, 25, 16, 17, 14, 28, 26, 29, 21, 9, 3, 4],
                "best-individual-distance": 53419.08792470194,
                "worst-individual-sequence": [28, 12, 25, 18, 8, 26, 3, 10, 5, 21, 15, 29, 22, 23, 17, 19, 13, 9, 1, 2, 6, 11, 4, 7, 14, 27, 16, 20, 24],
                "worst-individual-distance": 74739.54590902275,
                "average-distance": 69583.72662949008,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 28, 16, 24, 9, 18, 27, 29, 26, 23, 22, 25, 17, 15, 19, 12, 7, 8, 10, 11, 4, 3, 5, 1, 2, 6, 21, 13, 14],
                "best-individual-distance": 50932.07969303974,
                "worst-individual-sequence": [21, 9, 6, 4, 5, 13, 3, 16, 25, 28, 19, 24, 26, 27, 15, 7, 2, 1, 8, 17, 18, 22, 23, 29, 12, 14, 10, 11, 20],
                "worst-individual-distance": 73889.64997563536,
                "average-distance": 68740.95304497995,
                "individual-distances": []
            }, {
                "best-individual-sequence": [20, 28, 16, 24, 9, 18, 27, 29, 26, 23, 22, 25, 17, 15, 19, 12, 7, 8, 10, 11, 4, 3, 5, 1, 2, 6, 21, 13, 14],
                "best-individual-distance": 50932.07969303974,
                "worst-individual-sequence": [23, 18, 9, 7, 26, 19, 16, 15, 12, 1, 2, 6, 4, 11, 5, 3, 8, 17, 27, 20, 22, 10, 25, 14, 13, 29, 24, 28, 21],
                "worst-individual-distance": 73025.44474240913,
                "average-distance": 67903.53709690024,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 28, 21, 12, 11, 8, 5, 10, 18, 22, 29, 23, 15, 20, 17, 19, 13, 9, 1, 2, 6, 3, 4, 7, 14, 27, 16, 25, 24],
                "best-individual-distance": 50176.50346200247,
                "worst-individual-sequence": [3, 12, 28, 24, 25, 21, 5, 10, 18, 22, 29, 23, 15, 20, 17, 19, 13, 9, 1, 2, 6, 11, 4, 7, 14, 27, 16, 26, 8],
                "worst-individual-distance": 72260.58176301431,
                "average-distance": 67218.69481575444,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 28, 21, 12, 11, 8, 5, 10, 18, 22, 29, 23, 15, 20, 17, 19, 13, 9, 1, 2, 6, 3, 4, 7, 14, 27, 16, 25, 24],
                "best-individual-distance": 50176.50346200247,
                "worst-individual-sequence": [13, 12, 3, 19, 8, 11, 1, 2, 6, 7, 14, 22, 17, 23, 28, 24, 15, 21, 20, 27, 26, 25, 16, 5, 4, 9, 29, 10, 18],
                "worst-individual-distance": 71450.21409258046,
                "average-distance": 66492.47231871348,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 28, 21, 12, 11, 8, 5, 10, 18, 22, 29, 23, 15, 20, 17, 19, 13, 9, 1, 2, 6, 3, 4, 7, 14, 27, 16, 25, 24],
                "best-individual-distance": 50176.50346200247,
                "worst-individual-sequence": [17, 26, 28, 24, 14, 22, 25, 16, 18, 3, 1, 2, 9, 7, 15, 12, 6, 11, 20, 27, 21, 29, 23, 5, 10, 4, 8, 13, 19],
                "worst-individual-distance": 70577.79175772492,
                "average-distance": 65823.14102271995,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 28, 21, 12, 11, 8, 5, 10, 18, 22, 29, 23, 15, 20, 17, 19, 13, 9, 1, 2, 6, 3, 4, 7, 14, 27, 16, 25, 24],
                "best-individual-distance": 50176.50346200247,
                "worst-individual-sequence": [4, 13, 20, 21, 17, 24, 25, 29, 19, 6, 8, 12, 1, 22, 28, 18, 23, 27, 26, 15, 7, 14, 10, 3, 9, 16, 2, 11, 5],
                "worst-individual-distance": 69909.6496154977,
                "average-distance": 65171.06299673017,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 28, 21, 12, 11, 8, 5, 10, 18, 22, 29, 23, 15, 20, 17, 19, 13, 9, 1, 2, 6, 3, 4, 7, 14, 27, 16, 25, 24],
                "best-individual-distance": 50176.50346200247,
                "worst-individual-sequence": [19, 1, 10, 3, 6, 2, 16, 28, 24, 20, 15, 22, 27, 25, 26, 17, 21, 29, 23, 14, 7, 4, 5, 8, 13, 12, 11, 18, 9],
                "worst-individual-distance": 69133.06927454742,
                "average-distance": 64532.50685248381,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 28, 21, 12, 11, 8, 5, 10, 18, 22, 29, 23, 15, 20, 17, 19, 13, 9, 1, 2, 6, 3, 4, 7, 14, 27, 16, 25, 24],
                "best-individual-distance": 50176.50346200247,
                "worst-individual-sequence": [26, 18, 29, 23, 15, 19, 13, 1, 2, 6, 4, 11, 5, 3, 16, 17, 8, 7, 27, 20, 22, 9, 10, 14, 12, 21, 28, 24, 25],
                "worst-individual-distance": 68381.82672612988,
                "average-distance": 63945.64206425391,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 28, 21, 12, 11, 8, 5, 10, 18, 22, 29, 23, 15, 20, 17, 19, 13, 9, 1, 2, 6, 3, 4, 7, 14, 27, 16, 25, 24],
                "best-individual-distance": 50176.50346200247,
                "worst-individual-sequence": [29, 17, 18, 13, 16, 26, 27, 28, 24, 20, 8, 25, 14, 10, 11, 9, 4, 5, 1, 3, 2, 6, 7, 15, 19, 12, 23, 22, 21],
                "worst-individual-distance": 67773.44774226478,
                "average-distance": 63440.38988852646,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 28, 21, 12, 11, 8, 5, 10, 18, 22, 29, 23, 15, 20, 17, 19, 13, 9, 1, 2, 6, 3, 4, 7, 14, 27, 16, 25, 24],
                "best-individual-distance": 50176.50346200247,
                "worst-individual-sequence": [19, 13, 9, 11, 23, 29, 12, 5, 14, 20, 28, 22, 16, 24, 18, 8, 7, 3, 10, 2, 1, 6, 4, 27, 25, 21, 26, 15, 17],
                "worst-individual-distance": 67210.1721302365,
                "average-distance": 62959.93756169103,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 21, 2, 3, 4, 5, 10, 18, 22, 29, 23, 15, 20, 17, 19, 13, 9, 7, 1, 6, 11, 8, 12, 14, 28, 16, 24, 27, 25],
                "best-individual-distance": 49752.46505504277,
                "worst-individual-sequence": [9, 14, 20, 28, 22, 24, 11, 4, 5, 8, 7, 19, 16, 15, 21, 27, 25, 26, 23, 29, 6, 2, 1, 3, 10, 12, 17, 18, 13],
                "worst-individual-distance": 66627.57790254362,
                "average-distance": 62417.19262700609,
                "individual-distances": []
            }, {
                "best-individual-sequence": [26, 21, 2, 3, 4, 5, 10, 18, 22, 29, 23, 15, 20, 17, 19, 13, 9, 7, 1, 6, 11, 8, 12, 14, 28, 16, 24, 27, 25],
                "best-individual-distance": 49752.46505504277,
                "worst-individual-sequence": [28, 27, 29, 9, 5, 4, 25, 13, 20, 16, 24, 18, 8, 7, 3, 10, 2, 1, 6, 11, 15, 19, 21, 17, 26, 23, 14, 12, 22],
                "worst-individual-distance": 66034.22672660585,
                "average-distance": 61963.27316470204,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 21, 15, 14, 12, 13, 25, 2, 6, 5, 3, 8, 10, 11, 9, 4, 7, 1, 27, 20, 22, 19, 17, 18, 16, 24, 26, 29, 28],
                "best-individual-distance": 48019.46611801891,
                "worst-individual-sequence": [11, 9, 3, 6, 2, 1, 4, 10, 5, 12, 7, 15, 18, 25, 21, 26, 22, 19, 28, 29, 24, 16, 17, 14, 8, 13, 20, 23, 27],
                "worst-individual-distance": 65547.13804945968,
                "average-distance": 61407.01729717229,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 21, 15, 14, 12, 13, 25, 2, 6, 5, 3, 8, 10, 11, 9, 4, 7, 1, 27, 20, 22, 19, 17, 18, 16, 24, 26, 29, 28],
                "best-individual-distance": 48019.46611801891,
                "worst-individual-sequence": [4, 14, 20, 6, 28, 21, 19, 27, 25, 26, 22, 16, 24, 18, 15, 17, 23, 29, 13, 5, 8, 12, 7, 11, 10, 2, 1, 3, 9],
                "worst-individual-distance": 65044.58068902609,
                "average-distance": 60906.212709425774,
                "individual-distances": []
            }, {
                "best-individual-sequence": [23, 21, 15, 14, 12, 13, 25, 2, 6, 5, 3, 8, 10, 11, 9, 4, 7, 1, 27, 20, 22, 19, 17, 18, 16, 24, 26, 29, 28],
                "best-individual-distance": 48019.46611801891,
                "worst-individual-sequence": [9, 13, 10, 20, 28, 22, 24, 16, 12, 1, 2, 6, 4, 11, 15, 21, 27, 25, 26, 17, 23, 19, 14, 5, 3, 8, 7, 29, 18],
                "worst-individual-distance": 64534.50064997929,
                "average-distance": 60316.716517160676,
                "individual-distances": []
            }, {
                "best-individual-sequence": [29, 22, 13, 14, 1, 11, 10, 4, 2, 6, 5, 3, 8, 7, 9, 12, 17, 15, 19, 18, 28, 20, 24, 27, 23, 21, 25, 26, 16],
                "best-individual-distance": 47253.620564220444,
                "worst-individual-sequence": [29, 23, 7, 12, 15, 21, 13, 16, 9, 1, 2, 6, 4, 11, 5, 3, 8, 10, 19, 14, 18, 28, 24, 22, 26, 17, 25, 27, 20],
                "worst-individual-distance": 63976.9680075466,
                "average-distance": 59774.556281088735,
                "individual-distances": []
            }, {
                "best-individual-sequence": [29, 22, 13, 14, 1, 11, 10, 4, 2, 6, 5, 3, 8, 7, 9, 12, 17, 15, 19, 18, 28, 20, 24, 27, 23, 21, 25, 26, 16],
                "best-individual-distance": 47253.620564220444,
                "worst-individual-sequence": [15, 26, 19, 29, 27, 20, 25, 24, 21, 22, 28, 18, 23, 7, 3, 16, 14, 5, 17, 8, 13, 9, 4, 11, 10, 1, 2, 6, 12],
                "worst-individual-distance": 63562.962274610545,
                "average-distance": 59299.963793720744,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 7, 3, 1, 11, 10, 12, 2, 6, 8, 14, 15, 21, 17, 23, 20, 22, 19, 18, 28, 25, 16, 24, 27, 26, 29, 13, 9, 4],
                "best-individual-distance": 43685.19291522079,
                "worst-individual-sequence": [18, 19, 29, 22, 23, 13, 2, 1, 7, 4, 3, 5, 6, 15, 21, 11, 10, 25, 26, 28, 27, 17, 14, 9, 12, 8, 20, 24, 16],
                "worst-individual-distance": 62990.43846844265,
                "average-distance": 58809.175364379174,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 7, 3, 1, 11, 10, 12, 2, 6, 8, 14, 15, 21, 17, 23, 20, 22, 19, 18, 28, 25, 16, 24, 27, 26, 29, 13, 9, 4],
                "best-individual-distance": 43685.19291522079,
                "worst-individual-sequence": [20, 24, 16, 28, 18, 10, 1, 2, 6, 8, 14, 19, 21, 11, 9, 4, 5, 7, 3, 26, 12, 22, 29, 23, 15, 17, 13, 25, 27],
                "worst-individual-distance": 62293.96791975242,
                "average-distance": 58252.38112265648,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 7, 3, 1, 11, 10, 12, 2, 6, 8, 14, 15, 21, 17, 23, 20, 22, 19, 18, 28, 25, 16, 24, 27, 26, 29, 13, 9, 4],
                "best-individual-distance": 43685.19291522079,
                "worst-individual-sequence": [22, 13, 9, 7, 26, 19, 18, 15, 12, 1, 2, 6, 4, 11, 5, 3, 8, 24, 25, 20, 29, 23, 17, 14, 27, 16, 21, 28, 10],
                "worst-individual-distance": 61783.71286202074,
                "average-distance": 57811.365298977704,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 7, 3, 1, 11, 10, 12, 2, 6, 8, 14, 15, 21, 17, 23, 20, 22, 19, 18, 28, 25, 16, 24, 27, 26, 29, 13, 9, 4],
                "best-individual-distance": 43685.19291522079,
                "worst-individual-sequence": [29, 27, 19, 14, 12, 13, 4, 5, 8, 28, 22, 16, 24, 18, 20, 9, 7, 3, 10, 2, 1, 6, 11, 15, 17, 21, 25, 26, 23],
                "worst-individual-distance": 61334.090463808694,
                "average-distance": 57322.863376840636,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 7, 3, 1, 11, 10, 12, 2, 6, 8, 14, 15, 21, 17, 23, 20, 22, 19, 18, 28, 25, 16, 24, 27, 26, 29, 13, 9, 4],
                "best-individual-distance": 43685.19291522079,
                "worst-individual-sequence": [18, 13, 20, 25, 14, 22, 17, 15, 19, 12, 10, 3, 11, 9, 4, 5, 1, 2, 6, 7, 8, 26, 29, 27, 24, 21, 28, 23, 16],
                "worst-individual-distance": 60916.62474358436,
                "average-distance": 56876.774113763015,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 7, 3, 1, 11, 10, 12, 2, 6, 8, 14, 15, 21, 17, 23, 20, 22, 19, 18, 28, 25, 16, 24, 27, 26, 29, 13, 9, 4],
                "best-individual-distance": 43685.19291522079,
                "worst-individual-sequence": [13, 9, 12, 7, 28, 18, 11, 10, 1, 2, 6, 8, 14, 19, 15, 21, 27, 25, 4, 3, 5, 16, 24, 26, 22, 29, 23, 20, 17],
                "worst-individual-distance": 60331.06288566206,
                "average-distance": 56421.07773644408,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 7, 3, 1, 11, 10, 12, 2, 6, 8, 14, 15, 21, 17, 23, 20, 22, 19, 18, 28, 25, 16, 24, 27, 26, 29, 13, 9, 4],
                "best-individual-distance": 43685.19291522079,
                "worst-individual-sequence": [27, 25, 29, 16, 14, 13, 21, 10, 5, 8, 7, 9, 3, 4, 1, 2, 6, 12, 17, 22, 28, 11, 18, 23, 15, 20, 19, 24, 26],
                "worst-individual-distance": 59798.10487499006,
                "average-distance": 56031.14768179394,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 7, 3, 1, 11, 10, 12, 2, 6, 8, 14, 15, 21, 17, 23, 20, 22, 19, 18, 28, 25, 16, 24, 27, 26, 29, 13, 9, 4],
                "best-individual-distance": 43685.19291522079,
                "worst-individual-sequence": [12, 13, 3, 20, 28, 22, 16, 24, 14, 15, 18, 8, 7, 10, 11, 9, 4, 5, 1, 2, 6, 17, 29, 25, 27, 21, 26, 23, 19],
                "worst-individual-distance": 59258.07412068572,
                "average-distance": 55589.67781885325,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 7, 3, 1, 11, 10, 12, 2, 6, 8, 14, 15, 21, 17, 23, 20, 22, 19, 18, 28, 25, 16, 24, 27, 26, 29, 13, 9, 4],
                "best-individual-distance": 43685.19291522079,
                "worst-individual-sequence": [5, 7, 3, 22, 1, 10, 11, 18, 28, 2, 6, 8, 14, 19, 15, 21, 27, 25, 26, 17, 23, 29, 20, 24, 16, 12, 13, 9, 4],
                "worst-individual-distance": 58838.55308645862,
                "average-distance": 55159.636109848754,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 7, 3, 1, 11, 10, 12, 2, 6, 8, 14, 15, 21, 17, 23, 20, 22, 19, 18, 28, 25, 16, 24, 27, 26, 29, 13, 9, 4],
                "best-individual-distance": 43685.19291522079,
                "worst-individual-sequence": [26, 23, 22, 14, 12, 13, 9, 4, 5, 8, 7, 19, 16, 24, 18, 20, 28, 3, 10, 2, 1, 6, 11, 15, 17, 29, 25, 27, 21],
                "worst-individual-distance": 58390.71435579676,
                "average-distance": 54753.37699259399,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 7, 3, 1, 11, 10, 12, 2, 6, 8, 14, 15, 21, 17, 23, 20, 22, 19, 18, 28, 25, 16, 24, 27, 26, 29, 13, 9, 4],
                "best-individual-distance": 43685.19291522079,
                "worst-individual-sequence": [15, 9, 26, 23, 29, 13, 12, 1, 2, 6, 4, 11, 5, 3, 8, 7, 17, 22, 21, 10, 19, 14, 18, 28, 20, 25, 16, 24, 27],
                "worst-individual-distance": 58002.40917948476,
                "average-distance": 54387.7734263912,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 7, 3, 1, 11, 10, 12, 2, 6, 8, 14, 15, 21, 17, 23, 20, 22, 19, 18, 28, 25, 16, 24, 27, 26, 29, 13, 9, 4],
                "best-individual-distance": 43685.19291522079,
                "worst-individual-sequence": [16, 28, 18, 10, 11, 5, 1, 2, 6, 14, 19, 8, 15, 21, 27, 25, 26, 17, 23, 29, 22, 20, 24, 13, 9, 4, 3, 7, 12],
                "worst-individual-distance": 57611.871887020665,
                "average-distance": 54058.42604937431,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 1, 2, 6, 5, 8, 7, 3, 9, 13, 12, 15, 19, 18, 28, 20, 23, 22, 17, 27, 25, 24, 4, 26, 16, 29, 14, 21, 11],
                "best-individual-distance": 43328.42998826221,
                "worst-individual-sequence": [23, 28, 7, 18, 15, 12, 11, 10, 1, 2, 6, 4, 3, 5, 8, 20, 29, 24, 22, 21, 17, 13, 9, 14, 19, 26, 25, 16, 27],
                "worst-individual-distance": 57146.73024412867,
                "average-distance": 53721.92589957773,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 1, 2, 6, 5, 8, 7, 3, 9, 13, 12, 15, 19, 18, 28, 20, 23, 22, 17, 27, 25, 24, 4, 26, 16, 29, 14, 21, 11],
                "best-individual-distance": 43328.42998826221,
                "worst-individual-sequence": [5, 1, 6, 11, 13, 9, 4, 7, 15, 22, 14, 18, 23, 29, 21, 24, 27, 20, 28, 17, 25, 26, 16, 19, 12, 3, 10, 8, 2],
                "worst-individual-distance": 56714.41175473233,
                "average-distance": 53379.565979184445,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 1, 2, 6, 5, 8, 7, 3, 9, 13, 12, 15, 19, 18, 28, 20, 23, 22, 17, 27, 25, 24, 4, 26, 16, 29, 14, 21, 11],
                "best-individual-distance": 43328.42998826221,
                "worst-individual-sequence": [11, 1, 2, 4, 26, 22, 23, 21, 10, 6, 5, 3, 8, 7, 9, 12, 17, 15, 19, 18, 28, 20, 14, 25, 27, 29, 24, 16, 13],
                "worst-individual-distance": 56354.64824752779,
                "average-distance": 53094.754368744914,
                "individual-distances": []
            }, {
                "best-individual-sequence": [10, 1, 2, 6, 5, 8, 7, 3, 9, 13, 12, 15, 19, 18, 28, 20, 23, 22, 17, 27, 25, 24, 4, 26, 16, 29, 14, 21, 11],
                "best-individual-distance": 43328.42998826221,
                "worst-individual-sequence": [28, 24, 21, 18, 27, 29, 26, 22, 25, 17, 15, 14, 19, 23, 9, 7, 8, 10, 11, 4, 3, 5, 1, 2, 6, 12, 13, 20, 16],
                "worst-individual-distance": 56009.81637441176,
                "average-distance": 52789.66024981708,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 7, 3, 1, 11, 10, 12, 2, 6, 8, 14, 15, 21, 17, 23, 20, 22, 19, 18, 28, 25, 16, 24, 27, 26, 29, 13, 9, 4],
                "best-individual-distance": 42357.11155445565,
                "worst-individual-sequence": [25, 23, 19, 12, 13, 9, 4, 3, 7, 8, 16, 24, 22, 14, 5, 10, 2, 1, 6, 11, 15, 17, 29, 18, 28, 20, 21, 27, 26],
                "worst-individual-distance": 55528.49168102094,
                "average-distance": 52439.527851325816,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 7, 3, 1, 11, 10, 12, 2, 6, 8, 14, 15, 21, 17, 23, 20, 22, 19, 18, 28, 25, 16, 24, 27, 26, 29, 13, 9, 4],
                "best-individual-distance": 42357.11155445565,
                "worst-individual-sequence": [24, 25, 27, 20, 17, 29, 26, 22, 23, 14, 18, 12, 3, 19, 7, 8, 15, 5, 10, 4, 2, 1, 6, 11, 9, 13, 16, 28, 21],
                "worst-individual-distance": 55290.371621116916,
                "average-distance": 52165.17494205988,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 7, 3, 1, 11, 10, 12, 2, 6, 8, 14, 15, 21, 17, 23, 20, 22, 19, 18, 28, 25, 16, 24, 27, 26, 29, 13, 9, 4],
                "best-individual-distance": 42357.11155445565,
                "worst-individual-sequence": [12, 13, 9, 4, 3, 8, 26, 5, 23, 28, 16, 24, 20, 14, 18, 7, 22, 10, 2, 1, 6, 11, 15, 17, 29, 25, 27, 21, 19],
                "worst-individual-distance": 54973.610430310146,
                "average-distance": 51870.74893228081,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 7, 3, 1, 11, 10, 12, 2, 6, 8, 14, 15, 21, 17, 23, 20, 22, 19, 18, 28, 25, 16, 24, 27, 26, 29, 13, 9, 4],
                "best-individual-distance": 42357.11155445565,
                "worst-individual-sequence": [12, 16, 20, 22, 18, 9, 13, 4, 1, 2, 6, 5, 3, 8, 7, 10, 11, 15, 17, 29, 25, 27, 14, 19, 21, 24, 26, 28, 23],
                "worst-individual-distance": 54640.11333839846,
                "average-distance": 51544.30362146839,
                "individual-distances": []
            }, {
                "best-individual-sequence": [5, 7, 3, 1, 11, 10, 12, 2, 6, 8, 14, 15, 21, 17, 23, 20, 22, 19, 18, 28, 25, 16, 24, 27, 26, 29, 13, 9, 4],
                "best-individual-distance": 42357.11155445565,
                "worst-individual-sequence": [5, 2, 1, 6, 9, 14, 11, 10, 21, 17, 15, 23, 19, 18, 28, 25, 16, 24, 27, 26, 29, 13, 12, 4, 3, 7, 8, 20, 22],
                "worst-individual-distance": 54272.65663996676,
                "average-distance": 51221.17362068533,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 1, 2, 6, 10, 8, 13, 14, 15, 19, 18, 21, 27, 24, 25, 26, 28, 17, 23, 29, 22, 20, 16, 7, 12, 11, 5, 3, 9],
                "best-individual-distance": 41701.18828826754,
                "worst-individual-sequence": [22, 14, 19, 15, 28, 18, 11, 10, 12, 1, 2, 6, 4, 5, 3, 8, 24, 25, 20, 29, 23, 17, 27, 16, 26, 21, 13, 7, 9],
                "worst-individual-distance": 53822.382461783614,
                "average-distance": 50961.938126740024,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 1, 2, 6, 10, 8, 13, 14, 15, 19, 18, 21, 27, 24, 25, 26, 28, 17, 23, 29, 22, 20, 16, 7, 12, 11, 5, 3, 9],
                "best-individual-distance": 41701.18828826754,
                "worst-individual-sequence": [26, 23, 19, 12, 13, 9, 4, 3, 18, 28, 22, 16, 24, 8, 14, 20, 7, 5, 10, 2, 1, 6, 11, 15, 17, 29, 25, 27, 21],
                "worst-individual-distance": 53592.886368860316,
                "average-distance": 50671.35809133885,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 1, 2, 6, 10, 8, 13, 14, 15, 19, 18, 21, 27, 24, 25, 26, 28, 17, 23, 29, 22, 20, 16, 7, 12, 11, 5, 3, 9],
                "best-individual-distance": 41701.18828826754,
                "worst-individual-sequence": [29, 18, 15, 17, 16, 28, 27, 25, 26, 20, 24, 13, 19, 23, 12, 7, 8, 10, 11, 4, 3, 5, 1, 2, 6, 9, 21, 14, 22],
                "worst-individual-distance": 53323.80208172585,
                "average-distance": 50432.22751546156,
                "individual-distances": []
            }, {
                "best-individual-sequence": [4, 1, 2, 6, 10, 8, 13, 14, 15, 19, 18, 21, 27, 24, 25, 26, 28, 17, 23, 29, 22, 20, 16, 7, 12, 11, 5, 3, 9],
                "best-individual-distance": 41701.18828826754,
                "worst-individual-sequence": [14, 12, 13, 9, 4, 5, 8, 7, 3, 27, 20, 22, 10, 2, 1, 6, 11, 15, 18, 29, 16, 24, 28, 23, 17, 25, 26, 21, 19],
                "worst-individual-distance": 53038.381469521795,
                "average-distance": 50175.56095191915,
                "individual-distances": []
            }, {
                "best-individual-sequence": [25, 24, 16, 26, 28, 21, 17, 18, 22, 29, 15, 13, 19, 23, 12, 7, 8, 10, 11, 4, 3, 5, 1, 2, 6, 9, 14, 20, 27],
                "best-individual-distance": 41542.330578162844,
                "worst-individual-sequence": [12, 22, 8, 19, 28, 20, 18, 14, 10, 23, 7, 5, 2, 1, 6, 11, 15, 17, 27, 25, 24, 16, 29, 21, 26, 13, 9, 4, 3],
                "worst-individual-distance": 52741.244835171354,
                "average-distance": 49888.04236958333,
                "individual-distances": []
            }, {
                "best-individual-sequence": [25, 24, 16, 26, 28, 21, 17, 18, 22, 29, 15, 13, 19, 23, 12, 7, 8, 10, 11, 4, 3, 5, 1, 2, 6, 9, 14, 20, 27],
                "best-individual-distance": 41542.330578162844,
                "worst-individual-sequence": [5, 7, 3, 22, 11, 18, 28, 10, 1, 2, 6, 8, 15, 21, 27, 25, 26, 17, 19, 14, 23, 29, 20, 24, 16, 12, 13, 9, 4],
                "worst-individual-distance": 52516.853484526364,
                "average-distance": 49613.28769543855,
                "individual-distances": []
            }, {
                "best-individual-sequence": [25, 24, 16, 26, 28, 21, 17, 18, 22, 29, 15, 13, 19, 23, 12, 7, 8, 10, 11, 4, 3, 5, 1, 2, 6, 9, 14, 20, 27],
                "best-individual-distance": 41542.330578162844,
                "worst-individual-sequence": [12, 13, 14, 28, 18, 22, 4, 3, 5, 1, 2, 6, 21, 17, 15, 19, 26, 20, 29, 23, 25, 27, 16, 24, 10, 11, 9, 7, 8],
                "worst-individual-distance": 52136.679586519735,
                "average-distance": 49325.841774674416,
                "individual-distances": []
            }, {
                "best-individual-sequence": [25, 24, 16, 26, 28, 21, 17, 18, 22, 29, 15, 13, 19, 23, 12, 7, 8, 10, 11, 4, 3, 5, 1, 2, 6, 9, 14, 20, 27],
                "best-individual-distance": 41542.330578162844,
                "worst-individual-sequence": [8, 19, 18, 15, 12, 1, 2, 6, 4, 5, 11, 10, 14, 13, 28, 26, 17, 21, 24, 25, 27, 22, 29, 20, 16, 23, 3, 9, 7],
                "worst-individual-distance": 51939.56207665459,
                "average-distance": 49097.37256379261,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 10, 17, 2, 6, 5, 3, 8, 7, 9, 12, 1, 15, 19, 18, 28, 20, 25, 16, 24, 27, 21, 26, 29, 22, 23, 14, 13, 4],
                "best-individual-distance": 41039.515174423694,
                "worst-individual-sequence": [24, 13, 16, 10, 11, 5, 3, 9, 4, 1, 2, 6, 7, 8, 21, 22, 26, 17, 19, 14, 23, 29, 18, 15, 12, 28, 27, 25, 20],
                "worst-individual-distance": 51633.66441436739,
                "average-distance": 48870.94574244454,
                "individual-distances": []
            }, {
                "best-individual-sequence": [11, 10, 17, 2, 6, 5, 3, 8, 7, 9, 12, 1, 15, 19, 18, 28, 20, 25, 16, 24, 27, 21, 26, 29, 22, 23, 14, 13, 4],
                "best-individual-distance": 41039.515174423694,
                "worst-individual-sequence": [8, 7, 3, 10, 2, 1, 6, 11, 24, 27, 16, 20, 14, 25, 28, 21, 17, 12, 18, 26, 29, 22, 15, 23, 19, 13, 9, 4, 5],
                "worst-individual-distance": 51250.93830185871,
                "average-distance": 48596.00053976122,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 4, 5, 10, 2, 1, 6, 11, 8, 12, 14, 17, 18, 22, 29, 28, 20, 25, 16, 24, 27, 26, 23, 21, 15, 19, 13, 9, 7],
                "best-individual-distance": 36195.28137971668,
                "worst-individual-sequence": [5, 9, 4, 1, 2, 6, 7, 8, 12, 13, 14, 28, 18, 22, 15, 19, 21, 20, 23, 17, 25, 16, 24, 27, 26, 29, 10, 3, 11],
                "worst-individual-distance": 50999.64385011722,
                "average-distance": 48352.32431528687,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 4, 5, 10, 2, 1, 6, 11, 8, 12, 14, 17, 18, 22, 29, 28, 20, 25, 16, 24, 27, 26, 23, 21, 15, 19, 13, 9, 7],
                "best-individual-distance": 36195.28137971668,
                "worst-individual-sequence": [21, 26, 19, 12, 13, 9, 4, 3, 7, 14, 16, 24, 22, 8, 5, 10, 2, 1, 6, 11, 15, 17, 29, 18, 28, 20, 25, 27, 23],
                "worst-individual-distance": 50867.10319953025,
                "average-distance": 48163.61850288956,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 4, 5, 10, 2, 1, 6, 11, 8, 12, 14, 17, 18, 22, 29, 28, 20, 25, 16, 24, 27, 26, 23, 21, 15, 19, 13, 9, 7],
                "best-individual-distance": 36195.28137971668,
                "worst-individual-sequence": [5, 7, 3, 22, 1, 10, 11, 18, 28, 2, 6, 8, 14, 19, 15, 21, 27, 25, 26, 17, 23, 29, 20, 24, 16, 12, 13, 9, 4],
                "worst-individual-distance": 50632.12312144495,
                "average-distance": 47893.71421909818,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 4, 5, 10, 2, 1, 6, 11, 8, 12, 14, 17, 18, 22, 29, 28, 20, 25, 16, 24, 27, 26, 23, 21, 15, 19, 13, 9, 7],
                "best-individual-distance": 36195.28137971668,
                "worst-individual-sequence": [7, 24, 13, 28, 18, 10, 11, 5, 1, 2, 6, 8, 14, 19, 15, 21, 27, 25, 26, 17, 23, 29, 22, 20, 12, 16, 9, 4, 3],
                "worst-individual-distance": 50343.77323405946,
                "average-distance": 47623.666444190036,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 4, 5, 10, 2, 1, 6, 11, 8, 12, 14, 17, 18, 22, 29, 28, 20, 25, 16, 24, 27, 26, 23, 21, 15, 19, 13, 9, 7],
                "best-individual-distance": 36195.28137971668,
                "worst-individual-sequence": [10, 3, 9, 4, 2, 1, 5, 6, 11, 15, 21, 20, 17, 22, 14, 13, 23, 19, 18, 28, 25, 16, 24, 27, 26, 29, 12, 7, 8],
                "worst-individual-distance": 50039.93132139811,
                "average-distance": 47331.78673105834,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 4, 5, 10, 2, 1, 6, 11, 8, 12, 14, 17, 18, 22, 29, 28, 20, 25, 16, 24, 27, 26, 23, 21, 15, 19, 13, 9, 7],
                "best-individual-distance": 36195.28137971668,
                "worst-individual-sequence": [14, 28, 21, 15, 20, 23, 22, 17, 27, 25, 24, 16, 29, 26, 19, 12, 7, 8, 10, 11, 4, 3, 5, 1, 2, 6, 18, 9, 13],
                "worst-individual-distance": 49831.47862482152,
                "average-distance": 47117.61770614568,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 4, 5, 10, 2, 1, 6, 11, 8, 12, 14, 17, 18, 22, 29, 28, 20, 25, 16, 24, 27, 26, 23, 21, 15, 19, 13, 9, 7],
                "best-individual-distance": 36195.28137971668,
                "worst-individual-sequence": [21, 19, 14, 12, 13, 9, 4, 5, 8, 7, 3, 10, 20, 22, 27, 2, 1, 6, 11, 15, 18, 29, 28, 23, 17, 24, 25, 16, 26],
                "worst-individual-distance": 49610.39209154264,
                "average-distance": 46874.912644086326,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 4, 5, 10, 2, 1, 6, 11, 8, 12, 14, 17, 18, 22, 29, 28, 20, 25, 16, 24, 27, 26, 23, 21, 15, 19, 13, 9, 7],
                "best-individual-distance": 36195.28137971668,
                "worst-individual-sequence": [13, 12, 26, 28, 17, 18, 11, 10, 1, 2, 6, 8, 14, 19, 15, 21, 27, 25, 23, 29, 22, 20, 16, 24, 4, 5, 3, 7, 9],
                "worst-individual-distance": 49297.60805726977,
                "average-distance": 46596.25786775058,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 4, 5, 10, 2, 1, 6, 11, 8, 12, 14, 17, 18, 22, 29, 28, 20, 25, 16, 24, 27, 26, 23, 21, 15, 19, 13, 9, 7],
                "best-individual-distance": 36195.28137971668,
                "worst-individual-sequence": [11, 10, 1, 2, 6, 16, 12, 18, 22, 15, 19, 21, 26, 20, 23, 17, 14, 8, 3, 28, 24, 27, 25, 29, 13, 9, 7, 4, 5],
                "worst-individual-distance": 48998.74606984091,
                "average-distance": 46360.1206488133,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 4, 5, 10, 2, 1, 6, 11, 8, 12, 14, 17, 18, 22, 29, 28, 20, 25, 16, 24, 27, 26, 23, 21, 15, 19, 13, 9, 7],
                "best-individual-distance": 36195.28137971668,
                "worst-individual-sequence": [5, 7, 3, 1, 11, 10, 12, 2, 6, 8, 14, 15, 21, 17, 23, 20, 22, 19, 18, 28, 25, 16, 24, 27, 26, 29, 13, 9, 4],
                "worst-individual-distance": 48637.170138444766,
                "average-distance": 46119.975057454816,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 4, 5, 10, 2, 1, 6, 11, 8, 12, 14, 17, 18, 22, 29, 28, 20, 25, 16, 24, 27, 26, 23, 21, 15, 19, 13, 9, 7],
                "best-individual-distance": 36195.28137971668,
                "worst-individual-sequence": [12, 7, 9, 10, 11, 4, 3, 5, 2, 1, 6, 8, 14, 19, 15, 21, 27, 25, 26, 17, 23, 29, 20, 28, 24, 16, 13, 18, 22],
                "worst-individual-distance": 48359.9300209572,
                "average-distance": 45889.63219736486,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 4, 5, 10, 2, 1, 6, 11, 8, 12, 14, 17, 18, 22, 29, 28, 20, 25, 16, 24, 27, 26, 23, 21, 15, 19, 13, 9, 7],
                "best-individual-distance": 36195.28137971668,
                "worst-individual-sequence": [21, 18, 23, 22, 17, 24, 25, 16, 27, 26, 13, 14, 15, 19, 12, 4, 7, 8, 10, 11, 3, 5, 1, 2, 6, 29, 9, 28, 20],
                "worst-individual-distance": 48031.78569130036,
                "average-distance": 45647.59980737452,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 4, 5, 10, 2, 1, 6, 11, 8, 12, 14, 17, 18, 22, 29, 28, 20, 25, 16, 24, 27, 26, 23, 21, 15, 19, 13, 9, 7],
                "best-individual-distance": 36195.28137971668,
                "worst-individual-sequence": [5, 8, 11, 10, 1, 2, 6, 3, 25, 27, 24, 12, 18, 22, 15, 19, 21, 26, 20, 29, 23, 17, 28, 16, 13, 9, 14, 7, 4],
                "worst-individual-distance": 47790.8857323406,
                "average-distance": 45467.16923012993,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 4, 5, 10, 2, 1, 6, 11, 8, 12, 14, 17, 18, 22, 29, 28, 20, 25, 16, 24, 27, 26, 23, 21, 15, 19, 13, 9, 7],
                "best-individual-distance": 36195.28137971668,
                "worst-individual-sequence": [10, 12, 2, 6, 8, 13, 15, 20, 22, 21, 27, 23, 19, 18, 28, 25, 16, 24, 26, 17, 29, 14, 9, 4, 5, 7, 3, 1, 11],
                "worst-individual-distance": 47577.75203428882,
                "average-distance": 45240.55551889716,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 4, 5, 10, 2, 1, 6, 11, 8, 12, 14, 17, 18, 22, 29, 28, 20, 25, 16, 24, 27, 26, 23, 21, 15, 19, 13, 9, 7],
                "best-individual-distance": 36195.28137971668,
                "worst-individual-sequence": [15, 18, 28, 20, 23, 21, 22, 17, 27, 25, 24, 16, 29, 26, 19, 12, 7, 8, 10, 11, 4, 3, 5, 1, 2, 6, 13, 14, 9],
                "worst-individual-distance": 47282.51557389938,
                "average-distance": 45054.36581283412,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 4, 5, 10, 2, 1, 6, 11, 8, 12, 14, 17, 18, 22, 29, 28, 20, 25, 16, 24, 27, 26, 23, 21, 15, 19, 13, 9, 7],
                "best-individual-distance": 36195.28137971668,
                "worst-individual-sequence": [14, 18, 16, 24, 25, 29, 23, 22, 19, 12, 7, 8, 10, 11, 4, 3, 5, 2, 1, 6, 17, 9, 28, 27, 26, 20, 21, 15, 13],
                "worst-individual-distance": 47039.08239589954,
                "average-distance": 44838.05968383958,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 4, 5, 10, 2, 1, 6, 11, 8, 12, 14, 17, 18, 22, 29, 28, 20, 25, 16, 24, 27, 26, 23, 21, 15, 19, 13, 9, 7],
                "best-individual-distance": 36195.28137971668,
                "worst-individual-sequence": [4, 5, 10, 29, 1, 6, 11, 8, 12, 14, 26, 24, 15, 2, 23, 17, 28, 27, 25, 20, 21, 22, 16, 18, 19, 13, 9, 7, 3],
                "worst-individual-distance": 46782.412417793195,
                "average-distance": 44646.472932292,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 4, 5, 10, 2, 1, 6, 11, 8, 12, 14, 17, 18, 22, 29, 28, 20, 25, 16, 24, 27, 26, 23, 21, 15, 19, 13, 9, 7],
                "best-individual-distance": 36195.28137971668,
                "worst-individual-sequence": [18, 15, 21, 23, 28, 20, 17, 27, 25, 24, 16, 29, 26, 19, 12, 10, 11, 4, 3, 5, 1, 2, 6, 14, 7, 8, 9, 13, 22],
                "worst-individual-distance": 46596.39236012284,
                "average-distance": 44435.28803710664,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 4, 5, 10, 2, 1, 6, 11, 8, 12, 14, 17, 18, 22, 29, 28, 20, 25, 16, 24, 27, 26, 23, 21, 15, 19, 13, 9, 7],
                "best-individual-distance": 36195.28137971668,
                "worst-individual-sequence": [13, 24, 25, 18, 22, 15, 19, 21, 26, 20, 29, 23, 17, 28, 16, 27, 14, 7, 8, 11, 10, 5, 3, 9, 4, 1, 2, 6, 12],
                "worst-individual-distance": 46326.47605764512,
                "average-distance": 44209.967963099334,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 4, 5, 10, 2, 1, 6, 11, 8, 12, 14, 17, 18, 22, 29, 28, 20, 25, 16, 24, 27, 26, 23, 21, 15, 19, 13, 9, 7],
                "best-individual-distance": 36195.28137971668,
                "worst-individual-sequence": [22, 13, 14, 18, 11, 10, 1, 2, 6, 5, 3, 4, 8, 7, 9, 12, 17, 15, 19, 28, 20, 24, 27, 23, 21, 25, 26, 16, 29],
                "worst-individual-distance": 46079.68810576734,
                "average-distance": 44026.095451870555,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 4, 5, 10, 2, 1, 6, 11, 8, 12, 14, 17, 18, 22, 29, 28, 20, 25, 16, 24, 27, 26, 23, 21, 15, 19, 13, 9, 7],
                "best-individual-distance": 36195.28137971668,
                "worst-individual-sequence": [10, 25, 2, 6, 5, 3, 8, 7, 9, 12, 15, 1, 26, 17, 23, 20, 22, 19, 18, 28, 24, 27, 16, 29, 21, 14, 13, 4, 11],
                "worst-individual-distance": 45822.18172279654,
                "average-distance": 43854.93219041656,
                "individual-distances": []
            }, {
                "best-individual-sequence": [3, 4, 5, 10, 2, 1, 6, 11, 8, 12, 14, 17, 18, 22, 29, 28, 20, 25, 16, 24, 27, 26, 23, 21, 15, 19, 13, 9, 7],
                "best-individual-distance": 36195.28137971668,
                "worst-individual-sequence": [4, 1, 2, 6, 11, 5, 3, 8, 7, 9, 12, 17, 15, 19, 18, 28, 20, 25, 16, 24, 27, 26, 23, 21, 22, 29, 10, 13, 14],
                "worst-individual-distance": 45665.99598781142,
                "average-distance": 43713.99395564753,
                "individual-distances": []
            }
        ]
    ]
}
